// WidgetBlueprintGeneratedClass ClanCreate.ClanCreate_C
// Size: 0x3c8 (Inherited: 0x388)
struct UClanCreate_C : UPDClanCreateUI {
	struct UImage* IMG_Bar_01; // 0x388(0x08)
	struct UImage* IMG_Bar_02; // 0x390(0x08)
	struct UImage* IMG_Bar_03; // 0x398(0x08)
	struct UImage* IMG_Bar_04; // 0x3a0(0x08)
	struct UImage* IMG_Bar_05; // 0x3a8(0x08)
	struct UImage* IMG_InputBg_01; // 0x3b0(0x08)
	struct UImage* IMG_InputBg_02; // 0x3b8(0x08)
	struct UImage* IMG_InputBg_03; // 0x3c0(0x08)
};

