// BlueprintGeneratedClass BP_DMetal2Door_001_Left.BP_DMetal2Door_001_Left_C
// Size: 0x738 (Inherited: 0x728)
struct ABP_DMetal2Door_001_Left_C : APDDynamicObject {
	struct UStaticMeshComponent* LDOOR#; // 0x728(0x08)
	struct USceneComponent* ALIVEOBJ#; // 0x730(0x08)
};

