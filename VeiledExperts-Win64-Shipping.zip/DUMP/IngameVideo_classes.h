// WidgetBlueprintGeneratedClass IngameVideo.IngameVideo_C
// Size: 0x318 (Inherited: 0x2e8)
struct UIngameVideo_C : UPDIngameVideoUI {
	struct UWidgetAnimation* Anim_Logo; // 0x2e8(0x08)
	struct UImage* IMG_DERAILED_Logo_Fx_01; // 0x2f0(0x08)
	struct UImage* IMG_DERAILED_Logo_Fx_02; // 0x2f8(0x08)
	struct UImage* IMG_Logo; // 0x300(0x08)
	struct URetainerBox* RT_Logo_Fx_01; // 0x308(0x08)
	struct URetainerBox* RT_Logo_Fx_02; // 0x310(0x08)
};

