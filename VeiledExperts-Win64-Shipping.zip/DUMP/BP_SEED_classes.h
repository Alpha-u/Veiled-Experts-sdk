// BlueprintGeneratedClass BP_SEED.BP_SEED_C
// Size: 0x428 (Inherited: 0x240)
struct ABP_SEED_C : APDTransformationBaseActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)
	struct USceneComponent* SeedBase; // 0x248(0x08)
	struct USceneComponent* SeedBeam; // 0x250(0x08)
	struct USceneComponent* SeedHorogram; // 0x258(0x08)
	struct USceneComponent* SeedBody; // 0x260(0x08)
	struct USceneComponent* R_SeedRoot; // 0x268(0x08)
	struct USceneComponent* L_SeedRoot; // 0x270(0x08)
	struct USceneComponent* SeedRoot; // 0x278(0x08)
	struct UStaticMeshComponent* SM_SeedInBox; // 0x280(0x08)
	struct UStaticMeshComponent* SM_Seed_HoloBox; // 0x288(0x08)
	struct UStaticMeshComponent* SeedDisplay; // 0x290(0x08)
	struct UStaticMeshComponent* Seed_core_stick1; // 0x298(0x08)
	struct USceneComponent* L_SeedStick; // 0x2a0(0x08)
	struct UStaticMeshComponent* Seed_core_stick; // 0x2a8(0x08)
	struct USceneComponent* R_SeedStick; // 0x2b0(0x08)
	struct UStaticMeshComponent* Seed_Disk1; // 0x2b8(0x08)
	struct USceneComponent* R_Seed_Disk; // 0x2c0(0x08)
	struct UStaticMeshComponent* Seed_Disk; // 0x2c8(0x08)
	struct USceneComponent* L_Seed_Disk; // 0x2d0(0x08)
	struct USceneComponent* SeedLCD; // 0x2d8(0x08)
	struct UStaticMeshComponent* Seed_LCD; // 0x2e0(0x08)
	struct UStaticMeshComponent* Seed_body; // 0x2e8(0x08)
	struct UStaticMeshComponent* R_Seed_cover; // 0x2f0(0x08)
	struct UStaticMeshComponent* R_Seed_core_Cage; // 0x2f8(0x08)
	struct USceneComponent* R_CoreCage; // 0x300(0x08)
	struct UStaticMeshComponent* L_Seed_core_Cage; // 0x308(0x08)
	struct USceneComponent* L_CoreCage; // 0x310(0x08)
	struct USceneComponent* R_SeedCover; // 0x318(0x08)
	struct UStaticMeshComponent* R_Seed_core_side; // 0x320(0x08)
	struct USceneComponent* R_SeedSide; // 0x328(0x08)
	struct UStaticMeshComponent* R_Seed_side_Fame; // 0x330(0x08)
	struct USceneComponent* R_SideFrame; // 0x338(0x08)
	struct UStaticMeshComponent* Seed_cover; // 0x340(0x08)
	struct USceneComponent* L_SeedCover; // 0x348(0x08)
	struct UStaticMeshComponent* L_Seed_Side; // 0x350(0x08)
	struct USceneComponent* L_SeedSide; // 0x358(0x08)
	struct UStaticMeshComponent* L_Seed_Fame; // 0x360(0x08)
	struct USceneComponent* L_SideFrame; // 0x368(0x08)
	float _____2______0_A4E373AD451C4EA1023BFEB02B40DB76; // 0x370(0x04)
	enum class ETimelineDirection _____2__Direction_A4E373AD451C4EA1023BFEB02B40DB76; // 0x374(0x01)
	char pad_375[0x3]; // 0x375(0x03)
	struct UTimelineComponent*  �� _3; // 0x378(0x08)
	float _____0______0_DA74BFFB4F7B53E5F6B63ABB2001959E; // 0x380(0x04)
	enum class ETimelineDirection _____0__Direction_DA74BFFB4F7B53E5F6B63ABB2001959E; // 0x384(0x01)
	char pad_385[0x3]; // 0x385(0x03)
	struct UTimelineComponent*  �� _1; // 0x388(0x08)
	float _____1______0_6676C0284955210E1C914B9DCE8474A2; // 0x390(0x04)
	enum class ETimelineDirection _____1__Direction_6676C0284955210E1C914B9DCE8474A2; // 0x394(0x01)
	char pad_395[0x3]; // 0x395(0x03)
	struct UTimelineComponent*  �� _2; // 0x398(0x08)
	struct FLinearColor Color_Color_3803D0EF4D1CE496012065AA82382E91; // 0x3a0(0x10)
	enum class ETimelineDirection Color__Direction_3803D0EF4D1CE496012065AA82382E91; // 0x3b0(0x01)
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct UTimelineComponent* Color; // 0x3b8(0x08)
	struct TMap<struct FString, struct FTransformationStructArray> TransformationMap; // 0x3c0(0x50)
	float Speed; // 0x410(0x04)
	float Delay; // 0x414(0x04)
	struct FLinearColor Blue; // 0x418(0x10)

	void SetTranformationData(struct TArray<struct USceneComponent*>& TargetComponent, struct FName SequenceName); // Function BP_SEED.BP_SEED_C.SetTranformationData // (Net|NetReliableNetRequest|Exec|Event|Static|MulticastDelegate|Public|Private|Delegate|HasOutParms|NetClient|BlueprintCallable|Const) // @ game+0xffff8008b8ceffff
	void InitData(); // Function BP_SEED.BP_SEED_C.InitData // (None) // @ game+0xffff8008b8ceffff
	void Color__FinishedFunc(); // Function BP_SEED.BP_SEED_C.Color__FinishedFunc // (Native|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void Color__UpdateFunc(); // Function BP_SEED.BP_SEED_C.Color__UpdateFunc // (Net|Native|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void  ��읅랽잹ð(); // Function BP_SEED.BP_SEED_C. ��읅랽잹ð // (NetReliableNative|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void  ��읅랽잹ð(); // Function BP_SEED.BP_SEED_C. ��읅랽잹ð // (Net|NetReliableNative|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void  ��읅랽잹ñ(); // Function BP_SEED.BP_SEED_C. ��읅랽잹ñ // (NetRequest|Native|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void  ��읅랽잹ñ(); // Function BP_SEED.BP_SEED_C. ��읅랽잹ñ // (Net|NetReliableExec|Native|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void  ��읅랽잹ó(); // Function BP_SEED.BP_SEED_C. ��읅랽잹ó // (Net|NetRequest|Native|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void  ��읅랽잹ó(); // Function BP_SEED.BP_SEED_C. ��읅랽잹ó // (NetRequest|Exec|Native|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void ReceiveBeginPlay(); // Function BP_SEED.BP_SEED_C.ReceiveBeginPlay // (NetRequest|Exec|Native|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void OnActivateStart(); // Function BP_SEED.BP_SEED_C.OnActivateStart // (Net|Event|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void OnTestEditor(); // Function BP_SEED.BP_SEED_C.OnTestEditor // (Net|NetRequest|Event|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void K2_OnReset(); // Function BP_SEED.BP_SEED_C.K2_OnReset // (Net|NetRequest|Native|NetResponse|Static|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_BP_SEED(int32_t EntryPoint); // Function BP_SEED.BP_SEED_C.ExecuteUbergraph_BP_SEED // (Native|NetResponse|UbergraphFunction|MulticastDelegate|Public|Private|Protected|HasDefaults|NetClient|DLLImport|BlueprintEvent|EditorOnly|Const) // @ game+0xffff8008b8ceffff
};

