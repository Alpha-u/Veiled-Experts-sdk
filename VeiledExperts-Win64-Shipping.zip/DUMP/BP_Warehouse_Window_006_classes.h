// BlueprintGeneratedClass BP_Warehouse_Window_006.BP_Warehouse_Window_006_C
// Size: 0x240 (Inherited: 0x220)
struct ABP_Warehouse_Window_006_C : AActor {
	struct UChildActorComponent* ChildActor10; // 0x220(0x08)
	struct UChildActorComponent* ChildActor3; // 0x228(0x08)
	struct UStaticMeshComponent* SM_Warehpuse_Window_006; // 0x230(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x238(0x08)
};

