// Class MirrorAnimationSystem.ExtCharacter
// Size: 0x4c0 (Inherited: 0x4c0)
struct AExtCharacter : ACharacter {

	void SetRootMotionMirrorAndFlipAxis(enum class EAxis MirrorAxis, enum class EAxis FlipAxis); // Function MirrorAnimationSystem.ExtCharacter.SetRootMotionMirrorAndFlipAxis // (None) // @ game+0xffff8008b8ceffff
	void SetMirrorRootMotion(bool Mirror); // Function MirrorAnimationSystem.ExtCharacter.SetMirrorRootMotion // (None) // @ game+0xffff8008b8ceffff
	void GetRootMotionMirrorAndFlipAxis(enum class EAxis& MirrorAxis, enum class EAxis& FlipAxis); // Function MirrorAnimationSystem.ExtCharacter.GetRootMotionMirrorAndFlipAxis // (None) // @ game+0xffff8008b8ceffff
	bool GetMirrorRootMotion(); // Function MirrorAnimationSystem.ExtCharacter.GetMirrorRootMotion // (None) // @ game+0xffff8008b8ce0000
};

// Class MirrorAnimationSystem.ExtCharacterMovementComponent
// Size: 0x620 (Inherited: 0x610)
struct UExtCharacterMovementComponent : UCharacterMovementComponent {
	bool MirrorRootMotion; // 0x610(0x01)
	enum class EAxis MirrorAxis; // 0x611(0x01)
	enum class EAxis FlipAxis; // 0x612(0x01)
	char pad_613[0xd]; // 0x613(0x0d)
};

// Class MirrorAnimationSystem.MirrorTable
// Size: 0x40 (Inherited: 0x30)
struct UMirrorTable : UDataAsset {
	struct TArray<struct FMirrorBone> MirrorBones; // 0x30(0x10)
};

