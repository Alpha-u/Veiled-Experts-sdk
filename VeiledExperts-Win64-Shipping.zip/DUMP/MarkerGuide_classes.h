// WidgetBlueprintGeneratedClass MarkerGuide.MarkerGuide_C
// Size: 0x3a0 (Inherited: 0x378)
struct UMarkerGuide_C : UPDMarkerGuide {
	struct UImage* IMG_MoseLB; // 0x378(0x08)
	struct UImage* IMG_MoseMB; // 0x380(0x08)
	struct UImage* IMG_MoseRB; // 0x388(0x08)
	struct UImage* IMG_Split; // 0x390(0x08)
	struct UImage* IMG_TextLine; // 0x398(0x08)
};

