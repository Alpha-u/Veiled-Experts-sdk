// BlueprintGeneratedClass Export_SeedArea_AB.Export_SeedArea_AB_C
// Size: 0x290 (Inherited: 0x280)
struct AExport_SeedArea_AB_C : APDExportSeedArea {
	struct UStaticMeshComponent* BDecal; // 0x280(0x08)
	struct UStaticMeshComponent* ADecal; // 0x288(0x08)
};

