// BlueprintGeneratedClass BP_MERGED_AC_unit_SET_004_01.BP_MERGED_AC_unit_SET_004_01_C
// Size: 0x3a0 (Inherited: 0x370)
struct ABP_MERGED_AC_unit_SET_004_01_C : APDPropActor {
	struct UStaticMeshComponent* SM_AirPropeller_002; // 0x370(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_001; // 0x378(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_004; // 0x380(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_003; // 0x388(0x08)
	struct UStaticMeshComponent* SM_AC_unit_SET_004_01; // 0x390(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x398(0x08)
};

