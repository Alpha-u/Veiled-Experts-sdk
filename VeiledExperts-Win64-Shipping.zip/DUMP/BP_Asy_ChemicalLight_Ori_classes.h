// BlueprintGeneratedClass BP_Asy_ChemicalLight_Ori.BP_Asy_ChemicalLight_Ori_C
// Size: 0x248 (Inherited: 0x240)
struct ABP_Asy_ChemicalLight_Ori_C : APDAsyncObject {
	struct UPointLightComponent* PointLight; // 0x240(0x08)
};

