// BlueprintGeneratedClass BP_RooftopHVC_001.BP_RooftopHVC_001_C
// Size: 0x3d8 (Inherited: 0x370)
struct ABP_RooftopHVC_001_C : APDPropActor {
	struct UStaticMeshComponent* SM_Decal_020; // 0x370(0x08)
	struct UStaticMeshComponent* SM_Decal_002; // 0x378(0x08)
	struct UStaticMeshComponent* SM_Decal_019; // 0x380(0x08)
	struct UStaticMeshComponent* SM_RooftopHVC_MERGED_001; // 0x388(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_009; // 0x390(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_008; // 0x398(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_007; // 0x3a0(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_006; // 0x3a8(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_005; // 0x3b0(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_004; // 0x3b8(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_003; // 0x3c0(0x08)
	struct UStaticMeshComponent* SM_AirPropeller_002; // 0x3c8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3d0(0x08)
};

