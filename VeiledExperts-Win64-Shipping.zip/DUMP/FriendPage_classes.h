// WidgetBlueprintGeneratedClass FriendPage.FriendPage_C
// Size: 0x2e0 (Inherited: 0x2e0)
struct UFriendPage_C : UPDFriendPage {
};

