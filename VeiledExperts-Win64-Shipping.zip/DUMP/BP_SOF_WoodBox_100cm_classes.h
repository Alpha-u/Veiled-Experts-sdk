// BlueprintGeneratedClass BP_SOF_WoodBox_100cm.BP_SOF_WoodBox_100cm_C
// Size: 0x300 (Inherited: 0x300)
struct ABP_SOF_WoodBox_100cm_C : APDSplitObjectFall {
};

