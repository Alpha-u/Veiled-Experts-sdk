// WidgetBlueprintGeneratedClass CoinRequest.CoinRequest_C
// Size: 0x360 (Inherited: 0x318)
struct UCoinRequest_C : UPDUnKnownMarketCoinRequestUI {
	struct UImage* IMG_Blinder; // 0x318(0x08)
	struct UImage* IMG_CoinDivide_BG; // 0x320(0x08)
	struct UImage* IMG_CoinIcon; // 0x328(0x08)
	struct UImage* IMG_DivideModule_BG; // 0x330(0x08)
	struct UImage* IMG_Outline; // 0x338(0x08)
	struct UImage* IMG_SliderBar_BG; // 0x340(0x08)
	struct UImage* IMG_SliderBar_Max; // 0x348(0x08)
	struct UImage* IMG_SliderBar_Min; // 0x350(0x08)
	struct UImage* IMG_Title_Deco; // 0x358(0x08)
};

