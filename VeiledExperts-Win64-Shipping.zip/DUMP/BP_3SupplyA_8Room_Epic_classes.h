// BlueprintGeneratedClass BP_3SupplyA_8Room_Epic.BP_3SupplyA_8Room_Epic_C
// Size: 0x260 (Inherited: 0x220)
struct ABP_3SupplyA_8Room_Epic_C : AActor {
	struct UStaticMeshComponent* SM_DecalLeaking_003; // 0x220(0x08)
	struct UStaticMeshComponent* SM_DecalLeaking_002; // 0x228(0x08)
	struct UStaticMeshComponent* SM_DecalLeaking_001; // 0x230(0x08)
	struct UStaticMeshComponent* SM_DecalLeaking_006; // 0x238(0x08)
	struct UStaticMeshComponent* SM_EaterySign_003; // 0x240(0x08)
	struct UStaticMeshComponent* SM_EaterySign_005; // 0x248(0x08)
	struct UStaticMeshComponent* SM_Hallway_Vent_002; // 0x250(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x258(0x08)
};

