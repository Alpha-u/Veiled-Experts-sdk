// WidgetBlueprintGeneratedClass EscMenu.EscMenu_C
// Size: 0x310 (Inherited: 0x300)
struct UEscMenu_C : UPDEscMenuUI {
	struct UImage* IMG_TitleDeco_L; // 0x300(0x08)
	struct UImage* IMG_TitleDeco_R; // 0x308(0x08)
};

