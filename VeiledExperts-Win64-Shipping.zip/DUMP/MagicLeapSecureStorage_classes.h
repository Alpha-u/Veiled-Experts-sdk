// Class MagicLeapSecureStorage.MagicLeapSecureStorage
// Size: 0x28 (Inherited: 0x28)
struct UMagicLeapSecureStorage : UBlueprintFunctionLibrary {

	bool PutSecureVector(struct FString Key, struct FVector& DataToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureVector // (None) // @ game+0xffff80091677001c
	bool PutSecureTransform(struct FString Key, struct FTransform& DataToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureTransform // (None) // @ game+0xffff800916770040
	bool PutSecureString(struct FString Key, struct FString DataToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureString // (None) // @ game+0xffff800916770020
	bool PutSecureSaveGame(struct FString Key, struct USaveGame* ObjectToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureSaveGame // (None) // @ game+0xffff800916770018
	bool PutSecureRotator(struct FString Key, struct FRotator& DataToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureRotator // (None) // @ game+0xffff80091677001c
	bool PutSecureInt64(struct FString Key, int64_t DataToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureInt64 // (None) // @ game+0xffff800916770018
	bool PutSecureInt(struct FString Key, int32_t DataToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureInt // (None) // @ game+0xffff800916770014
	bool PutSecureFloat(struct FString Key, float DataToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureFloat // (None) // @ game+0xffff800916770014
	bool PutSecureByte(struct FString Key, char DataToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureByte // (None) // @ game+0xffff800916770011
	bool PutSecureBool(struct FString Key, bool DataToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureBool // (None) // @ game+0xffff800916770011
	bool PutSecureArray(struct FString Key, struct TArray<int32_t>& DataToStore); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.PutSecureArray // (None) // @ game+0xffff800916770020
	bool GetSecureVector(struct FString Key, struct FVector& DataToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureVector // (None) // @ game+0xffff80091677001c
	bool GetSecureTransform(struct FString Key, struct FTransform& DataToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureTransform // (None) // @ game+0xffff800916770040
	bool GetSecureString(struct FString Key, struct FString& DataToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureString // (None) // @ game+0xffff800916770020
	bool GetSecureSaveGame(struct FString Key, struct USaveGame*& ObjectToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureSaveGame // (None) // @ game+0xffff800916770018
	bool GetSecureRotator(struct FString Key, struct FRotator& DataToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureRotator // (None) // @ game+0xffff80091677001c
	bool GetSecureInt64(struct FString Key, int64_t& DataToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureInt64 // (None) // @ game+0xffff800916770018
	bool GetSecureInt(struct FString Key, int32_t& DataToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureInt // (None) // @ game+0xffff800916770014
	bool GetSecureFloat(struct FString Key, float& DataToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureFloat // (None) // @ game+0xffff800916770014
	bool GetSecureByte(struct FString Key, char& DataToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureByte // (None) // @ game+0xffff800916770011
	bool GetSecureBool(struct FString Key, bool& DataToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureBool // (None) // @ game+0xffff800916770011
	bool GetSecureArray(struct FString Key, struct TArray<int32_t>& DataToRetrieve); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.GetSecureArray // (None) // @ game+0xffff800916770020
	bool DeleteSecureData(struct FString Key); // Function MagicLeapSecureStorage.MagicLeapSecureStorage.DeleteSecureData // (None) // @ game+0xffff800916770010
};

