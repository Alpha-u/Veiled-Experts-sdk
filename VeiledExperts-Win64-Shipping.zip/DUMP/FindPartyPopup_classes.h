// WidgetBlueprintGeneratedClass FindPartyPopup.FindPartyPopup_C
// Size: 0x450 (Inherited: 0x3b8)
struct UFindPartyPopup_C : UPDFindPartyPageUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x3b8(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x3c0(0x08)
	struct UImage* IMG_Bg; // 0x3c8(0x08)
	struct UImage* IMG_Brick_TitleBg; // 0x3d0(0x08)
	struct UImage* IMG_Category_Line_01; // 0x3d8(0x08)
	struct UImage* IMG_Category_Line_02; // 0x3e0(0x08)
	struct UImage* IMG_FindParty; // 0x3e8(0x08)
	struct UImage* IMG_FindParty_Disabled; // 0x3f0(0x08)
	struct UImage* IMG_FindParty_Done; // 0x3f8(0x08)
	struct UImage* IMG_FindParty_Searching; // 0x400(0x08)
	struct UImage* IMG_FindPartyMannerToolTipBg; // 0x408(0x08)
	struct UImage* IMG_FindPartyMannerToolTipOutline; // 0x410(0x08)
	struct UImage* IMG_MannerToolTipBg; // 0x418(0x08)
	struct UImage* IMG_MannerToolTipOutline; // 0x420(0x08)
	struct UImage* IMG_Register; // 0x428(0x08)
	struct UImage* IMG_Register_Disabled; // 0x430(0x08)
	struct UImage* IMG_Register_Searching; // 0x438(0x08)
	struct UImage* IMG_ToolTipBg; // 0x440(0x08)
	struct UImage* IMG_ToolTipOutline; // 0x448(0x08)
};

