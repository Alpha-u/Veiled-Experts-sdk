// WidgetBlueprintGeneratedClass Match.Match_C
// Size: 0x368 (Inherited: 0x328)
struct UMatch_C : UPDMatchUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x328(0x08)
	struct UWidgetAnimation* LoadingDotAni; // 0x330(0x08)
	struct UImage* IMG_AnimIndicator_A; // 0x338(0x08)
	struct UImage* IMG_AnimIndicator_B; // 0x340(0x08)
	struct UImage* IMG_Dot1; // 0x348(0x08)
	struct UImage* IMG_Dot2; // 0x350(0x08)
	struct UImage* IMG_Dot3; // 0x358(0x08)
	struct UImage* IMG_GradationBox; // 0x360(0x08)

	void PreConstruct(bool IsDesignTime); // Function Match.Match_C.PreConstruct // (NetRequest|Native|NetResponse|Static|UbergraphFunction|Protected|HasOutParms|HasDefaults|BlueprintEvent|EditorOnly|NetValidate) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_Match(int32_t EntryPoint); // Function Match.Match_C.ExecuteUbergraph_Match // (None) // @ game+0xffff80091677ffff
};

