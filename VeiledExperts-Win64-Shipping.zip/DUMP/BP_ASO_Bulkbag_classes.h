// BlueprintGeneratedClass BP_ASO_Bulkbag.BP_ASO_Bulkbag_C
// Size: 0x2d8 (Inherited: 0x2d8)
struct ABP_ASO_Bulkbag_C : APDAnimSyncObject {
};

