// BlueprintGeneratedClass BP_AsyDS_Cardboard_004.BP_AsyDS_Cardboard_004_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_AsyDS_Cardboard_004_C : APDAsyncObjectDestroyed {
};

