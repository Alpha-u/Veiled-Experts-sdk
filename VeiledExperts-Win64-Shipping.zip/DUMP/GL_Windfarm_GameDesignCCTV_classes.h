// BlueprintGeneratedClass GL_Windfarm_GameDesignCCTV.GL_Windfarm_GameDesignCCTV_C
// Size: 0x228 (Inherited: 0x228)
struct AGL_Windfarm_GameDesignCCTV_C : ALevelScriptActor {
};

