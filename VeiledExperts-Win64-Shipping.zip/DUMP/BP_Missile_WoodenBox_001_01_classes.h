// BlueprintGeneratedClass BP_Missile_WoodenBox_001_01.BP_Missile_WoodenBox_001_01_C
// Size: 0x240 (Inherited: 0x220)
struct ABP_Missile_WoodenBox_001_01_C : AActor {
	struct UStaticMeshComponent* SM_Missile_WoodenBox_001_02; // 0x220(0x08)
	struct UStaticMeshComponent* SM_Missile_WoodenBox_001_03; // 0x228(0x08)
	struct UStaticMeshComponent* SM_Missile_WoodenBox_001_01; // 0x230(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x238(0x08)
};

