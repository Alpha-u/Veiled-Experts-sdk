// WidgetBlueprintGeneratedClass MatchList.MatchList_C
// Size: 0x2e8 (Inherited: 0x2e8)
struct UMatchList_C : UPDMatchListUI {
};

