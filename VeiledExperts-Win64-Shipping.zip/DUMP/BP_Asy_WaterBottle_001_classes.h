// BlueprintGeneratedClass BP_Asy_WaterBottle_001.BP_Asy_WaterBottle_001_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_Asy_WaterBottle_001_C : APDAsyncObject {
};

