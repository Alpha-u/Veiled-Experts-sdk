// WidgetBlueprintGeneratedClass MatchPlayerTeamCharListItem.MatchPlayerTeamCharListItem_C
// Size: 0x2f8 (Inherited: 0x2f8)
struct UMatchPlayerTeamCharListItem_C : UPDMatchPlayerTeamCharListItem {
};

