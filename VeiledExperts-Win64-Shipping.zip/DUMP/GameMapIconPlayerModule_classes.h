// WidgetBlueprintGeneratedClass GameMapIconPlayerModule.GameMapIconPlayerModule_C
// Size: 0x3b8 (Inherited: 0x380)
struct UGameMapIconPlayerModule_C : UPDGameMapIconPlayerUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)
	struct UWidgetAnimation* Shooting; // 0x388(0x08)
	struct UImage* IMG_Bomb; // 0x390(0x08)
	struct UImage* IMG_Dead; // 0x398(0x08)
	struct UImage* IMG_Shot00; // 0x3a0(0x08)
	struct UImage* IMG_Shot01; // 0x3a8(0x08)
	struct UImage* IMG_VeiwArea; // 0x3b0(0x08)

	void Construct(); // Function GameMapIconPlayerModule.GameMapIconPlayerModule_C.Construct // (Net|Exec|Native|Static|UbergraphFunction|MulticastDelegate|Private|Protected|Delegate|NetServer|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintPure|EditorOnly) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_GameMapIconPlayerModule(int32_t EntryPoint); // Function GameMapIconPlayerModule.GameMapIconPlayerModule_C.ExecuteUbergraph_GameMapIconPlayerModule // (None) // @ game+0xffff8008b8ceffff
};

