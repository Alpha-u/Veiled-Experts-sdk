// Class ImageWriteQueue.ImageWriteBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UImageWriteBlueprintLibrary : UBlueprintFunctionLibrary {

	void ExportToDisk(struct UTexture* Texture, struct FString Filename, struct FImageWriteOptions& Options); // Function ImageWriteQueue.ImageWriteBlueprintLibrary.ExportToDisk // (None) // @ game+0xffff8008b8ceffff
};

