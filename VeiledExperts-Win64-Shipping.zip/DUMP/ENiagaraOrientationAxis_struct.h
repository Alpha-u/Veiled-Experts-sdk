// UserDefinedEnum ENiagaraOrientationAxis.ENiagaraOrientationAxis
enum class ENiagaraOrientationAxis : uint8 {
	None = 0
};

