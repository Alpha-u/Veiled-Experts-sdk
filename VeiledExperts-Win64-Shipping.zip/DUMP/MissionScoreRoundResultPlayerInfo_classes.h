// WidgetBlueprintGeneratedClass MissionScoreRoundResultPlayerInfo.MissionScoreRoundResultPlayerInfo_C
// Size: 0x468 (Inherited: 0x440)
struct UMissionScoreRoundResultPlayerInfo_C : UPDMSRoundResultPlayerInfo {
	struct UImage* IMG_Down; // 0x440(0x08)
	struct UImage* IMG_Keep; // 0x448(0x08)
	struct UImage* IMG_SlotBg_Me; // 0x450(0x08)
	struct UImage* IMG_TopLine; // 0x458(0x08)
	struct UImage* IMG_Up; // 0x460(0x08)
};

