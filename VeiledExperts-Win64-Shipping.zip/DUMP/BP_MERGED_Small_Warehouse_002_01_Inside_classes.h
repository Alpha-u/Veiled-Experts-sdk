// BlueprintGeneratedClass BP_MERGED_Small_Warehouse_002_01_Inside.BP_MERGED_Small_Warehouse_002_01_Inside_C
// Size: 0x290 (Inherited: 0x220)
struct ABP_MERGED_Small_Warehouse_002_01_Inside_C : AActor {
	struct UStaticMeshComponent* SM_FireExtinguisher_002; // 0x220(0x08)
	struct UStaticMeshComponent* SM_EmergencyBoardFull_001; // 0x228(0x08)
	struct UStaticMeshComponent* SM_Exit_002; // 0x230(0x08)
	struct UStaticMeshComponent* SM_FuseBox_05; // 0x238(0x08)
	struct UStaticMeshComponent* SM_WallSwitch_07; // 0x240(0x08)
	struct UStaticMeshComponent* SM_LampCeiling_007; // 0x248(0x08)
	struct UStaticMeshComponent* SM_LampCeiling_006; // 0x250(0x08)
	struct UStaticMeshComponent* SM_Exit_004; // 0x258(0x08)
	struct UStaticMeshComponent* SM_Exit_003; // 0x260(0x08)
	struct UStaticMeshComponent* SM_LampCeiling_005; // 0x268(0x08)
	struct UStaticMeshComponent* SM_LampCeiling_003; // 0x270(0x08)
	struct UStaticMeshComponent* SM_Exit_001; // 0x278(0x08)
	struct UStaticMeshComponent* SM_WallSwitch_04; // 0x280(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x288(0x08)
};

