// WidgetBlueprintGeneratedClass AgentRecently.AgentRecently_C
// Size: 0x330 (Inherited: 0x330)
struct UAgentRecently_C : UPDRecentlyUI {
};

