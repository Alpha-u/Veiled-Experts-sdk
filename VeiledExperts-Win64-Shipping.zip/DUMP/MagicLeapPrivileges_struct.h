// Enum MagicLeapPrivileges.EMagicLeapPrivilege
enum class EMagicLeapPrivilege : uint8 {
	None = 0,
	None = 0
};

