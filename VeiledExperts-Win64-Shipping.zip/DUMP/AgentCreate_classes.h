// WidgetBlueprintGeneratedClass AgentCreate.AgentCreate_C
// Size: 0x3d0 (Inherited: 0x380)
struct UAgentCreate_C : UPDAgentCreateUI {
	struct UWidgetAnimation* Anim_BtnShow; // 0x380(0x08)
	struct UWidgetAnimation* Anim_SceneOut; // 0x388(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x390(0x08)
	struct UPDKeyButton_C* Btn_F1; // 0x398(0x08)
	struct UImage* IMG_Logo; // 0x3a0(0x08)
	struct UImage* IMG_Name_Deco; // 0x3a8(0x08)
	struct UImage* IMG_Story_Deco; // 0x3b0(0x08)
	struct UImage* IMG_Tooltip_Bg; // 0x3b8(0x08)
	struct UImage* IMG_Tooltip_IconBg; // 0x3c0(0x08)
	struct UImage* IMG_Tooltip_Outline; // 0x3c8(0x08)

	void OnBP_OnGetItemChildren_1(struct UObject* Item, struct TArray<struct UObject*>& Children); // Function AgentCreate.AgentCreate_C.OnBP_OnGetItemChildren_1 // (None) // @ game+0xffff80091677ffff
};

