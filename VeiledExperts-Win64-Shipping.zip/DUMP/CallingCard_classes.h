// WidgetBlueprintGeneratedClass CallingCard.CallingCard_C
// Size: 0x350 (Inherited: 0x340)
struct UCallingCard_C : UPDCallingCardUI {
	struct UWidgetAnimation* AniEnd; // 0x340(0x08)
	struct UWidgetAnimation* AniStart; // 0x348(0x08)
};

