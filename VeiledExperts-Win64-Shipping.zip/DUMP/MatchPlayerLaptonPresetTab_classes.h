// WidgetBlueprintGeneratedClass MatchPlayerLaptonPresetTab.MatchPlayerLaptonPresetTab_C
// Size: 0x310 (Inherited: 0x310)
struct UMatchPlayerLaptonPresetTab_C : UPDMatchPlayerLaptonPresetTab {
};

