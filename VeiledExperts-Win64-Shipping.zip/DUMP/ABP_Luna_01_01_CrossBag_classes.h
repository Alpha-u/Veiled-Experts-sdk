// AnimBlueprintGeneratedClass ABP_Luna_01_01_CrossBag.ABP_Luna_01_01_CrossBag_C
// Size: 0x1edd (Inherited: 0x270)
struct UABP_Luna_01_01_CrossBag_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x278(0x30)
	char pad_2A8[0x8]; // 0x2a8(0x08)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6; // 0x2b0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5; // 0x6f0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4; // 0xb30(0x440)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0xf70(0x20)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0xf90(0xa0)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2; // 0x1030(0xe0)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x1110(0x20)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer; // 0x1130(0xe0)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3; // 0x1210(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2; // 0x1650(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics; // 0x1a90(0x440)
	struct FVector WindVelocity; // 0x1ed0(0x0c)
	bool UseAnimDynamics; // 0x1edc(0x01)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Luna_01_01_CrossBag.ABP_Luna_01_01_CrossBag_C.AnimGraph // (NetReliableNative|Event|NetMulticast|Public|Delegate|HasOutParms|NetClient|DLLImport|BlueprintCallable|NetValidate) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_ABP_Luna_01_01_CrossBag(int32_t EntryPoint); // Function ABP_Luna_01_01_CrossBag.ABP_Luna_01_01_CrossBag_C.ExecuteUbergraph_ABP_Luna_01_01_CrossBag // (None) // @ game+0xffff8008b8ceffff
};

