// BlueprintGeneratedClass BP_PlayerCharacter.BP_PlayerCharacter_C
// Size: 0xb50 (Inherited: 0xb50)
struct ABP_PlayerCharacter_C : APDPlayerCharacter {
};

