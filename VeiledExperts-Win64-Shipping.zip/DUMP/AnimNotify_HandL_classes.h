// BlueprintGeneratedClass AnimNotify_HandL.AnimNotify_HandL_C
// Size: 0xb8 (Inherited: 0xb8)
struct UAnimNotify_HandL_C : UPDParkourAkAnimNotify {
};

