// WidgetBlueprintGeneratedClass ClanApplicantListItem.ClanApplicantListItem_C
// Size: 0x330 (Inherited: 0x328)
struct UClanApplicantListItem_C : UPDClanApplicantListItemUI {
	struct UImage* IMG_Bg; // 0x328(0x08)
};

