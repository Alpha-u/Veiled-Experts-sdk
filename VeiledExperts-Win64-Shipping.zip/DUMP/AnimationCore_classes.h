// Class AnimationCore.AnimationDataSourceRegistry
// Size: 0x78 (Inherited: 0x28)
struct UAnimationDataSourceRegistry : UObject {
	struct TMap<struct FName, struct TWeakObjectPtr<struct UObject>> DataSources; // 0x28(0x50)
};

