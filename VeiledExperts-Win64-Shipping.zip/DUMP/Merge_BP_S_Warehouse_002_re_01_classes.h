// BlueprintGeneratedClass Merge_BP_S_Warehouse_002_re_01.Merge_BP_S_Warehouse_002_re_01_C
// Size: 0x248 (Inherited: 0x220)
struct AMerge_BP_S_Warehouse_002_re_01_C : AActor {
	struct UStaticMeshComponent* SM_Merge_S_Warehouse_002_04_re_02; // 0x220(0x08)
	struct UStaticMeshComponent* SM_Merge_S_Warehouse_002_04_re; // 0x228(0x08)
	struct UStaticMeshComponent* SM_Merge_S_Warehouse_002_04_re_01; // 0x230(0x08)
	struct UStaticMeshComponent* SM_Merge_S_Warehouse_002_04_Frame; // 0x238(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x240(0x08)
};

