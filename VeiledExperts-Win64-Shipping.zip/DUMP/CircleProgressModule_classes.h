// WidgetBlueprintGeneratedClass CircleProgressModule.CircleProgressModule_C
// Size: 0x348 (Inherited: 0x348)
struct UCircleProgressModule_C : UPDCircleProgressModule {
};

