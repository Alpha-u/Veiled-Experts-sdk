// WidgetBlueprintGeneratedClass InvenDivide.InvenDivide_C
// Size: 0x378 (Inherited: 0x328)
struct UInvenDivide_C : UPDInvenDivide {
	struct UImage* B_Title_Deco_3; // 0x328(0x08)
	struct UImage* IMG_Arrow_01; // 0x330(0x08)
	struct UImage* IMG_Arrow_02; // 0x338(0x08)
	struct UImage* IMG_BoxGlow; // 0x340(0x08)
	struct UImage* IMG_DivideModule_BG; // 0x348(0x08)
	struct UImage* IMG_InvenDivide_BG; // 0x350(0x08)
	struct UImage* IMG_Outline; // 0x358(0x08)
	struct UImage* IMG_SliderBar_01; // 0x360(0x08)
	struct UImage* IMG_SliderBar_02; // 0x368(0x08)
	struct UImage* IMG_SliderBar_BG; // 0x370(0x08)
};

