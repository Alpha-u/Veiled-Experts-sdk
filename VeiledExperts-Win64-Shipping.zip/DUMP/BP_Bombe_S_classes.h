// BlueprintGeneratedClass BP_Bombe_S.BP_Bombe_S_C
// Size: 0x748 (Inherited: 0x728)
struct ABP_Bombe_S_C : APDDynamicObject {
	struct UPDDynamicObjectPoint* POINT2#; // 0x728(0x08)
	struct UPDDynamicObjectPoint* POINT1#; // 0x730(0x08)
	struct UDestructibleComponent* FDESTROY#; // 0x738(0x08)
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x740(0x08)
};

