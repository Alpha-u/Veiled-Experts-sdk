// WidgetBlueprintGeneratedClass AgentProfile.AgentProfile_C
// Size: 0x438 (Inherited: 0x3c0)
struct UAgentProfile_C : UPDAgentProfileUI {
	struct UWidgetAnimation* Anim_AgentFree; // 0x3c0(0x08)
	struct UWidgetAnimation* Anim_Contract; // 0x3c8(0x08)
	struct UWidgetAnimation* Anim_SceneOut; // 0x3d0(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x3d8(0x08)
	struct UImage* IMG_Deco_01; // 0x3e0(0x08)
	struct UImage* IMG_Icon_LeptonBG_01; // 0x3e8(0x08)
	struct UImage* IMG_Icon_LeptonBG_02; // 0x3f0(0x08)
	struct UImage* IMG_Icon_SignatureBg; // 0x3f8(0x08)
	struct UImage* IMG_Mouse_W; // 0x400(0x08)
	struct UImage* IMG_PopupBg_01; // 0x408(0x08)
	struct UImage* IMG_PopupBg_02; // 0x410(0x08)
	struct UImage* IMG_PopupBg_L; // 0x418(0x08)
	struct UImage* IMG_ProfilePic_Bg; // 0x420(0x08)
	struct UImage* IMG_ProfilePic_Outline; // 0x428(0x08)
	struct UImage* IMG_ProfilePic_Shadow; // 0x430(0x08)
};

