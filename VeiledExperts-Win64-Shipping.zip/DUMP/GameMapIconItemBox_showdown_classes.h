// WidgetBlueprintGeneratedClass GameMapIconItemBox_showdown.GameMapIconItemBox_showdown_C
// Size: 0x2f0 (Inherited: 0x2f0)
struct UGameMapIconItemBox_showdown_C : UPDGameMapIconModule {
};

