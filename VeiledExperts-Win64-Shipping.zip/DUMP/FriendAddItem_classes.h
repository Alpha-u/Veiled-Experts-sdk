// WidgetBlueprintGeneratedClass FriendAddItem.FriendAddItem_C
// Size: 0x3c8 (Inherited: 0x3b8)
struct UFriendAddItem_C : UPDFriendAddItem {
	struct UImage* IMG_PictureBg; // 0x3b8(0x08)
	struct UImage* IMG_UserBg; // 0x3c0(0x08)
};

