// WidgetBlueprintGeneratedClass KillLog.KillLog_C
// Size: 0x308 (Inherited: 0x300)
struct UKillLog_C : UPDKillLogUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x300(0x08)

	void PreConstruct(bool IsDesignTime); // Function KillLog.KillLog_C.PreConstruct // (Net|NetReliableExec|Event|NetResponse|Static|Public|Private|NetServer|HasDefaults|DLLImport|BlueprintEvent|BlueprintPure|EditorOnly|NetValidate) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_KillLog(int32_t EntryPoint); // Function KillLog.KillLog_C.ExecuteUbergraph_KillLog // (None) // @ game+0xffff80091677ffff
};

