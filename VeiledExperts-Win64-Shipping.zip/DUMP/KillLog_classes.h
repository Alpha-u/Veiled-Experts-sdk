// WidgetBlueprintGeneratedClass KillLog.KillLog_C
// Size: 0x308 (Inherited: 0x300)
struct UKillLog_C : UPDKillLogUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x300(0x08)

	void PreConstruct(bool IsDesignTime); // Function KillLog.KillLog_C.PreConstruct // (NetReliableExec|Event|NetResponse|Static|Public|Private|Delegate|NetServer|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|EditorOnly|Const) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_KillLog(int32_t EntryPoint); // Function KillLog.KillLog_C.ExecuteUbergraph_KillLog // (None) // @ game+0xffff8008b8ceffff
};

