// WidgetBlueprintGeneratedClass AgentDefaultLeptonPopup.AgentDefaultLeptonPopup_C
// Size: 0x350 (Inherited: 0x320)
struct UAgentDefaultLeptonPopup_C : UPDAgentDefaultLeptonPopupUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x320(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x328(0x08)
	struct UImage* IMG_Background; // 0x330(0x08)
	struct UImage* IMG_PopupBg; // 0x338(0x08)
	struct UImage* IMG_TopDeco; // 0x340(0x08)
	struct URichTextBlock* RTB_Desc; // 0x348(0x08)
};

