// WidgetBlueprintGeneratedClass MatchStopInfoUI.MatchStopInfoUI_C
// Size: 0x328 (Inherited: 0x308)
struct UMatchStopInfoUI_C : UPDMatchStopInfoUI {
	struct UWidgetAnimation* Anim_End; // 0x308(0x08)
	struct UWidgetAnimation* Anim_Start; // 0x310(0x08)
	struct UImage* IMG_Indicator; // 0x318(0x08)
	struct UImage* IMG_Message_Bg; // 0x320(0x08)
};

