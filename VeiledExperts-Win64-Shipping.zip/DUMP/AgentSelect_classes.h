// WidgetBlueprintGeneratedClass AgentSelect.AgentSelect_C
// Size: 0x370 (Inherited: 0x348)
struct UAgentSelect_C : UPDAgentSelectUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x348(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x350(0x08)
	struct UEquipLeptonInfo_C* EquipLeptonInfo; // 0x358(0x08)
	struct UImage* IMG_Level_Bg; // 0x360(0x08)
	struct UImage* IMG_Level_Outline; // 0x368(0x08)
};

