// WidgetBlueprintGeneratedClass Ingame.Ingame_C
// Size: 0x3b0 (Inherited: 0x3b0)
struct UIngame_C : UPDIngameUI {
};

