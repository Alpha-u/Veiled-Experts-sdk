// BlueprintGeneratedClass BP_AC_unit_SET_004_01.BP_AC_unit_SET_004_01_C
// Size: 0x388 (Inherited: 0x370)
struct ABP_AC_unit_SET_004_01_C : APDPropActor {
	struct UStaticMeshComponent* SM_AirPropeller_001; // 0x370(0x08)
	struct UStaticMeshComponent* SM_AC_unit_001; // 0x378(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x380(0x08)
};

