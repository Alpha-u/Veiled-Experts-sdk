// WidgetBlueprintGeneratedClass MatchExtend.MatchExtend_C
// Size: 0x348 (Inherited: 0x308)
struct UMatchExtend_C : UPDMatchExtendUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x308(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x310(0x08)
	struct UImage* IMG_Deco; // 0x318(0x08)
	struct UImage* IMG_Desc_01_Arrow; // 0x320(0x08)
	struct UImage* IMG_Desc_02_Arrow; // 0x328(0x08)
	struct UImage* IMG_Desc_03_Arrow; // 0x330(0x08)
	struct UImage* IMG_Outglow; // 0x338(0x08)
	struct UImage* IMG_SlotBg; // 0x340(0x08)
};

