// BlueprintGeneratedClass BP_AsyDS_FlashLight_001_Sand.BP_AsyDS_FlashLight_001_Sand_C
// Size: 0x248 (Inherited: 0x240)
struct ABP_AsyDS_FlashLight_001_Sand_C : APDAsyncObjectDestroyed {
	struct USpotLightComponent* SpotLight; // 0x240(0x08)
};

