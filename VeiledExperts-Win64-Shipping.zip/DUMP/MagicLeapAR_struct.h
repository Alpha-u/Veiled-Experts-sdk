// Enum MagicLeapAR.ELuminARLineTraceChannel
enum class ELuminARLineTraceChannel : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapAR.ELuminARTrackingState
enum class ELuminARTrackingState : uint8 {
	None = 0,
	None = 0
};

