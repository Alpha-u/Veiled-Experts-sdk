// WidgetBlueprintGeneratedClass CoinInfoItem.CoinInfoItem_C
// Size: 0x318 (Inherited: 0x300)
struct UCoinInfoItem_C : UPDCoinInfoListItemUI {
	struct UWidgetAnimation* HideInfo; // 0x300(0x08)
	struct UWidgetAnimation* GetCoin; // 0x308(0x08)
	struct UImage* IMG_CoinFX; // 0x310(0x08)
};

