// BlueprintGeneratedClass AnimNotify_Slide.AnimNotify_Slide_C
// Size: 0x110 (Inherited: 0x110)
struct UAnimNotify_Slide_C : UPDSlideAkAnimNotify {
};

