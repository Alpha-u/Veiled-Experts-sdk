// WidgetBlueprintGeneratedClass KillNoti.KillNoti_C
// Size: 0x378 (Inherited: 0x350)
struct UKillNoti_C : UPDKillMessage {
	struct UWidgetAnimation* AniQuadraKill; // 0x350(0x08)
	struct UWidgetAnimation* AniTripleKill; // 0x358(0x08)
	struct UWidgetAnimation* AniPentaKill; // 0x360(0x08)
	struct UWidgetAnimation* AniDoubleKill; // 0x368(0x08)
	struct UWidgetAnimation* AniFirstKill; // 0x370(0x08)
};

