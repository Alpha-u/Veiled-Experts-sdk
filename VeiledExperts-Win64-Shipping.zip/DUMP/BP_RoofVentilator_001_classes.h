// BlueprintGeneratedClass BP_RoofVentilator_001.BP_RoofVentilator_001_C
// Size: 0x390 (Inherited: 0x370)
struct ABP_RoofVentilator_001_C : APDPropActor {
	struct UStaticMeshComponent* SM_RoofVentilator_Wheel_002; // 0x370(0x08)
	struct UStaticMeshComponent* SM_RoofVentilator_Wheel_001; // 0x378(0x08)
	struct UStaticMeshComponent* SM_RoofVentilator_Duct_001; // 0x380(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x388(0x08)
};

