// Enum MeshModelingTools.EMakeMeshPolygroupMode
enum class EMakeMeshPolygroupMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EMakeMeshPivotLocation
enum class EMakeMeshPivotLocation : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EMakeMeshPlacementType
enum class EMakeMeshPlacementType : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EMakeMeshShapeType
enum class EMakeMeshShapeType : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EAlignObjectsBoxPoint
enum class EAlignObjectsBoxPoint : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EAlignObjectsAlignToOptions
enum class EAlignObjectsAlignToOptions : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EAlignObjectsAlignTypes
enum class EAlignObjectsAlignTypes : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EBakeScaleMethod
enum class EBakeScaleMethod : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EConvertToPolygonsMode
enum class EConvertToPolygonsMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EQuickTransformerMode
enum class EQuickTransformerMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EWeightScheme
enum class EWeightScheme : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EGroupTopologyDeformationStrategy
enum class EGroupTopologyDeformationStrategy : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EDisplaceMeshToolDisplaceType
enum class EDisplaceMeshToolDisplaceType : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EDrawPolygonOutputMode
enum class EDrawPolygonOutputMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EDrawPolygonDrawMode
enum class EDrawPolygonDrawMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EDrawPolyPathExtrudeDirection
enum class EDrawPolyPathExtrudeDirection : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EDrawPolyPathHeightMode
enum class EDrawPolyPathHeightMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EDrawPolyPathWidthMode
enum class EDrawPolyPathWidthMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EDrawPolyPathOutputMode
enum class EDrawPolyPathOutputMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EPlaneBrushSideMode
enum class EPlaneBrushSideMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EDynamicMeshSculptBrushType
enum class EDynamicMeshSculptBrushType : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EPolyEditCutPlaneOrientation
enum class EPolyEditCutPlaneOrientation : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EPolyEditExtrudeDirection
enum class EPolyEditExtrudeDirection : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EEditMeshPolygonsToolActions
enum class EEditMeshPolygonsToolActions : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.ELocalFrameMode
enum class ELocalFrameMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EEditPivotToolActions
enum class EEditPivotToolActions : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EEditPivotSnapDragRotationMode
enum class EEditPivotSnapDragRotationMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EMeshEditingMaterialModes
enum class EMeshEditingMaterialModes : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.ESetMeshMaterialMode
enum class ESetMeshMaterialMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EMeshFacesColorMode
enum class EMeshFacesColorMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EMeshSelectionToolPrimaryMode
enum class EMeshSelectionToolPrimaryMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EMeshSelectionToolActions
enum class EMeshSelectionToolActions : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.ENonlinearOperationType
enum class ENonlinearOperationType : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EMaterialBoundaryConstraint
enum class EMaterialBoundaryConstraint : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EGroupBoundaryConstraint
enum class EGroupBoundaryConstraint : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EMeshBoundaryConstraint
enum class EMeshBoundaryConstraint : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EOcclusionCalculationUIMode
enum class EOcclusionCalculationUIMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.EOcclusionTriangleSamplingUIMode
enum class EOcclusionTriangleSamplingUIMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.ESmoothMeshToolSmoothType
enum class ESmoothMeshToolSmoothType : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.ETransformMeshesSnapDragRotationMode
enum class ETransformMeshesSnapDragRotationMode : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.ETransformMeshesSnapDragSource
enum class ETransformMeshesSnapDragSource : uint8 {
	None = 0,
	None = 0
};

// Enum MeshModelingTools.ETransformMeshesTransformMode
enum class ETransformMeshesTransformMode : uint8 {
	None = 0,
	None = 0
};

// ScriptStruct MeshModelingTools.EditPivotTarget
// Size: 0x10 (Inherited: 0x00)
struct FEditPivotTarget {
	struct UTransformProxy* TransformProxy; // 0x00(0x08)
	struct UTransformGizmo* TransformGizmo; // 0x08(0x08)
};

// ScriptStruct MeshModelingTools.TransformMeshesTarget
// Size: 0x10 (Inherited: 0x00)
struct FTransformMeshesTarget {
	struct UTransformProxy* TransformProxy; // 0x00(0x08)
	struct UTransformGizmo* TransformGizmo; // 0x08(0x08)
};

