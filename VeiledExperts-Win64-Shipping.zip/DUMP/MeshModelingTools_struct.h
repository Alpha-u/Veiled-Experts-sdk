// Enum MeshModelingTools.EMakeMeshPolygroupMode
enum class EMakeMeshPolygroupMode : uint8 {
	Single = 0,
	PerFace = 1,
	PerQuad = 2,
	EMakeMeshPolygroupMode_MAX = 3
};

// Enum MeshModelingTools.EMakeMeshPivotLocation
enum class EMakeMeshPivotLocation : uint8 {
	Base = 0,
	Centered = 1,
	Top = 2,
	EMakeMeshPivotLocation_MAX = 3
};

// Enum MeshModelingTools.EMakeMeshPlacementType
enum class EMakeMeshPlacementType : uint8 {
	GroundPlane = 0,
	OnScene = 1,
	EMakeMeshPlacementType_MAX = 2
};

// Enum MeshModelingTools.EMakeMeshShapeType
enum class EMakeMeshShapeType : int32 {
	None = 0,
	All = 4095,
	Box = 1,
	Cylinder = 2,
	Cone = 4,
	Arrow = 8,
	Rectangle = 16,
	RoundedRectangle = 32,
	Disc = 64,
	PuncturedDisc = 128,
	Torus = 256,
	SphericalBox = 512,
	Sphere = 1024,
	EMakeMeshShapeType_MAX = 4096
};

// Enum MeshModelingTools.EAlignObjectsBoxPoint
enum class EAlignObjectsBoxPoint : uint8 {
	Center = 0,
	Bottom = 1,
	Top = 2,
	Left = 3,
	Right = 4,
	Front = 5,
	Back = 6,
	Min = 7,
	Max = 8
};

// Enum MeshModelingTools.EAlignObjectsAlignToOptions
enum class EAlignObjectsAlignToOptions : uint8 {
	FirstSelected = 0,
	LastSelected = 1,
	Combined = 2,
	EAlignObjectsAlignToOptions_MAX = 3
};

// Enum MeshModelingTools.EAlignObjectsAlignTypes
enum class EAlignObjectsAlignTypes : uint8 {
	Pivots = 0,
	BoundingBoxes = 1,
	EAlignObjectsAlignTypes_MAX = 2
};

// Enum MeshModelingTools.EBakeScaleMethod
enum class EBakeScaleMethod : uint8 {
	BakeFullScale = 0,
	BakeNonuniformScale = 1,
	DoNotBakeScale = 2,
	EBakeScaleMethod_MAX = 3
};

// Enum MeshModelingTools.EConvertToPolygonsMode
enum class EConvertToPolygonsMode : uint8 {
	FaceNormalDeviation = 0,
	FromUVISlands = 1,
	EConvertToPolygonsMode_MAX = 2
};

// Enum MeshModelingTools.EQuickTransformerMode
enum class EQuickTransformerMode : uint8 {
	AxisTranslation = 0,
	AxisRotation = 1,
	EQuickTransformerMode_MAX = 2
};

// Enum MeshModelingTools.EWeightScheme
enum class EWeightScheme : uint8 {
	Uniform = 0,
	Umbrella = 1,
	Valence = 2,
	MeanValue = 3,
	Cotangent = 4,
	ClampedCotangent = 5,
	EWeightScheme_MAX = 6
};

// Enum MeshModelingTools.EGroupTopologyDeformationStrategy
enum class EGroupTopologyDeformationStrategy : uint8 {
	Linear = 0,
	Laplacian = 1,
	EGroupTopologyDeformationStrategy_MAX = 2
};

// Enum MeshModelingTools.EDisplaceMeshToolDisplaceType
enum class EDisplaceMeshToolDisplaceType : uint8 {
	Constant = 0,
	RandomNoise = 1,
	PerlinNoise = 2,
	DisplacementMap = 3,
	SineWave = 4,
	EDisplaceMeshToolDisplaceType_MAX = 5
};

// Enum MeshModelingTools.EDrawPolygonOutputMode
enum class EDrawPolygonOutputMode : uint8 {
	MeshedPolygon = 0,
	ExtrudedConstant = 1,
	ExtrudedInteractive = 2,
	EDrawPolygonOutputMode_MAX = 3
};

// Enum MeshModelingTools.EDrawPolygonDrawMode
enum class EDrawPolygonDrawMode : uint8 {
	Freehand = 0,
	Circle = 1,
	Square = 2,
	Rectangle = 3,
	RoundedRectangle = 4,
	HoleyCircle = 5,
	EDrawPolygonDrawMode_MAX = 6
};

// Enum MeshModelingTools.EDrawPolyPathExtrudeDirection
enum class EDrawPolyPathExtrudeDirection : uint8 {
	SelectionNormal = 0,
	WorldX = 1,
	WorldY = 2,
	WorldZ = 3,
	LocalX = 4,
	LocalY = 5,
	LocalZ = 6,
	EDrawPolyPathExtrudeDirection_MAX = 7
};

// Enum MeshModelingTools.EDrawPolyPathHeightMode
enum class EDrawPolyPathHeightMode : uint8 {
	Interactive = 0,
	Constant = 1,
	EDrawPolyPathHeightMode_MAX = 2
};

// Enum MeshModelingTools.EDrawPolyPathWidthMode
enum class EDrawPolyPathWidthMode : uint8 {
	Interactive = 0,
	Constant = 1,
	EDrawPolyPathWidthMode_MAX = 2
};

// Enum MeshModelingTools.EDrawPolyPathOutputMode
enum class EDrawPolyPathOutputMode : uint8 {
	Ribbon = 0,
	Extrusion = 1,
	Ramp = 2,
	EDrawPolyPathOutputMode_MAX = 3
};

// Enum MeshModelingTools.EPlaneBrushSideMode
enum class EPlaneBrushSideMode : uint8 {
	BothSides = 0,
	PushDown = 1,
	PullTowards = 2,
	EPlaneBrushSideMode_MAX = 3
};

// Enum MeshModelingTools.EDynamicMeshSculptBrushType
enum class EDynamicMeshSculptBrushType : uint8 {
	Move = 0,
	Smooth = 1,
	Offset = 2,
	SculptView = 3,
	SculptMax = 4,
	Inflate = 5,
	Pinch = 6,
	Flatten = 7,
	Plane = 8,
	PlaneViewAligned = 9,
	FixedPlane = 10,
	Resample = 11,
	LastValue = 12,
	EDynamicMeshSculptBrushType_MAX = 13
};

// Enum MeshModelingTools.EPolyEditCutPlaneOrientation
enum class EPolyEditCutPlaneOrientation : uint8 {
	FaceNormals = 0,
	ViewDirection = 1,
	EPolyEditCutPlaneOrientation_MAX = 2
};

// Enum MeshModelingTools.EPolyEditExtrudeDirection
enum class EPolyEditExtrudeDirection : uint8 {
	SelectionNormal = 0,
	WorldX = 1,
	WorldY = 2,
	WorldZ = 3,
	LocalX = 4,
	LocalY = 5,
	LocalZ = 6,
	EPolyEditExtrudeDirection_MAX = 7
};

// Enum MeshModelingTools.EEditMeshPolygonsToolActions
enum class EEditMeshPolygonsToolActions : uint8 {
	NoAction = 0,
	PlaneCut = 1,
	Extrude = 2,
	Offset = 3,
	Inset = 4,
	Outset = 5,
	Merge = 6,
	Delete = 7,
	CutFaces = 8,
	RecalculateNormals = 9,
	FlipNormals = 10,
	Retriangulate = 11,
	Decompose = 12,
	Disconnect = 13,
	CollapseEdge = 14,
	WeldEdges = 15,
	StraightenEdge = 16,
	FillHole = 17,
	PlanarProjectionUV = 18,
	PokeSingleFace = 19,
	SplitSingleEdge = 20,
	FlipSingleEdge = 21,
	CollapseSingleEdge = 22,
	EEditMeshPolygonsToolActions_MAX = 23
};

// Enum MeshModelingTools.ELocalFrameMode
enum class ELocalFrameMode : uint8 {
	FromObject = 0,
	FromGeometry = 1,
	ELocalFrameMode_MAX = 2
};

// Enum MeshModelingTools.EEditPivotToolActions
enum class EEditPivotToolActions : uint8 {
	NoAction = 0,
	Center = 1,
	Bottom = 2,
	Top = 3,
	Left = 4,
	Right = 5,
	Front = 6,
	Back = 7,
	EEditPivotToolActions_MAX = 8
};

// Enum MeshModelingTools.EEditPivotSnapDragRotationMode
enum class EEditPivotSnapDragRotationMode : uint8 {
	Ignore = 0,
	Align = 1,
	AlignFlipped = 2,
	LastValue = 3,
	EEditPivotSnapDragRotationMode_MAX = 4
};

// Enum MeshModelingTools.EMeshEditingMaterialModes
enum class EMeshEditingMaterialModes : uint8 {
	ExistingMaterial = 0,
	Diffuse = 1,
	Grey = 2,
	Soft = 3,
	TangentNormal = 4,
	Custom = 5,
	EMeshEditingMaterialModes_MAX = 6
};

// Enum MeshModelingTools.ESetMeshMaterialMode
enum class ESetMeshMaterialMode : uint8 {
	KeepOriginal = 0,
	Checkerboard = 1,
	Override = 2,
	ESetMeshMaterialMode_MAX = 3
};

// Enum MeshModelingTools.EMeshFacesColorMode
enum class EMeshFacesColorMode : uint8 {
	None = 0,
	ByGroup = 1,
	ByMaterialID = 2,
	ByUVIsland = 3,
	EMeshFacesColorMode_MAX = 4
};

// Enum MeshModelingTools.EMeshSelectionToolPrimaryMode
enum class EMeshSelectionToolPrimaryMode : uint8 {
	Brush = 0,
	VolumetricBrush = 1,
	AngleFiltered = 2,
	Visible = 3,
	AllConnected = 4,
	AllInGroup = 5,
	ByMaterial = 6,
	ByUVIsland = 7,
	AllWithinAngle = 8,
	EMeshSelectionToolPrimaryMode_MAX = 9
};

// Enum MeshModelingTools.EMeshSelectionToolActions
enum class EMeshSelectionToolActions : uint8 {
	NoAction = 0,
	SelectAll = 1,
	ClearSelection = 2,
	InvertSelection = 3,
	GrowSelection = 4,
	ShrinkSelection = 5,
	ExpandToConnected = 6,
	SelectLargestComponentByTriCount = 7,
	SelectLargestComponentByArea = 8,
	OptimizeSelection = 9,
	DeleteSelected = 10,
	DisconnectSelected = 11,
	SeparateSelected = 12,
	FlipSelected = 13,
	CreateGroup = 14,
	CycleSelectionMode = 15,
	CycleViewMode = 16,
	EMeshSelectionToolActions_MAX = 17
};

// Enum MeshModelingTools.ENonlinearOperationType
enum class ENonlinearOperationType : uint8 {
	Bend = 0,
	Flare = 1,
	Twist = 2,
	ENonlinearOperationType_MAX = 3
};

// Enum MeshModelingTools.EMaterialBoundaryConstraint
enum class EMaterialBoundaryConstraint : uint8 {
	Fixed = 7,
	Refine = 5,
	Free = 1,
	Ignore = 0,
	EMaterialBoundaryConstraint_MAX = 8
};

// Enum MeshModelingTools.EGroupBoundaryConstraint
enum class EGroupBoundaryConstraint : uint8 {
	Fixed = 7,
	Refine = 5,
	Free = 1,
	Ignore = 0,
	EGroupBoundaryConstraint_MAX = 8
};

// Enum MeshModelingTools.EMeshBoundaryConstraint
enum class EMeshBoundaryConstraint : uint8 {
	Fixed = 7,
	Refine = 5,
	Free = 1,
	EMeshBoundaryConstraint_MAX = 8
};

// Enum MeshModelingTools.EOcclusionCalculationUIMode
enum class EOcclusionCalculationUIMode : uint8 {
	GeneralizedWindingNumber = 0,
	RaycastOcclusionSamples = 1,
	EOcclusionCalculationUIMode_MAX = 2
};

// Enum MeshModelingTools.EOcclusionTriangleSamplingUIMode
enum class EOcclusionTriangleSamplingUIMode : uint8 {
	Vertices = 0,
	VerticesAndCentroids = 1,
	EOcclusionTriangleSamplingUIMode_MAX = 2
};

// Enum MeshModelingTools.ESmoothMeshToolSmoothType
enum class ESmoothMeshToolSmoothType : uint8 {
	Iterative = 0,
	BiHarmonic_Cotan = 1,
	ESmoothMeshToolSmoothType_MAX = 2
};

// Enum MeshModelingTools.ETransformMeshesSnapDragRotationMode
enum class ETransformMeshesSnapDragRotationMode : uint8 {
	Ignore = 0,
	Align = 1,
	AlignFlipped = 2,
	LastValue = 3,
	ETransformMeshesSnapDragRotationMode_MAX = 4
};

// Enum MeshModelingTools.ETransformMeshesSnapDragSource
enum class ETransformMeshesSnapDragSource : uint8 {
	ClickPoint = 0,
	Pivot = 1,
	LastValue = 2,
	ETransformMeshesSnapDragSource_MAX = 3
};

// Enum MeshModelingTools.ETransformMeshesTransformMode
enum class ETransformMeshesTransformMode : uint8 {
	SharedGizmo = 0,
	SharedGizmoLocal = 1,
	PerObjectGizmo = 2,
	LastValue = 3,
	ETransformMeshesTransformMode_MAX = 4
};

// ScriptStruct MeshModelingTools.EditPivotTarget
// Size: 0x10 (Inherited: 0x00)
struct FEditPivotTarget {
	struct UTransformProxy* TransformProxy; // 0x00(0x08)
	struct UTransformGizmo* TransformGizmo; // 0x08(0x08)
};

// ScriptStruct MeshModelingTools.TransformMeshesTarget
// Size: 0x10 (Inherited: 0x00)
struct FTransformMeshesTarget {
	struct UTransformProxy* TransformProxy; // 0x00(0x08)
	struct UTransformGizmo* TransformGizmo; // 0x08(0x08)
};

