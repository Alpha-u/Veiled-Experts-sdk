// WidgetBlueprintGeneratedClass GameMapIconTutorialMarker.GameMapIconTutorialMarker_C
// Size: 0x2f8 (Inherited: 0x2f8)
struct UGameMapIconTutorialMarker_C : UPDGameMapIconTutorialMarker {
};

