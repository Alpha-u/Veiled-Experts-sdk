// WidgetBlueprintGeneratedClass GameMapModule.GameMapModule_C
// Size: 0x410 (Inherited: 0x410)
struct UGameMapModule_C : UPDGameMapModule {
};

