// WidgetBlueprintGeneratedClass CustomJoinPopup.CustomJoinPopup_C
// Size: 0x358 (Inherited: 0x320)
struct UCustomJoinPopup_C : UPDCustomJoinPopupUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x320(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x328(0x08)
	struct UImage* IMG_Blinder; // 0x330(0x08)
	struct UImage* IMG_Divider; // 0x338(0x08)
	struct UImage* IMG_InputBg; // 0x340(0x08)
	struct UImage* IMG_PopupBg; // 0x348(0x08)
	struct UImage* IMG_TopDeco; // 0x350(0x08)
};

