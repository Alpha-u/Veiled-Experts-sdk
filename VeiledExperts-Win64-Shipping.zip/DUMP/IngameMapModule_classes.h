// WidgetBlueprintGeneratedClass IngameMapModule.IngameMapModule_C
// Size: 0x518 (Inherited: 0x518)
struct UIngameMapModule_C : UPDIngameMapModule {
};

