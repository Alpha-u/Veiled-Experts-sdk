// UserDefinedEnum ENiagaraBooleanLogicOps.ENiagaraBooleanLogicOps
enum class ENiagaraBooleanLogicOps : uint8 {
	None = 0
};

