// WidgetBlueprintGeneratedClass MailNotificationSlot.MailNotificationSlot_C
// Size: 0x310 (Inherited: 0x2f8)
struct UMailNotificationSlot_C : UPDMailNotificationSlotUI {
	struct UWidgetAnimation* Anim_Appear; // 0x2f8(0x08)
	struct UImage* IMG_SlotBg; // 0x300(0x08)
	struct UImage* IMG_SlotOutline; // 0x308(0x08)
};

