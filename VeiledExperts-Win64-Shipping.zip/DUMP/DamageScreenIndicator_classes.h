// WidgetBlueprintGeneratedClass DamageScreenIndicator.DamageScreenIndicator_C
// Size: 0x3b8 (Inherited: 0x378)
struct UDamageScreenIndicator_C : UPDDamageScreenIndicatorUI {
	struct UWidgetAnimation* Anim_Damage_Left; // 0x378(0x08)
	struct UWidgetAnimation* Anim_Damage_LeftDown; // 0x380(0x08)
	struct UWidgetAnimation* Anim_Damage_Down; // 0x388(0x08)
	struct UWidgetAnimation* Anim_Damage_RightDown; // 0x390(0x08)
	struct UWidgetAnimation* Anim_Damage_Right; // 0x398(0x08)
	struct UWidgetAnimation* Anim_Damage_RightUp; // 0x3a0(0x08)
	struct UWidgetAnimation* Anim_Damage_Up; // 0x3a8(0x08)
	struct UWidgetAnimation* Anim_Damage_LeftUp; // 0x3b0(0x08)
};

