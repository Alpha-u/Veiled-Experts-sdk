// WidgetBlueprintGeneratedClass MatchListItem.MatchListItem_C
// Size: 0x2e8 (Inherited: 0x2e8)
struct UMatchListItem_C : UPDMatchListItem {
};

