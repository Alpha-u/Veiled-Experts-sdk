// BlueprintGeneratedClass BP_ExportWorldBoundary.BP_ExportWorldBoundary_C
// Size: 0x230 (Inherited: 0x228)
struct ABP_ExportWorldBoundary_C : AExportWorldBoundary {
	struct UBoxComponent* BoundaryBox; // 0x228(0x08)
};

