// WidgetBlueprintGeneratedClass MissionScoreStatusBoardPlayerInfo.MissionScoreStatusBoardPlayerInfo_C
// Size: 0x438 (Inherited: 0x410)
struct UMissionScoreStatusBoardPlayerInfo_C : UPDMSStatusBoardPlayerInfo {
	struct UImage* IMG_BottomLine; // 0x410(0x08)
	struct UImage* IMG_Death; // 0x418(0x08)
	struct UImage* IMG_Groggy; // 0x420(0x08)
	struct UImage* IMG_Rescue; // 0x428(0x08)
	struct UImage* IMG_SlotBg_Me; // 0x430(0x08)
};

