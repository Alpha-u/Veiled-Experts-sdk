// BlueprintGeneratedClass BP_AgentVan_001.BP_AgentVan_001_C
// Size: 0x248 (Inherited: 0x220)
struct ABP_AgentVan_001_C : AActor {
	struct UStaticMeshComponent* SM_AgentVan_Logo_02; // 0x220(0x08)
	struct UStaticMeshComponent* SM_LampCeiling_002_03; // 0x228(0x08)
	struct UStaticMeshComponent* SM_LampCeiling_002_02; // 0x230(0x08)
	struct UStaticMeshComponent* SM_Van_001; // 0x238(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x240(0x08)
};

