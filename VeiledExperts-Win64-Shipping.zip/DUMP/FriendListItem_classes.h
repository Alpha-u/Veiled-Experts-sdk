// WidgetBlueprintGeneratedClass FriendListItem.FriendListItem_C
// Size: 0x3f8 (Inherited: 0x3d8)
struct UFriendListItem_C : UPDFriendListItem {
	struct UImage* IMG_Divider; // 0x3d8(0x08)
	struct UImage* IMG_PictureBg; // 0x3e0(0x08)
	struct UImage* IMG_ToolTipBg; // 0x3e8(0x08)
	struct UImage* IMG_UserBg; // 0x3f0(0x08)
};

