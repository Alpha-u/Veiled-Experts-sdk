// BlueprintGeneratedClass BP_WindFarmWallD_001.BP_WindFarmWallD_001_C
// Size: 0x270 (Inherited: 0x220)
struct ABP_WindFarmWallD_001_C : AActor {
	struct UStaticMeshComponent* SM_CautionSign_005; // 0x220(0x08)
	struct UStaticMeshComponent* SM_CautionSign_004; // 0x228(0x08)
	struct UStaticMeshComponent* SM_CautionSign_003; // 0x230(0x08)
	struct UStaticMeshComponent* SM_CautionSign_002; // 0x238(0x08)
	struct UStaticMeshComponent* DF_WindFarmWallD_001_01; // 0x240(0x08)
	struct UStaticMeshComponent* DF_WindFarmWallD_001_04; // 0x248(0x08)
	struct UStaticMeshComponent* DF_WindFarmWallD_001_03; // 0x250(0x08)
	struct UStaticMeshComponent* DF_WindFarmWallD_001_02; // 0x258(0x08)
	struct UStaticMeshComponent* SM_WindFarmWallD_001; // 0x260(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x268(0x08)
};

