// WidgetBlueprintGeneratedClass MailBoxListItem.MailBoxListItem_C
// Size: 0x340 (Inherited: 0x330)
struct UMailBoxListItem_C : UPDMailBoxListItemUI {
	struct UImage* IMG_NormalBg; // 0x330(0x08)
	struct UImage* IMG_ReadBg; // 0x338(0x08)
};

