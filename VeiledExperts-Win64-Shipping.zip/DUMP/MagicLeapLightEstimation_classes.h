// Class MagicLeapLightEstimation.MagicLeapLightingTrackingComponent
// Size: 0xc0 (Inherited: 0xb0)
struct UMagicLeapLightingTrackingComponent : UActorComponent {
	bool UseGlobalAmbience; // 0xb0(0x01)
	bool UseColorTemp; // 0xb1(0x01)
	char pad_B2[0xe]; // 0xb2(0x0e)
};

// Class MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UMagicLeapLightEstimationFunctionLibrary : UBlueprintFunctionLibrary {

	bool IsTrackerValid(); // Function MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary.IsTrackerValid // (None) // @ game+0xffff8008b8ce0000
	bool GetColorTemperatureState(struct FMagicLeapLightEstimationColorTemperatureState& ColorTemperatureState); // Function MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary.GetColorTemperatureState // (None) // @ game+0xffff8008b8ce0020
	bool GetAmbientGlobalState(struct FMagicLeapLightEstimationAmbientGlobalState& GlobalAmbientState); // Function MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary.GetAmbientGlobalState // (None) // @ game+0xffff8008b8ce0018
	void DestroyTracker(); // Function MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary.DestroyTracker // (None) // @ game+0xffff8008b8ceffff
	bool CreateTracker(); // Function MagicLeapLightEstimation.MagicLeapLightEstimationFunctionLibrary.CreateTracker // (None) // @ game+0xffff8008b8ce0000
};

