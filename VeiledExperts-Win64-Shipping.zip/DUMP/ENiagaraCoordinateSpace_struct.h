// UserDefinedEnum ENiagaraCoordinateSpace.ENiagaraCoordinateSpace
enum class ENiagaraCoordinateSpace : uint8 {
	None = 0
};

