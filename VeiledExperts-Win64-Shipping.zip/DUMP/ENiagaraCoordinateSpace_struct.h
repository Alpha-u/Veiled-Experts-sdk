// UserDefinedEnum ENiagaraCoordinateSpace.ENiagaraCoordinateSpace
enum class ENiagaraCoordinateSpace : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ENiagaraCoordinateSpace_MAX = 3
};

