// BlueprintGeneratedClass BP_Forklift_002.BP_Forklift_002_C
// Size: 0x248 (Inherited: 0x220)
struct ABP_Forklift_002_C : AActor {
	struct UBoxComponent* Box1; // 0x220(0x08)
	struct UBoxComponent* Box; // 0x228(0x08)
	struct UStaticMeshComponent* SM_ForkliftCrane_002_W01; // 0x230(0x08)
	struct UStaticMeshComponent* SM_Forklift_002_W01; // 0x238(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x240(0x08)
};

