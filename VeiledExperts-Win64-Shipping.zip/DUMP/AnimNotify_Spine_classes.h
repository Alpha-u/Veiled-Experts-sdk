// BlueprintGeneratedClass AnimNotify_Spine.AnimNotify_Spine_C
// Size: 0xb8 (Inherited: 0xb8)
struct UAnimNotify_Spine_C : UPDFootstepAkAnimNotify {
};

