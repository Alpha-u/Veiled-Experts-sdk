// WidgetBlueprintGeneratedClass MainLobbyInfo.MainLobbyInfo_C
// Size: 0x448 (Inherited: 0x3c8)
struct UMainLobbyInfo_C : UPDLobbyInfoUI {
	struct UPDButton_C* BTN_GradeNone; // 0x3c8(0x08)
	struct UPDButton_C* Btn_Leader; // 0x3d0(0x08)
	struct UPDButton_C* BTN_Leave; // 0x3d8(0x08)
	struct UPDButton_C* Btn_Record; // 0x3e0(0x08)
	struct UImage* IMG_Community; // 0x3e8(0x08)
	struct UImage* IMG_ContextMenu_Bg; // 0x3f0(0x08)
	struct UImage* IMG_ContextMenu_Shadow; // 0x3f8(0x08)
	struct UImage* IMG_GradeNone; // 0x400(0x08)
	struct UImage* IMG_LeaveParty; // 0x408(0x08)
	struct UImage* IMG_MannerToolTipBg; // 0x410(0x08)
	struct UImage* IMG_MannerToolTipOutline; // 0x418(0x08)
	struct UImage* IMG_Register_Disabled; // 0x420(0x08)
	struct UImage* IMG_Register_Normal; // 0x428(0x08)
	struct UImage* IMG_Register_Searching; // 0x430(0x08)
	struct UImage* IMG_ToolTipBg; // 0x438(0x08)
	struct UImage* IMG_ToolTipOutline; // 0x440(0x08)
};

