// WidgetBlueprintGeneratedClass BattleLog.BattleLog_C
// Size: 0x358 (Inherited: 0x348)
struct UBattleLog_C : UPDBattleLogUI {
	struct UWidgetAnimation* FeedbackAni; // 0x348(0x08)
	struct UImage* IMG_Feedback; // 0x350(0x08)
};

