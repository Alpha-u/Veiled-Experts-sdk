// WidgetBlueprintGeneratedClass GameMapIconSpectating.GameMapIconSpectating_C
// Size: 0x318 (Inherited: 0x300)
struct UGameMapIconSpectating_C : UPDGameMapIconSpectatingUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x300(0x08)
	struct UWidgetAnimation* Shooting; // 0x308(0x08)
	struct UImage* IMG_VeiwArea; // 0x310(0x08)

	void Construct(); // Function GameMapIconSpectating.GameMapIconSpectating_C.Construct // (NetReliableNetRequest|Exec|Native|Event|NetResponse|UbergraphFunction|Private|Protected|NetServer|BlueprintEvent|EditorOnly|NetValidate) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_GameMapIconSpectating(int32_t EntryPoint); // Function GameMapIconSpectating.GameMapIconSpectating_C.ExecuteUbergraph_GameMapIconSpectating // (None) // @ game+0xffff80091677ffff
};

