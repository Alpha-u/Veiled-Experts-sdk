// WidgetBlueprintGeneratedClass GameMapIconSpectating.GameMapIconSpectating_C
// Size: 0x318 (Inherited: 0x300)
struct UGameMapIconSpectating_C : UPDGameMapIconSpectatingUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x300(0x08)
	struct UWidgetAnimation* Shooting; // 0x308(0x08)
	struct UImage* IMG_VeiwArea; // 0x310(0x08)

	void Construct(); // Function GameMapIconSpectating.GameMapIconSpectating_C.Construct // (Net|NetReliableNetRequest|Exec|Event|NetResponse|UbergraphFunction|MulticastDelegate|Private|Protected|Delegate|NetServer|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintPure|EditorOnly) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_GameMapIconSpectating(int32_t EntryPoint); // Function GameMapIconSpectating.GameMapIconSpectating_C.ExecuteUbergraph_GameMapIconSpectating // (None) // @ game+0xffff8008b8ceffff
};

