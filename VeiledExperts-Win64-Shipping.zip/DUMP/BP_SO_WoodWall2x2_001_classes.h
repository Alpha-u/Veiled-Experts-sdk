// BlueprintGeneratedClass BP_SO_WoodWall2x2_001.BP_SO_WoodWall2x2_001_C
// Size: 0x300 (Inherited: 0x300)
struct ABP_SO_WoodWall2x2_001_C : APDSplitObject {
};

