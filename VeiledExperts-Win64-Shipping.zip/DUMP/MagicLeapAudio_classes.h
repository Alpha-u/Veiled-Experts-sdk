// Class MagicLeapAudio.MagicLeapAudioFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UMagicLeapAudioFunctionLibrary : UBlueprintFunctionLibrary {

	bool SetOnAudioJackUnpluggedDelegate(struct FDelegate& ResultDelegate); // Function MagicLeapAudio.MagicLeapAudioFunctionLibrary.SetOnAudioJackUnpluggedDelegate // (None) // @ game+0xffff800916770010
	bool SetOnAudioJackPluggedDelegate(struct FDelegate& ResultDelegate); // Function MagicLeapAudio.MagicLeapAudioFunctionLibrary.SetOnAudioJackPluggedDelegate // (None) // @ game+0xffff800916770010
	bool SetMicMute(bool IsMuted); // Function MagicLeapAudio.MagicLeapAudioFunctionLibrary.SetMicMute // (None) // @ game+0xffff800916770001
	bool IsMicMuted(); // Function MagicLeapAudio.MagicLeapAudioFunctionLibrary.IsMicMuted // (None) // @ game+0xffff800916770000
};

