// WidgetBlueprintGeneratedClass FindPartyListItem.FindPartyListItem_C
// Size: 0x410 (Inherited: 0x390)
struct UFindPartyListItem_C : UPDFindPartyListItem {
	struct UPDButton_C* BTN_GradeNone; // 0x390(0x08)
	struct UImage* IMG_Agent_SlotBg; // 0x398(0x08)
	struct UImage* IMG_Divider; // 0x3a0(0x08)
	struct UImage* IMG_Failed_SlotBg; // 0x3a8(0x08)
	struct UImage* IMG_GradeNone; // 0x3b0(0x08)
	struct UImage* IMG_Manner; // 0x3b8(0x08)
	struct UImage* IMG_Medal1; // 0x3c0(0x08)
	struct UImage* IMG_Medal2; // 0x3c8(0x08)
	struct UImage* IMG_Medal3; // 0x3d0(0x08)
	struct UImage* IMG_PictureBg; // 0x3d8(0x08)
	struct UImage* IMG_Ping_Bg; // 0x3e0(0x08)
	struct UImage* IMG_RecruitDone_Bg; // 0x3e8(0x08)
	struct UImage* IMG_RecuritFalied; // 0x3f0(0x08)
	struct UImage* IMG_ToolTipBg; // 0x3f8(0x08)
	struct UImage* IMG_WaitingRecruited; // 0x400(0x08)
	struct UImage* IMG_WaitingRecruited_Bg; // 0x408(0x08)
};

