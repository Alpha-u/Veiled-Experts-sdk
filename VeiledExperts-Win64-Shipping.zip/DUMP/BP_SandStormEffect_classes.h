// BlueprintGeneratedClass BP_SandStormEffect.BP_SandStormEffect_C
// Size: 0x5e8 (Inherited: 0x5c8)
struct ABP_SandStormEffect_C : APDEnvEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5c8(0x08)
	struct UParticleSystemComponent* Speck; // 0x5d0(0x08)
	struct UParticleSystemComponent* Dust; // 0x5d8(0x08)
	struct UParticleSystemComponent* FogVolume; // 0x5e0(0x08)

	void ReceiveTick(float DeltaSeconds); // Function BP_SandStormEffect.BP_SandStormEffect_C.ReceiveTick // (NetReliableNetRequest|Exec|Native|Event|NetResponse|NetMulticast|UbergraphFunction|Public|Protected|Delegate|HasOutParms|NetClient|DLLImport|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_BP_SandStormEffect(int32_t EntryPoint); // Function BP_SandStormEffect.BP_SandStormEffect_C.ExecuteUbergraph_BP_SandStormEffect // (None) // @ game+0xffff8008b8ceffff
};

