// WidgetBlueprintGeneratedClass CommunityPopup.CommunityPopup_C
// Size: 0x460 (Inherited: 0x3f8)
struct UCommunityPopup_C : UPDCommunityPopupUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x3f8(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x400(0x08)
	struct UImage* IMG_Bg; // 0x408(0x08)
	struct UImage* Img_ContentsLine_Top; // 0x410(0x08)
	struct UImage* IMG_ContextMenu_Bg; // 0x418(0x08)
	struct UImage* IMG_ContextMenu_Shadow; // 0x420(0x08)
	struct UImage* IMG_FindPartyMannerToolTipBg; // 0x428(0x08)
	struct UImage* IMG_FindPartyMannerToolTipOutline; // 0x430(0x08)
	struct UImage* IMG_MannerToolTipBg; // 0x438(0x08)
	struct UImage* IMG_MannerToolTipOutline; // 0x440(0x08)
	struct UImage* IMG_ToolTipBg; // 0x448(0x08)
	struct UImage* IMG_ToolTipOutline; // 0x450(0x08)
	struct UImage* IMG_TopBg; // 0x458(0x08)
};

