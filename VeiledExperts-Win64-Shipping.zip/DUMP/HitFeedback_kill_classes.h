// WidgetBlueprintGeneratedClass HitFeedback_kill.HitFeedback_kill_C
// Size: 0x350 (Inherited: 0x340)
struct UHitFeedback_kill_C : UPDHitFeedBackUI {
	struct UWidgetAnimation* Feedback_kill; // 0x340(0x08)
	struct UWidgetAnimation* Feedback; // 0x348(0x08)
};

