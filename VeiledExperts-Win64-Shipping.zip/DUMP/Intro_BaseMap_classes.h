// WidgetBlueprintGeneratedClass Intro_BaseMap.Intro_BaseMap_C
// Size: 0x2e0 (Inherited: 0x2d8)
struct UIntro_BaseMap_C : UPDMatchIntroUI {
	struct UWidgetAnimation* Anim_Intro; // 0x2d8(0x08)
};

