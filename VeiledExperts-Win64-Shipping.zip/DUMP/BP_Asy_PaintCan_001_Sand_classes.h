// BlueprintGeneratedClass BP_Asy_PaintCan_001_Sand.BP_Asy_PaintCan_001_Sand_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_Asy_PaintCan_001_Sand_C : APDAsyncObject {
};

