// WidgetBlueprintGeneratedClass IngameStatusBoard.IngameStatusBoard_C
// Size: 0x478 (Inherited: 0x3f8)
struct UIngameStatusBoard_C : UPDIngameStatusBoardUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct UStatusBoardBlockAll_C* BTN_Community_OFF; // 0x400(0x08)
	struct UStatusBoardBlockFriendly_C* BTN_Community_OFF_Friendly; // 0x408(0x08)
	struct UImage* IMG_AllyTeamCoinIcon; // 0x410(0x08)
	struct UImage* IMG_Assit; // 0x418(0x08)
	struct UImage* IMG_EnemyTeamCoinIcon; // 0x420(0x08)
	struct UImage* IMG_GuideBg2; // 0x428(0x08)
	struct UImage* IMG_InfoBoardBg; // 0x430(0x08)
	struct UImage* IMG_Kill; // 0x438(0x08)
	struct UImage* IMG_Ping; // 0x440(0x08)
	struct UImage* IMG_Point; // 0x448(0x08)
	struct UImage* IMG_RoundBg; // 0x450(0x08)
	struct UImage* IMG_TeamLine; // 0x458(0x08)
	struct UInvalidationBox* InvalidationBox_Anemy; // 0x460(0x08)
	struct UUnKnownMarketUpgradeTooltip_C* StatusBoardUpgradeTooltip; // 0x468(0x08)
	struct UUnKnownMarketTooltip_C* TeamBuffTooltip; // 0x470(0x08)

	void Construct(); // Function IngameStatusBoard.IngameStatusBoard_C.Construct // (NetRequest|Exec|Native|Static|NetMulticast|MulticastDelegate|Protected|Delegate|NetServer|BlueprintPure|EditorOnly|NetValidate) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_IngameStatusBoard(int32_t EntryPoint); // Function IngameStatusBoard.IngameStatusBoard_C.ExecuteUbergraph_IngameStatusBoard // (None) // @ game+0xffff80091677ffff
};

