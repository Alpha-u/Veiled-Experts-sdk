// WidgetBlueprintGeneratedClass KeyGuide_Key.KeyGuide_Key_C
// Size: 0x410 (Inherited: 0x3d8)
struct UKeyGuide_Key_C : UPDKeyGuideKeyIcon {
	struct UImage* IMG_GuideMouseLeft; // 0x3d8(0x08)
	struct UImage* IMG_GuideMouseMiddle; // 0x3e0(0x08)
	struct UImage* IMG_GuideMouseRight; // 0x3e8(0x08)
	struct UImage* IMG_GuideMouseThumb; // 0x3f0(0x08)
	struct UImage* IMG_GuideMouseThumb2; // 0x3f8(0x08)
	struct UImage* IMG_GuideScrollDown; // 0x400(0x08)
	struct UImage* IMG_GuideScrollUp; // 0x408(0x08)
};

