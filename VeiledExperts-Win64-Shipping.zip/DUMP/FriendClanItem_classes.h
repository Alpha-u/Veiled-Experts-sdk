// WidgetBlueprintGeneratedClass FriendClanItem.FriendClanItem_C
// Size: 0x3f0 (Inherited: 0x3a8)
struct UFriendClanItem_C : UPDFriendClanItem {
	struct UImage* IMG_Category_Arrow; // 0x3a8(0x08)
	struct UImage* IMG_Divider; // 0x3b0(0x08)
	struct UImage* IMG_Manner; // 0x3b8(0x08)
	struct UImage* IMG_Medal1; // 0x3c0(0x08)
	struct UImage* IMG_Medal2; // 0x3c8(0x08)
	struct UImage* IMG_Medal3; // 0x3d0(0x08)
	struct UImage* IMG_PictureBg; // 0x3d8(0x08)
	struct UImage* IMG_ToolTipBg; // 0x3e0(0x08)
	struct UImage* IMG_UserBg; // 0x3e8(0x08)
};

