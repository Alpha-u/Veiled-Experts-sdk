// Class CustomMeshComponent.CustomMeshComponent
// Size: 0x450 (Inherited: 0x440)
struct UCustomMeshComponent : UMeshComponent {
	char pad_440[0x10]; // 0x440(0x10)

	bool SetCustomMeshTriangles(struct TArray<struct FCustomMeshTriangle>& Triangles); // Function CustomMeshComponent.CustomMeshComponent.SetCustomMeshTriangles // (None) // @ game+0xffff800916770010
	void ClearCustomMeshTriangles(); // Function CustomMeshComponent.CustomMeshComponent.ClearCustomMeshTriangles // (None) // @ game+0xffff80091677ffff
	void AddCustomMeshTriangles(struct TArray<struct FCustomMeshTriangle>& Triangles); // Function CustomMeshComponent.CustomMeshComponent.AddCustomMeshTriangles // (None) // @ game+0xffff80091677ffff
};

