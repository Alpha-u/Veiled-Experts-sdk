// WidgetBlueprintGeneratedClass Intro_WheatField.Intro_WheatField_C
// Size: 0x310 (Inherited: 0x2d8)
struct UIntro_WheatField_C : UPDMatchIntroUI {
	struct UWidgetAnimation* Anim_Intro; // 0x2d8(0x08)
	struct UImage* IMG_WHEATFIELD_Mission_Fx; // 0x2e0(0x08)
	struct URetainerBox* RB_WHEATFIELD_Mission_GLow; // 0x2e8(0x08)
	struct URetainerBox* RT_WHEATFIELD_MapName_Fx_01; // 0x2f0(0x08)
	struct URetainerBox* RT_WHEATFIELD_MapName_Fx_02; // 0x2f8(0x08)
	struct URetainerBox* RT_WHEATFIELD_Mission_Fx_01; // 0x300(0x08)
	struct URetainerBox* RT_WHEATFIELD_Mission_Fx_02; // 0x308(0x08)
};

