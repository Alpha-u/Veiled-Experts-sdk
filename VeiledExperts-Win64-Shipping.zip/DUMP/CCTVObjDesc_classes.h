// WidgetBlueprintGeneratedClass CCTVObjDesc.CCTVObjDesc_C
// Size: 0x330 (Inherited: 0x320)
struct UCCTVObjDesc_C : UPDCCTVObjDescUI {
	struct UImage* IMG_Desc_Bg; // 0x320(0x08)
	struct UImage* IMG_Desc_Outline; // 0x328(0x08)
};

