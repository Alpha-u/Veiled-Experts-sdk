// WidgetBlueprintGeneratedClass IngameEscapePlayerPopupUI.IngameEscapePlayerPopupUI_C
// Size: 0x358 (Inherited: 0x340)
struct UIngameEscapePlayerPopupUI_C : UPDOKCancelPopupUI {
	struct UImage* Img_BgBox; // 0x340(0x08)
	struct UImage* IMG_Contants_BG; // 0x348(0x08)
	struct UImage* IMG_Contants_Deco; // 0x350(0x08)
};

