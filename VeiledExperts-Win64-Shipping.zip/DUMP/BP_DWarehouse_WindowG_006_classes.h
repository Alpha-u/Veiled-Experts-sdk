// BlueprintGeneratedClass BP_DWarehouse_WindowG_006.BP_DWarehouse_WindowG_006_C
// Size: 0x738 (Inherited: 0x728)
struct ABP_DWarehouse_WindowG_006_C : APDDynamicObject {
	struct UBoxComponent* Box; // 0x728(0x08)
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x730(0x08)
};

