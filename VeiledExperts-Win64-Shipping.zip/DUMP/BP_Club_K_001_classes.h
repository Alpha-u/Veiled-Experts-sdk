// BlueprintGeneratedClass BP_Club_K_001.BP_Club_K_001_C
// Size: 0x26c (Inherited: 0x220)
struct ABP_Club_K_001_C : AActor {
	struct UStaticMeshComponent* SM_Door_R_001; // 0x220(0x08)
	struct UStaticMeshComponent* SM_Door_L_001; // 0x228(0x08)
	struct UStaticMeshComponent* SM_Club_K_001_06; // 0x230(0x08)
	struct UStaticMeshComponent* StaticMeshComponent2; // 0x238(0x08)
	struct UStaticMeshComponent* SM_ContainerMiissileSystem_12; // 0x240(0x08)
	struct UStaticMeshComponent* StaticMeshComponent0; // 0x248(0x08)
	struct UStaticMeshComponent* SM_Container_001_04; // 0x250(0x08)
	struct USceneComponent* SharedRoot; // 0x258(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x260(0x08)
	float Rotation; // 0x268(0x04)

	void UserConstructionScript(); // Function BP_Club_K_001.BP_Club_K_001_C.UserConstructionScript // (Net|NetReliableNetRequest|Exec|Native|Event|NetResponse|NetMulticast|MulticastDelegate|Private|NetServer|HasOutParms|HasDefaults|DLLImport|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
};

