// WidgetBlueprintGeneratedClass MissionListItem.MissionListItem_C
// Size: 0x328 (Inherited: 0x308)
struct UMissionListItem_C : UPDMissionListItemUI {
	struct UImage* IMG_CompleteBg; // 0x308(0x08)
	struct UImage* IMG_CompleteDeco; // 0x310(0x08)
	struct UImage* IMG_SlotDeco_01; // 0x318(0x08)
	struct UImage* IMG_SlotDeco_02; // 0x320(0x08)
};

