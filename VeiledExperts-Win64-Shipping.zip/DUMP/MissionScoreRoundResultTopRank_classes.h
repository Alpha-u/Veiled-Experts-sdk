// WidgetBlueprintGeneratedClass MissionScoreRoundResultTopRank.MissionScoreRoundResultTopRank_C
// Size: 0x368 (Inherited: 0x350)
struct UMissionScoreRoundResultTopRank_C : UPDMSRoundResultTopRank {
	struct UImage* IMG_RankBack_2; // 0x350(0x08)
	struct UImage* IMG_RankBack_3; // 0x358(0x08)
	struct UImage* IMG_RankBack_4; // 0x360(0x08)
};

