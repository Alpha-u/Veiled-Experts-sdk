// WidgetBlueprintGeneratedClass GameMapIconSafeZoneDrawer.GameMapIconSafeZoneDrawer_C
// Size: 0x330 (Inherited: 0x328)
struct UGameMapIconSafeZoneDrawer_C : UPDGameMapIconSafeZoneDrawer {
	struct UImage* Image_15; // 0x328(0x08)
};

