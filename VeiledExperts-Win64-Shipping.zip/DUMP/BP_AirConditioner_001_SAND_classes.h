// BlueprintGeneratedClass BP_AirConditioner_001_SAND.BP_AirConditioner_001_SAND_C
// Size: 0x388 (Inherited: 0x370)
struct ABP_AirConditioner_001_SAND_C : APDPropActor {
	struct UStaticMeshComponent* SM_AirPropeller_001; // 0x370(0x08)
	struct UStaticMeshComponent* SM_AirConditioner_001; // 0x378(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x380(0x08)
};

