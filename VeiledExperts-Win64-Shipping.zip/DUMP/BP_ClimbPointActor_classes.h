// BlueprintGeneratedClass BP_ClimbPointActor.BP_ClimbPointActor_C
// Size: 0x2a8 (Inherited: 0x2a8)
struct ABP_ClimbPointActor_C : ABP_ClimbableActor_C {

	void UserConstructionScript(); // Function BP_ClimbPointActor.BP_ClimbPointActor_C.UserConstructionScript // (NetReliableNetRequest|Event|NetResponse|NetMulticast|UbergraphFunction|MulticastDelegate|Private|NetServer|HasOutParms|HasDefaults|DLLImport|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
};

