// WidgetBlueprintGeneratedClass 3DIndicator.3DIndicator_C
// Size: 0x340 (Inherited: 0x338)
struct U3DIndicator_C : UPD3DIndicatorUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x338(0x08)

	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function 3DIndicator.3DIndicator_C.Tick // (Net|NetReliableNetRequest|Native|Static|DLLImport|BlueprintCallable|EditorOnly|Const) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_3DIndicator(int32_t EntryPoint); // Function 3DIndicator.3DIndicator_C.ExecuteUbergraph_3DIndicator // (None) // @ game+0xffff8008b8ceffff
};

