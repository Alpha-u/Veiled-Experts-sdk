// WidgetBlueprintGeneratedClass 3DIndicator.3DIndicator_C
// Size: 0x340 (Inherited: 0x338)
struct U3DIndicator_C : UPD3DIndicatorUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x338(0x08)

	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function 3DIndicator.3DIndicator_C.Tick // (NetRequest|Exec|Event|Static|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|EditorOnly|NetValidate) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_3DIndicator(int32_t EntryPoint); // Function 3DIndicator.3DIndicator_C.ExecuteUbergraph_3DIndicator // (None) // @ game+0xffff80091677ffff
};

