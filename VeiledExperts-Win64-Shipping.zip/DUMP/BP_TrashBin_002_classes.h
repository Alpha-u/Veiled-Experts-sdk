// BlueprintGeneratedClass BP_TrashBin_002.BP_TrashBin_002_C
// Size: 0x23c (Inherited: 0x220)
struct ABP_TrashBin_002_C : AActor {
	struct UStaticMeshComponent* SM_TrashBin_002_01; // 0x220(0x08)
	struct UStaticMeshComponent* SM_TrashBin_002; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	float Cap; // 0x238(0x04)

	void UserConstructionScript(); // Function BP_TrashBin_002.BP_TrashBin_002_C.UserConstructionScript // (NetRequest|Native|MulticastDelegate|Public|Delegate|NetClient|BlueprintCallable) // @ game+0xffff80091677ffff
};

