// Enum AssetTags.ECollectionScriptingShareType
enum class ECollectionScriptingShareType : uint8 {
	None = 0,
	None = 0
};

