// WidgetBlueprintGeneratedClass ArmorGaugeDetail.ArmorGaugeDetail_C
// Size: 0x5d0 (Inherited: 0x5d0)
struct UArmorGaugeDetail_C : UPDArmorGaugeDetail {
};

