// WidgetBlueprintGeneratedClass IngameMap.IngameMap_C
// Size: 0x5f0 (Inherited: 0x530)
struct UIngameMap_C : UPDIngameMapUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x530(0x08)
	struct UWidgetAnimation* AniWCount; // 0x538(0x08)
	struct UWidgetAnimation* AniWDefault; // 0x540(0x08)
	struct UWidgetAnimation* AniWCountStart; // 0x548(0x08)
	struct UWidgetAnimation* AniWTimerStart; // 0x550(0x08)
	struct UWidgetAnimation* AllyPing_Old; // 0x558(0x08)
	struct UWidgetAnimation* MissionPing_Old; // 0x560(0x08)
	struct UWidgetAnimation* AllyPing; // 0x568(0x08)
	struct UWidgetAnimation* MissionPing; // 0x570(0x08)
	struct UImage* IMG_Back; // 0x578(0x08)
	struct UImage* IMG_BadgeBg; // 0x580(0x08)
	struct UImage* IMG_BadgeOutline; // 0x588(0x08)
	struct UImage* IMG_GuideBg; // 0x590(0x08)
	struct UImage* IMG_Jamming; // 0x598(0x08)
	struct UImage* IMG_MapNameBg; // 0x5a0(0x08)
	struct UImage* IMG_Mouse_C; // 0x5a8(0x08)
	struct UImage* IMG_Mouse_L; // 0x5b0(0x08)
	struct UImage* IMG_Mouse_R; // 0x5b8(0x08)
	struct UImage* IMG_Mouse_R_2; // 0x5c0(0x08)
	struct UImage* IMG_Mouse_R_3; // 0x5c8(0x08)
	struct UImage* IMG_Mouse_R_4; // 0x5d0(0x08)
	struct UImage* IMG_Mouse_R_5; // 0x5d8(0x08)
	struct UImage* IMG_Mouse_R_6; // 0x5e0(0x08)
	struct UImage* IMG_Mouse_WD; // 0x5e8(0x08)

	void Construct(); // Function IngameMap.IngameMap_C.Construct // (Net|Exec|Event|NetResponse|Static|NetMulticast|Protected|Delegate|NetServer|HasOutParms|DLLImport|BlueprintCallable|BlueprintPure|EditorOnly|Const) // @ game+0xffff8008b8ceffff
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function IngameMap.IngameMap_C.Tick // (Exec|Event|NetResponse|Static|NetMulticast|Protected|Delegate|NetServer|HasOutParms|DLLImport|BlueprintCallable|BlueprintPure|EditorOnly|Const) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_IngameMap(int32_t EntryPoint); // Function IngameMap.IngameMap_C.ExecuteUbergraph_IngameMap // (None) // @ game+0xffff8008b8ceffff
};

