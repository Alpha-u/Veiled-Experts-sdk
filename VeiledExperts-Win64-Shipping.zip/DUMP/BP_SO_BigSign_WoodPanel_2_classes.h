// BlueprintGeneratedClass BP_SO_BigSign_WoodPanel_2.BP_SO_BigSign_WoodPanel_1_C
// Size: 0x300 (Inherited: 0x300)
struct ABP_SO_BigSign_WoodPanel_1_C : APDSplitObject {
};

