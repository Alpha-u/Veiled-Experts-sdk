// BlueprintGeneratedClass Merge_BP_Small_Warehouse_002_07_ExteriorProps1.Merge_BP_Small_Warehouse_002_07_ExteriorProps1_C
// Size: 0x290 (Inherited: 0x220)
struct AMerge_BP_Small_Warehouse_002_07_ExteriorProps1_C : AActor {
	struct UStaticMeshComponent* SM_ShipW_WindowDeco_004; // 0x220(0x08)
	struct UStaticMeshComponent* SM_MERGED_WarehousePipe_002; // 0x228(0x08)
	struct UStaticMeshComponent* SM_CCTV_001; // 0x230(0x08)
	struct UStaticMeshComponent* SM_MERGED_WarehousePipe_001; // 0x238(0x08)
	struct UBoxComponent* Parkour_Volume; // 0x240(0x08)
	struct UStaticMeshComponent* SM_Frame_008; // 0x248(0x08)
	struct UStaticMeshComponent* SM_Frame_007; // 0x250(0x08)
	struct UStaticMeshComponent* SM_Rackshield_005; // 0x258(0x08)
	struct UStaticMeshComponent* SM_Rackshield_004; // 0x260(0x08)
	struct UStaticMeshComponent* Sm_Warehouse_Frame_Door_004; // 0x268(0x08)
	struct UStaticMeshComponent* SM_WallWire_08; // 0x270(0x08)
	struct UStaticMeshComponent* SM_WallSwitch_05; // 0x278(0x08)
	struct UStaticMeshComponent* Sm_Warehouse_Frame_Door_001; // 0x280(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x288(0x08)
};

