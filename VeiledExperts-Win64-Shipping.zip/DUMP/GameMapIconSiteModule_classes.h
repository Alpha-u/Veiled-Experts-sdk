// WidgetBlueprintGeneratedClass GameMapIconSiteModule.GameMapIconSiteModule_C
// Size: 0x340 (Inherited: 0x338)
struct UGameMapIconSiteModule_C : UPDGameMapIconDemolition {
	struct UWidgetAnimation* SiteInteraction; // 0x338(0x08)
};

