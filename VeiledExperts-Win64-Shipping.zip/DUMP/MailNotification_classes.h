// WidgetBlueprintGeneratedClass MailNotification.MailNotification_C
// Size: 0x2e8 (Inherited: 0x2e8)
struct UMailNotification_C : UPDMailNotificationUI {
};

