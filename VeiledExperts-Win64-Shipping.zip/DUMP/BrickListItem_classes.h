// WidgetBlueprintGeneratedClass BrickListItem.BrickListItem_C
// Size: 0x308 (Inherited: 0x308)
struct UBrickListItem_C : UPDBrickListItem {
};

