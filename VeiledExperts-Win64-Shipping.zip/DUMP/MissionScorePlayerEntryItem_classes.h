// WidgetBlueprintGeneratedClass MissionScorePlayerEntryItem.MissionScorePlayerEntryItem_C
// Size: 0x3d0 (Inherited: 0x378)
struct UMissionScorePlayerEntryItem_C : UPDMissionScorePlayerEntryItem {
	struct UWidgetAnimation* AddScore_6; // 0x378(0x08)
	struct UWidgetAnimation* AddScore_5; // 0x380(0x08)
	struct UWidgetAnimation* AddScore_4; // 0x388(0x08)
	struct UWidgetAnimation* AddScore_3; // 0x390(0x08)
	struct UWidgetAnimation* AddScore_2; // 0x398(0x08)
	struct UImage* IMG_bronze; // 0x3a0(0x08)
	struct UImage* IMG_Gold; // 0x3a8(0x08)
	struct UImage* IMG_Groggy; // 0x3b0(0x08)
	struct UImage* IMG_Juggernaut; // 0x3b8(0x08)
	struct UImage* IMG_None; // 0x3c0(0x08)
	struct UImage* IMG_Silver; // 0x3c8(0x08)
};

