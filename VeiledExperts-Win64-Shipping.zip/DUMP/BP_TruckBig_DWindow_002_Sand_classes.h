// BlueprintGeneratedClass BP_TruckBig_DWindow_002_Sand.BP_TruckBig_DWindow_002_Sand_C
// Size: 0x738 (Inherited: 0x728)
struct ABP_TruckBig_DWindow_002_Sand_C : APDDynamicObject {
	struct UBoxComponent* Box; // 0x728(0x08)
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x730(0x08)
};

