// WidgetBlueprintGeneratedClass Interaction_ItemInfo.Interaction_ItemInfo_C
// Size: 0x310 (Inherited: 0x300)
struct UInteraction_ItemInfo_C : UPDAutoFarmingLogItem {
	struct UWidgetAnimation* AniStart; // 0x300(0x08)
	struct UWidgetAnimation* AniEnd; // 0x308(0x08)
};

