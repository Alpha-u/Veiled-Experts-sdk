// WidgetBlueprintGeneratedClass KeyGuide_Desc.KeyGuide_Desc_C
// Size: 0x398 (Inherited: 0x398)
struct UKeyGuide_Desc_C : UPDKeyGuideKeyDesc {
};

