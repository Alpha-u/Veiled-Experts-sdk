// WidgetBlueprintGeneratedClass Intro_Bridge.Intro_Bridge_C
// Size: 0x310 (Inherited: 0x2d8)
struct UIntro_Bridge_C : UPDMatchIntroUI {
	struct UWidgetAnimation* Anim_Intro; // 0x2d8(0x08)
	struct UImage* IMG_BRIDGE_Mission_Fx; // 0x2e0(0x08)
	struct URetainerBox* RB_BRIDGE_Mission_GLow; // 0x2e8(0x08)
	struct URetainerBox* RT_BRIDGE_MapName_Fx_01; // 0x2f0(0x08)
	struct URetainerBox* RT_BRIDGE_MapName_Fx_02; // 0x2f8(0x08)
	struct URetainerBox* RT_BRIDGE_Mission_Fx_01; // 0x300(0x08)
	struct URetainerBox* RT_BRIDGE_Mission_Fx_02; // 0x308(0x08)
};

