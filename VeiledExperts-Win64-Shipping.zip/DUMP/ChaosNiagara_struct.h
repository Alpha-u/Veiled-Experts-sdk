// Enum ChaosNiagara.ELocationZToSpawnEnum
enum class ELocationZToSpawnEnum : uint8 {
	None = 0,
	None = 0
};

// Enum ChaosNiagara.ELocationYToSpawnEnum
enum class ELocationYToSpawnEnum : uint8 {
	None = 0,
	None = 0
};

// Enum ChaosNiagara.ELocationXToSpawnEnum
enum class ELocationXToSpawnEnum : uint8 {
	None = 0,
	None = 0
};

// Enum ChaosNiagara.ELocationFilteringModeEnum
enum class ELocationFilteringModeEnum : uint8 {
	None = 0,
	None = 0
};

// Enum ChaosNiagara.EDataSourceTypeEnum
enum class EDataSourceTypeEnum : uint8 {
	None = 0,
	None = 0
};

// Enum ChaosNiagara.EDebugTypeEnum
enum class EDebugTypeEnum : uint8 {
	None = 0,
	None = 0
};

// Enum ChaosNiagara.ERandomVelocityGenerationTypeEnum
enum class ERandomVelocityGenerationTypeEnum : uint8 {
	None = 0,
	None = 0
};

// Enum ChaosNiagara.EDataSortTypeEnum
enum class EDataSortTypeEnum : uint8 {
	None = 0,
	None = 0
};

// ScriptStruct ChaosNiagara.ChaosDestructionEvent
// Size: 0x44 (Inherited: 0x00)
struct FChaosDestructionEvent {
	struct FVector Position; // 0x00(0x0c)
	struct FVector Normal; // 0x0c(0x0c)
	struct FVector Velocity; // 0x18(0x0c)
	struct FVector AngularVelocity; // 0x24(0x0c)
	float ExtentMin; // 0x30(0x04)
	float ExtentMax; // 0x34(0x04)
	int32_t ParticleID; // 0x38(0x04)
	float Time; // 0x3c(0x04)
	int32_t Type; // 0x40(0x04)
};

