// BlueprintGeneratedClass BP_AsyDS_Cardboard_007_Sand.BP_AsyDS_Cardboard_007_Sand_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_AsyDS_Cardboard_007_Sand_C : APDAsyncObjectDestroyed {
};

