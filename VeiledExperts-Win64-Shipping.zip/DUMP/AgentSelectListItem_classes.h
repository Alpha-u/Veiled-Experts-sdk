// WidgetBlueprintGeneratedClass AgentSelectListItem.AgentSelectListItem_C
// Size: 0x310 (Inherited: 0x308)
struct UAgentSelectListItem_C : UPDAgentSelectListItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x308(0x08)

	void BP_OnEntryReleased(); // Function AgentSelectListItem.AgentSelectListItem_C.BP_OnEntryReleased // (NetReliableExec|Native|Static|UbergraphFunction|MulticastDelegate|NetServer|HasOutParms|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff80091677ffff
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function AgentSelectListItem.AgentSelectListItem_C.BP_OnItemExpansionChanged // (NetRequest|Exec|Native|Static|UbergraphFunction|MulticastDelegate|NetServer|HasOutParms|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff80091677ffff
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function AgentSelectListItem.AgentSelectListItem_C.BP_OnItemSelectionChanged // (NetRequest|Exec|Native|Static|UbergraphFunction|MulticastDelegate|NetServer|HasOutParms|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_AgentSelectListItem(int32_t EntryPoint); // Function AgentSelectListItem.AgentSelectListItem_C.ExecuteUbergraph_AgentSelectListItem // (None) // @ game+0xffff80091677ffff
};

