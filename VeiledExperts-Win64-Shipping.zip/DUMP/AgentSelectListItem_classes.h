// WidgetBlueprintGeneratedClass AgentSelectListItem.AgentSelectListItem_C
// Size: 0x310 (Inherited: 0x308)
struct UAgentSelectListItem_C : UPDAgentSelectListItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x308(0x08)

	void BP_OnEntryReleased(); // Function AgentSelectListItem.AgentSelectListItem_C.BP_OnEntryReleased // (Net|NetReliableExec|Native|NetResponse|Static|NetMulticast|MulticastDelegate|Public|Private|Protected|Delegate|HasOutParms|HasDefaults|BlueprintCallable|EditorOnly|NetValidate) // @ game+0xffff8008b8ceffff
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function AgentSelectListItem.AgentSelectListItem_C.BP_OnItemExpansionChanged // (Net|NetRequest|Exec|Event|Static|MulticastDelegate|Public|Private|Protected|Delegate|HasOutParms|HasDefaults|BlueprintCallable|EditorOnly|NetValidate) // @ game+0xffff8008b8ceffff
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function AgentSelectListItem.AgentSelectListItem_C.BP_OnItemSelectionChanged // (NetRequest|NetResponse|NetMulticast|UbergraphFunction|Private|Delegate|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_AgentSelectListItem(int32_t EntryPoint); // Function AgentSelectListItem.AgentSelectListItem_C.ExecuteUbergraph_AgentSelectListItem // (None) // @ game+0xffff8008b8ceffff
};

