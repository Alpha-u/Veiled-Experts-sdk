// ScriptStruct MagicLeapImageTracker.MagicLeapImageTrackerTarget
// Size: 0xb0 (Inherited: 0x00)
struct FMagicLeapImageTrackerTarget {
	char pad_0[0xb0]; // 0x00(0xb0)
};

