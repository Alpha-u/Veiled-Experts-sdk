// BlueprintGeneratedClass BP_BrokenWood_001_04.BP_BrokenWood_001_04_C
// Size: 0x730 (Inherited: 0x728)
struct ABP_BrokenWood_001_04_C : APDDynamicObject {
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x728(0x08)
};

