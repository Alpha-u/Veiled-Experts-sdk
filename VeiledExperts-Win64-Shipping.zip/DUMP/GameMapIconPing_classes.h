// WidgetBlueprintGeneratedClass GameMapIconPing.GameMapIconPing_C
// Size: 0x328 (Inherited: 0x318)
struct UGameMapIconPing_C : UPDGameMapIconPing {
	struct UWidgetAnimation* PingHovered; // 0x318(0x08)
	struct UWidgetAnimation* PingStart; // 0x320(0x08)
};

