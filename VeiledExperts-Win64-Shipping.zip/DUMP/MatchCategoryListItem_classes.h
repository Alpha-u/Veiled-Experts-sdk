// WidgetBlueprintGeneratedClass MatchCategoryListItem.MatchCategoryListItem_C
// Size: 0x2f0 (Inherited: 0x2e8)
struct UMatchCategoryListItem_C : UPDMatchCategoryListItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e8(0x08)

	void BP_OnEntryReleased(); // Function MatchCategoryListItem.MatchCategoryListItem_C.BP_OnEntryReleased // (Net|NetReliableNetRequest|Event|Static|NetMulticast|Private|Delegate|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff8008b8ceffff
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function MatchCategoryListItem.MatchCategoryListItem_C.BP_OnItemExpansionChanged // (Exec|Event|Static|NetMulticast|Private|Delegate|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff8008b8ceffff
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function MatchCategoryListItem.MatchCategoryListItem_C.BP_OnItemSelectionChanged // (NetReliableNetRequest|Event|Static|NetMulticast|Private|Delegate|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_MatchCategoryListItem(int32_t EntryPoint); // Function MatchCategoryListItem.MatchCategoryListItem_C.ExecuteUbergraph_MatchCategoryListItem // (None) // @ game+0xffff8008b8ceffff
};

