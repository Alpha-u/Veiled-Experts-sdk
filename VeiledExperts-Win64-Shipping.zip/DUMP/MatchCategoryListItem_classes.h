// WidgetBlueprintGeneratedClass MatchCategoryListItem.MatchCategoryListItem_C
// Size: 0x2f0 (Inherited: 0x2e8)
struct UMatchCategoryListItem_C : UPDMatchCategoryListItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e8(0x08)

	void BP_OnEntryReleased(); // Function MatchCategoryListItem.MatchCategoryListItem_C.BP_OnEntryReleased // (Net|NetRequest|NetResponse|UbergraphFunction|MulticastDelegate|Private|Protected|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff80091677ffff
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function MatchCategoryListItem.MatchCategoryListItem_C.BP_OnItemExpansionChanged // (Net|NetReliableExec|NetResponse|UbergraphFunction|MulticastDelegate|Private|Protected|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff80091677ffff
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function MatchCategoryListItem.MatchCategoryListItem_C.BP_OnItemSelectionChanged // (Net|Exec|NetResponse|UbergraphFunction|MulticastDelegate|Private|Protected|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_MatchCategoryListItem(int32_t EntryPoint); // Function MatchCategoryListItem.MatchCategoryListItem_C.ExecuteUbergraph_MatchCategoryListItem // (None) // @ game+0xffff80091677ffff
};

