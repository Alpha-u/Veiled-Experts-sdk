// UserDefinedEnum ENiagaraRandomnessMode.ENiagaraRandomnessMode
enum class ENiagaraRandomnessMode : uint8 {
	None = 0
};

