// Enum GameplayTasks.ETaskResourceOverlapPolicy
enum class ETaskResourceOverlapPolicy : uint8 {
	None = 0,
	None = 0
};

// Enum GameplayTasks.EGameplayTaskState
enum class EGameplayTaskState : uint8 {
	None = 0,
	None = 0
};

// Enum GameplayTasks.EGameplayTaskRunResult
enum class EGameplayTaskRunResult : uint8 {
	None = 0,
	None = 0
};

// ScriptStruct GameplayTasks.GameplayResourceSet
// Size: 0x02 (Inherited: 0x00)
struct FGameplayResourceSet {
	char pad_0[0x2]; // 0x00(0x02)
};

