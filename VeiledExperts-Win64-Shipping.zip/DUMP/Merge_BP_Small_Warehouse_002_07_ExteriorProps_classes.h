// BlueprintGeneratedClass Merge_BP_Small_Warehouse_002_07_ExteriorProps.Merge_BP_Small_Warehouse_002_07_ExteriorProps_C
// Size: 0x258 (Inherited: 0x220)
struct AMerge_BP_Small_Warehouse_002_07_ExteriorProps_C : AActor {
	struct UStaticMeshComponent* SM_ShipW_WindowDeco_003; // 0x220(0x08)
	struct UStaticMeshComponent* SM_CCTV_002; // 0x228(0x08)
	struct UStaticMeshComponent* SM_Frame_0010; // 0x230(0x08)
	struct UStaticMeshComponent* SM_Frame_009; // 0x238(0x08)
	struct UStaticMeshComponent* SM_RollShutter_004; // 0x240(0x08)
	struct UStaticMeshComponent* SM_RollShutter_001; // 0x248(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x250(0x08)
};

