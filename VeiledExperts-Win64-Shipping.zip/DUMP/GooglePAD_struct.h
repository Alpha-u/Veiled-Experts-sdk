// Enum GooglePAD.EGooglePADCellularDataConfirmStatus
enum class EGooglePADCellularDataConfirmStatus : uint8 {
	None = 0,
	None = 0
};

// Enum GooglePAD.EGooglePADStorageMethod
enum class EGooglePADStorageMethod : uint8 {
	None = 0,
	None = 0
};

// Enum GooglePAD.EGooglePADDownloadStatus
enum class EGooglePADDownloadStatus : uint8 {
	None = 0,
	None = 0
};

// Enum GooglePAD.EGooglePADErrorCode
enum class EGooglePADErrorCode : uint8 {
	None = 0,
	None = 0
};

