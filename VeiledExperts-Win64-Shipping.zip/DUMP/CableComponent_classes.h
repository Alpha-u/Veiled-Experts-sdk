// Class CableComponent.CableActor
// Size: 0x228 (Inherited: 0x220)
struct ACableActor : AActor {
	struct UCableComponent* CableComponent; // 0x220(0x08)
};

// Class CableComponent.CableComponent
// Size: 0x4d0 (Inherited: 0x440)
struct UCableComponent : UMeshComponent {
	bool bAttachStart; // 0x438(0x01)
	bool bAttachEnd; // 0x439(0x01)
	struct FComponentReference AttachEndTo; // 0x440(0x28)
	struct FName AttachEndToSocketName; // 0x468(0x08)
	struct FVector EndLocation; // 0x470(0x0c)
	float CableLength; // 0x47c(0x04)
	int32_t NumSegments; // 0x480(0x04)
	float SubstepTime; // 0x484(0x04)
	int32_t SolverIterations; // 0x488(0x04)
	bool bEnableStiffness; // 0x48c(0x01)
	bool bEnableCollision; // 0x48d(0x01)
	float CollisionFriction; // 0x490(0x04)
	struct FVector CableForce; // 0x494(0x0c)
	float CableGravityScale; // 0x4a0(0x04)
	float CableWidth; // 0x4a4(0x04)
	int32_t NumSides; // 0x4a8(0x04)
	float TileMaterial; // 0x4ac(0x04)
	char pad_4B0[0x20]; // 0x4b0(0x20)

	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndToComponent // (None) // @ game+0xffff80091677ffff
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndTo // (None) // @ game+0xffff80091677ffff
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Function CableComponent.CableComponent.GetCableParticleLocations // (None) // @ game+0xffff80091677ffff
	struct USceneComponent* GetAttachedComponent(); // Function CableComponent.CableComponent.GetAttachedComponent // (None) // @ game+0xffff800916770000
	struct AActor* GetAttachedActor(); // Function CableComponent.CableComponent.GetAttachedActor // (None) // @ game+0xffff800916770000
};

