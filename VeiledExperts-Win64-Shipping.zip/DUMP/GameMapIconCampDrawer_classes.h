// WidgetBlueprintGeneratedClass GameMapIconCampDrawer.GameMapIconCampDrawer_C
// Size: 0x390 (Inherited: 0x390)
struct UGameMapIconCampDrawer_C : UPDGameMapIconCampDrawer {
};

