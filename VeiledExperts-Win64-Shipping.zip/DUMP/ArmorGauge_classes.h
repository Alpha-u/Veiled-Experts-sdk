// WidgetBlueprintGeneratedClass ArmorGauge.ArmorGauge_C
// Size: 0x520 (Inherited: 0x520)
struct UArmorGauge_C : UPDArmorGauge {
};

