// BlueprintGeneratedClass BP_NewTruckBig_001.BP_NewTruckBig_001_C
// Size: 0x260 (Inherited: 0x220)
struct ABP_NewTruckBig_001_C : AActor {
	struct UBoxComponent* Parkour_Volume_03; // 0x220(0x08)
	struct UChildActorComponent* BP_TruckBig_Window_005; // 0x228(0x08)
	struct UChildActorComponent* BP_TruckBig_Window_004; // 0x230(0x08)
	struct UChildActorComponent* BP_TruckBig_Window_003; // 0x238(0x08)
	struct UChildActorComponent* BP_TruckBig_Window_002; // 0x240(0x08)
	struct UChildActorComponent* BP_TruckBig_Window_001; // 0x248(0x08)
	struct UStaticMeshComponent* SM_NewTruck_001; // 0x250(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x258(0x08)
};

