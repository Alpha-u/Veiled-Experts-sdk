// WidgetBlueprintGeneratedClass CustomizeLeptonListItem.CustomizeLeptonListItem_C
// Size: 0x398 (Inherited: 0x368)
struct UCustomizeLeptonListItem_C : UPDCustomizeLeptonListItem {
	struct UImage* IMG_Empty_BottomBg; // 0x368(0x08)
	struct UImage* IMG_Empty_CostBg; // 0x370(0x08)
	struct UImage* IMG_Empty_Shadow; // 0x378(0x08)
	struct UImage* IMG_Empty_SlotBg; // 0x380(0x08)
	struct UImage* IMG_Slot_Bg; // 0x388(0x08)
	struct UImage* IMG_Slot_Shadow; // 0x390(0x08)
};

