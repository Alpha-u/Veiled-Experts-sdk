// Class GeometryCache.GeometryCache
// Size: 0x68 (Inherited: 0x28)
struct UGeometryCache : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct UMaterialInterface*> Materials; // 0x30(0x10)
	struct TArray<struct UGeometryCacheTrack*> Tracks; // 0x40(0x10)
	char pad_50[0x10]; // 0x50(0x10)
	int32_t StartFrame; // 0x60(0x04)
	int32_t EndFrame; // 0x64(0x04)
};

// Class GeometryCache.GeometryCacheActor
// Size: 0x228 (Inherited: 0x220)
struct AGeometryCacheActor : AActor {
	struct UGeometryCacheComponent* GeometryCacheComponent; // 0x220(0x08)

	struct UGeometryCacheComponent* GetGeometryCacheComponent(); // Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent // (None) // @ game+0xffff800916770000
};

// Class GeometryCache.GeometryCacheCodecBase
// Size: 0x38 (Inherited: 0x28)
struct UGeometryCacheCodecBase : UObject {
	struct TArray<int32_t> TopologyRanges; // 0x28(0x10)
};

// Class GeometryCache.GeometryCacheCodecRaw
// Size: 0x40 (Inherited: 0x38)
struct UGeometryCacheCodecRaw : UGeometryCacheCodecBase {
	int32_t DummyProperty; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class GeometryCache.GeometryCacheCodecV1
// Size: 0x40 (Inherited: 0x38)
struct UGeometryCacheCodecV1 : UGeometryCacheCodecBase {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class GeometryCache.GeometryCacheComponent
// Size: 0x490 (Inherited: 0x440)
struct UGeometryCacheComponent : UMeshComponent {
	struct UGeometryCache* GeometryCache; // 0x438(0x08)
	bool bRunning; // 0x440(0x01)
	bool bLooping; // 0x441(0x01)
	float StartTimeOffset; // 0x444(0x04)
	float PlaybackSpeed; // 0x448(0x04)
	int32_t NumTracks; // 0x44c(0x04)
	float ElapsedTime; // 0x450(0x04)
	char pad_45A[0x2a]; // 0x45a(0x2a)
	float Duration; // 0x484(0x04)
	bool bManualTick; // 0x488(0x01)
	char pad_489[0x7]; // 0x489(0x07)

	void TickAtThisTime(float Time, bool bInIsRunning, bool bInBackwards, bool bInIsLooping); // Function GeometryCache.GeometryCacheComponent.TickAtThisTime // (None) // @ game+0xffff80091677ffff
	void Stop(); // Function GeometryCache.GeometryCacheComponent.Stop // (None) // @ game+0xffff80091677ffff
	void SetStartTimeOffset(float NewStartTimeOffset); // Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset // (None) // @ game+0xffff80091677ffff
	void SetPlaybackSpeed(float NewPlaybackSpeed); // Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed // (None) // @ game+0xffff80091677ffff
	void SetLooping(bool bNewLooping); // Function GeometryCache.GeometryCacheComponent.SetLooping // (None) // @ game+0xffff80091677ffff
	bool SetGeometryCache(struct UGeometryCache* NewGeomCache); // Function GeometryCache.GeometryCacheComponent.SetGeometryCache // (None) // @ game+0xffff800916770008
	void PlayReversedFromEnd(); // Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd // (None) // @ game+0xffff80091677ffff
	void PlayReversed(); // Function GeometryCache.GeometryCacheComponent.PlayReversed // (None) // @ game+0xffff80091677ffff
	void PlayFromStart(); // Function GeometryCache.GeometryCacheComponent.PlayFromStart // (None) // @ game+0xffff80091677ffff
	void Play(); // Function GeometryCache.GeometryCacheComponent.Play // (None) // @ game+0xffff80091677ffff
	void Pause(); // Function GeometryCache.GeometryCacheComponent.Pause // (None) // @ game+0xffff80091677ffff
	bool IsPlayingReversed(); // Function GeometryCache.GeometryCacheComponent.IsPlayingReversed // (None) // @ game+0xffff800916770000
	bool IsPlaying(); // Function GeometryCache.GeometryCacheComponent.IsPlaying // (None) // @ game+0xffff800916770000
	bool IsLooping(); // Function GeometryCache.GeometryCacheComponent.IsLooping // (None) // @ game+0xffff800916770000
	float GetStartTimeOffset(); // Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset // (None) // @ game+0xffff800916770000
	float GetPlaybackSpeed(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed // (None) // @ game+0xffff800916770000
	float GetPlaybackDirection(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackDirection // (None) // @ game+0xffff800916770000
	int32_t GetNumberOfFrames(); // Function GeometryCache.GeometryCacheComponent.GetNumberOfFrames // (None) // @ game+0xffff800916770000
	float GetDuration(); // Function GeometryCache.GeometryCacheComponent.GetDuration // (None) // @ game+0xffff800916770000
	float GetAnimationTime(); // Function GeometryCache.GeometryCacheComponent.GetAnimationTime // (None) // @ game+0xffff800916770000
};

// Class GeometryCache.GeometryCacheTrack
// Size: 0x58 (Inherited: 0x28)
struct UGeometryCacheTrack : UObject {
	float Duration; // 0x28(0x04)
	char pad_2C[0x2c]; // 0x2c(0x2c)
};

// Class GeometryCache.GeometryCacheTrack_FlipbookAnimation
// Size: 0x80 (Inherited: 0x58)
struct UGeometryCacheTrack_FlipbookAnimation : UGeometryCacheTrack {
	uint32_t NumMeshSamples; // 0x58(0x04)
	char pad_5C[0x24]; // 0x5c(0x24)

	void AddMeshSample(struct FGeometryCacheMeshData& MeshData, float SampleTime); // Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample // (None) // @ game+0xffff80091677ffff
};

// Class GeometryCache.GeometryCacheTrackStreamable
// Size: 0xd0 (Inherited: 0x58)
struct UGeometryCacheTrackStreamable : UGeometryCacheTrack {
	struct UGeometryCacheCodecBase* Codec; // 0x58(0x08)
	char pad_60[0x68]; // 0x60(0x68)
	float StartSampleTime; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
};

// Class GeometryCache.GeometryCacheTrack_TransformAnimation
// Size: 0x100 (Inherited: 0x58)
struct UGeometryCacheTrack_TransformAnimation : UGeometryCacheTrack {
	char pad_58[0xa8]; // 0x58(0xa8)

	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh // (None) // @ game+0xffff80091677ffff
};

// Class GeometryCache.GeometryCacheTrack_TransformGroupAnimation
// Size: 0x100 (Inherited: 0x58)
struct UGeometryCacheTrack_TransformGroupAnimation : UGeometryCacheTrack {
	char pad_58[0xa8]; // 0x58(0xa8)

	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh // (None) // @ game+0xffff80091677ffff
};

