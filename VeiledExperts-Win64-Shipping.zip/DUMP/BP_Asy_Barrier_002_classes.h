// BlueprintGeneratedClass BP_Asy_Barrier_002.BP_Asy_Barrier_002_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_Asy_Barrier_002_C : APDAsyncObject {
};

