// BlueprintGeneratedClass BP_SO_BigSign_WoodPanel_5.BP_SO_BigSign_WoodPanel_4_C
// Size: 0x300 (Inherited: 0x300)
struct ABP_SO_BigSign_WoodPanel_4_C : APDSplitObject {
};

