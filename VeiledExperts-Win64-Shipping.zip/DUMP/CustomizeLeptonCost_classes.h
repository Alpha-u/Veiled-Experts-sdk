// WidgetBlueprintGeneratedClass CustomizeLeptonCost.CustomizeLeptonCost_C
// Size: 0x360 (Inherited: 0x2e8)
struct UCustomizeLeptonCost_C : UPDCustomizeLeptonCost {
	struct UImage* IMG_Empty_Bg; // 0x2e8(0x08)
	struct UImage* IMG_Empty_Circle; // 0x2f0(0x08)
	struct UImage* IMG_Empty_Glow; // 0x2f8(0x08)
	struct UImage* IMG_Equiped_Bg; // 0x300(0x08)
	struct UImage* IMG_Equiped_Circle; // 0x308(0x08)
	struct UImage* IMG_Equiped_Fx01; // 0x310(0x08)
	struct UImage* IMG_Equiped_Fx02; // 0x318(0x08)
	struct UImage* IMG_Equiped_Glow01; // 0x320(0x08)
	struct UImage* IMG_Equiped_GlowFX; // 0x328(0x08)
	struct UImage* IMG_Unique_Bg; // 0x330(0x08)
	struct UImage* IMG_Unique_Circle; // 0x338(0x08)
	struct UImage* IMG_Unique_Fx01; // 0x340(0x08)
	struct UImage* IMG_Unique_Fx02; // 0x348(0x08)
	struct UImage* IMG_Unique_Glow01; // 0x350(0x08)
	struct UImage* IMG_Unique_GlowFX; // 0x358(0x08)
};

