// BlueprintGeneratedClass ExportSafeZoneInitialVertices.ExportSafeZoneInitialVertices_C
// Size: 0x248 (Inherited: 0x240)
struct AExportSafeZoneInitialVertices_C : APDExportSafeZoneInitialVertices {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)

	void  ��꺆윓 (); // Function ExportSafeZoneInitialVertices.ExportSafeZoneInitialVertices_C. ��꺆윓  // (Exec|Event|NetResponse|Static|MulticastDelegate|Private|NetServer|HasOutParms|HasDefaults|DLLImport|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_ExportSafeZoneInitialVertices(int32_t EntryPoint); // Function ExportSafeZoneInitialVertices.ExportSafeZoneInitialVertices_C.ExecuteUbergraph_ExportSafeZoneInitialVertices // (Net|Exec|NetResponse|Static|MulticastDelegate|Private|NetServer|HasOutParms|HasDefaults|DLLImport|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
};

