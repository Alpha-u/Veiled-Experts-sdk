// BlueprintGeneratedClass ExportSafeZoneInitialVertices.ExportSafeZoneInitialVertices_C
// Size: 0x248 (Inherited: 0x240)
struct AExportSafeZoneInitialVertices_C : APDExportSafeZoneInitialVertices {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)

	void  ��껱읤 (); // Function ExportSafeZoneInitialVertices.ExportSafeZoneInitialVertices_C. ��껱읤  // (Net|NetReliableNetRequest|Exec|NetResponse|NetMulticast|UbergraphFunction|Public|Protected|Delegate|HasOutParms|NetClient|DLLImport|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_ExportSafeZoneInitialVertices(int32_t EntryPoint); // Function ExportSafeZoneInitialVertices.ExportSafeZoneInitialVertices_C.ExecuteUbergraph_ExportSafeZoneInitialVertices // (Net|NetReliableExec|NetResponse|NetMulticast|UbergraphFunction|Public|Protected|Delegate|HasOutParms|NetClient|DLLImport|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
};

