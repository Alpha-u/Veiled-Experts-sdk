// BlueprintGeneratedClass BP_ClimbableActor.BP_ClimbableActor_C
// Size: 0x2a8 (Inherited: 0x2a0)
struct ABP_ClimbableActor_C : APDClimbableActor {
	struct UStaticMeshComponent* StaticMesh; // 0x2a0(0x08)
};

