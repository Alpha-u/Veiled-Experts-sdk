// WidgetBlueprintGeneratedClass InvalidGameResultPopup.InvalidGameResultPopup_C
// Size: 0x350 (Inherited: 0x318)
struct UInvalidGameResultPopup_C : UPDOKPopupUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x318(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x320(0x08)
	struct UImage* Img_BgBox; // 0x328(0x08)
	struct UImage* IMG_VXIcon_Deco_L; // 0x330(0x08)
	struct UImage* IMG_VXIcon_Deco_R; // 0x338(0x08)
	struct UImage* IMG_VXIcon_L; // 0x340(0x08)
	struct UImage* IMG_VXIcon_R; // 0x348(0x08)
};

