// WidgetBlueprintGeneratedClass ClanOtherListItem.ClanOtherListItem_C
// Size: 0x3e0 (Inherited: 0x370)
struct UClanOtherListItem_C : UPDClanOtherListItemUI {
	struct UImage* B_ClanTrendBG; // 0x370(0x08)
	struct UImage* B_ClanTrendBG_2; // 0x378(0x08)
	struct UImage* B_ClanTrendBG_3; // 0x380(0x08)
	struct UImage* IMG_ActivityIndex_02; // 0x388(0x08)
	struct UImage* IMG_ActivityIndex_03; // 0x390(0x08)
	struct UImage* IMG_ActivityIndex_04; // 0x398(0x08)
	struct UImage* IMG_ActivityIndex_05; // 0x3a0(0x08)
	struct UImage* IMG_ClanDeco_Left; // 0x3a8(0x08)
	struct UImage* IMG_LineDeco; // 0x3b0(0x08)
	struct UImage* IMG_ListBG_Left; // 0x3b8(0x08)
	struct UImage* IMG_ListBG_Right; // 0x3c0(0x08)
	struct UImage* IMG_Locked; // 0x3c8(0x08)
	struct UImage* IMG_Opened; // 0x3d0(0x08)
	struct UWidgetSwitcher* WS_ActivityIndex; // 0x3d8(0x08)
};

