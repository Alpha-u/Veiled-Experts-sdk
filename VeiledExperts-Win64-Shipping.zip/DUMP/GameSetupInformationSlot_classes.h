// WidgetBlueprintGeneratedClass GameSetupInformationSlot.GameSetupInformationSlot_C
// Size: 0x360 (Inherited: 0x358)
struct UGameSetupInformationSlot_C : UPDGameSetupInformationSlot {
	struct UPDImage* IMG_DefaultBG; // 0x358(0x08)
};

