// WidgetBlueprintGeneratedClass GameMapIconModule.GameMapIconModule_C
// Size: 0x2f0 (Inherited: 0x2f0)
struct UGameMapIconModule_C : UPDGameMapIconModule {
};

