// BlueprintGeneratedClass BP_Windsock_001.BP_Windsock_001_C
// Size: 0x238 (Inherited: 0x220)
struct ABP_Windsock_001_C : AActor {
	struct UStaticMeshComponent* SM_Windsock_002; // 0x220(0x08)
	struct UStaticMeshComponent* SM_Windsock_001; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
};

