// WidgetBlueprintGeneratedClass ControlOption.ControlOption_C
// Size: 0x3b0 (Inherited: 0x3a8)
struct UControlOption_C : UPDControlOptionUI {
	struct UImage* Img_ContentsLine; // 0x3a8(0x08)
};

