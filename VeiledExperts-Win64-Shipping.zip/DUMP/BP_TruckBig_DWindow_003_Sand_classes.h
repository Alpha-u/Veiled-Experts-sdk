// BlueprintGeneratedClass BP_TruckBig_DWindow_003_Sand.BP_TruckBig_DWindow_003_Sand_C
// Size: 0x730 (Inherited: 0x728)
struct ABP_TruckBig_DWindow_003_Sand_C : APDDynamicObject {
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x728(0x08)
};

