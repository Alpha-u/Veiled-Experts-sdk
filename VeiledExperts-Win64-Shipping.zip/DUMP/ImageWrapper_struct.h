// Enum ImageWrapper.EBitmapCSType
enum class EBitmapCSType : uint8 {
	None = 0,
	None = 0
};

// Enum ImageWrapper.EBitmapHeaderVersion
enum class EBitmapHeaderVersion : uint8 {
	None = 0,
	None = 0
};

