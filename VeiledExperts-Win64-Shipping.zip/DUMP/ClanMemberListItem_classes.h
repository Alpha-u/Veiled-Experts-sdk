// WidgetBlueprintGeneratedClass ClanMemberListItem.ClanMemberListItem_C
// Size: 0x360 (Inherited: 0x328)
struct UClanMemberListItem_C : UPDClanMemberListItemUI {
	struct UImage* IMG_ActivityIndex_01; // 0x328(0x08)
	struct UImage* IMG_ActivityIndex_02; // 0x330(0x08)
	struct UImage* IMG_ActivityIndex_03; // 0x338(0x08)
	struct UImage* IMG_ActivityIndex_04; // 0x340(0x08)
	struct UImage* IMG_ActivityIndex_05; // 0x348(0x08)
	struct UImage* IMG_SlotBg; // 0x350(0x08)
	struct UWidgetSwitcher* WS_ActivityIndex; // 0x358(0x08)
};

