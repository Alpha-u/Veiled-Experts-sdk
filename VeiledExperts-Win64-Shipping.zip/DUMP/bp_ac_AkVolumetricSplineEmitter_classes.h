// BlueprintGeneratedClass bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C
// Size: 0x298 (Inherited: 0x220)
struct Abp_ac_AkVolumetricSplineEmitter_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UAkComponent* AkComponent; // 0x228(0x08)
	struct USplineComponent* Spline; // 0x230(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x238(0x08)
	bool Debug; // 0x240(0x01)
	bool Hidden In Game; // 0x241(0x01)
	bool Follow Player Elevation; // 0x242(0x01)
	char pad_243[0x5]; // 0x243(0x05)
	struct UAkAudioEvent* Ak Event Emitter; // 0x248(0x08)
	struct FName State Group; // 0x250(0x08)
	struct FName State Inside; // 0x258(0x08)
	struct FName State Outside; // 0x260(0x08)
	float Occ Refresh Interval; // 0x268(0x04)
	float Max Range Fade Distance; // 0x26c(0x04)
	bool Is Inside Spline; // 0x270(0x01)
	char pad_271[0x3]; // 0x271(0x03)
	float Dot Value; // 0x274(0x04)
	struct FVector Ak Emitter Location; // 0x278(0x0c)
	float Timer Lazy; // 0x284(0x04)
	bool Is Lazy; // 0x288(0x01)
	bool Is Initialized; // 0x289(0x01)
	char pad_28A[0x2]; // 0x28a(0x02)
	struct FVector Spline Curve Location Closest To Player; // 0x28c(0x0c)

	void GetDistanceToPlayerFromClosestSplinePoint(float& DistanceToPlayerFromClosestSplinePoint); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.GetDistanceToPlayerFromClosestSplinePoint // (Net|NetRequest|Exec|Native|Event|Static|NetMulticast|Public|Private|Protected|NetServer|HasDefaults|NetValidate) // @ game+0xffff8008b8ceffff
	void GetIsInsideSpline(bool& IsInsideSpline?, bool& IsInsideSplineChanged?); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.GetIsInsideSpline // (NetReliableExec|Native|Event|NetResponse|Static|NetMulticast|UbergraphFunction|MulticastDelegate|NetServer|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff8008b8ceffff
	void GetPlayerControllerCameraRotation(struct FRotator& PlayerControllerCameraRotation); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.GetPlayerControllerCameraRotation // (Net|NetReliableNetResponse|Static|Protected|NetServer|HasOutParms|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
	void GetControlledPawnLocation(struct APawn*& ControlledPawnReference, struct FVector& ControlledPawnLocation); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.GetControlledPawnLocation // (NetReliableNetResponse|Static|Protected|NetServer|HasOutParms|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
	void UserConstructionScript(); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.UserConstructionScript // (Net|NetRequest|Exec|MulticastDelegate|NetServer|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff8008b8ceffff
	void UpdateEmitterLocationProxy(); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.UpdateEmitterLocationProxy // (Net|Exec|Event|Static|Protected|NetServer|HasOutParms|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
	void Update Emitter Slowly(); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.Update Emitter Slowly // (NetResponse|Static|Protected|NetServer|HasOutParms|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
	void ReceiveTick(float DeltaSeconds); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.ReceiveTick // (Net|NetReliableNetRequest|Exec|Native|Event|Static|Protected|NetServer|HasOutParms|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
	void ReceiveBeginPlay(); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.ReceiveBeginPlay // (Native|Static|Protected|NetServer|HasOutParms|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
	void Set AK State(); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.Set AK State // (NetRequest|Native|Static|Protected|NetServer|HasOutParms|HasDefaults|NetClient|DLLImport|BlueprintCallable|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_bp_ac_AkVolumetricSplineEmitter(int32_t EntryPoint); // Function bp_ac_AkVolumetricSplineEmitter.bp_ac_AkVolumetricSplineEmitter_C.ExecuteUbergraph_bp_ac_AkVolumetricSplineEmitter // (Net|NetRequest|Exec|Native|Event|NetResponse|Static|UbergraphFunction|Delegate|NetServer|HasDefaults|NetClient|DLLImport|BlueprintEvent) // @ game+0xffff8008b8ceffff
};

