// WidgetBlueprintGeneratedClass KillLogModule.KillLogModule_C
// Size: 0x398 (Inherited: 0x398)
struct UKillLogModule_C : UPDKillLogModule {
};

