// WidgetBlueprintGeneratedClass DamageIndicator.DamageIndicator_C
// Size: 0x300 (Inherited: 0x2f8)
struct UDamageIndicator_C : UPDDamageIndicatorUI {
	struct UWidgetAnimation* Anim_Damage; // 0x2f8(0x08)
};

