// Enum MagicLeapController.EMagicLeapTouchpadGestureDirection
enum class EMagicLeapTouchpadGestureDirection : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapController.EMagicLeapTouchpadGestureType
enum class EMagicLeapTouchpadGestureType : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapController.EMagicLeapControllerTrackingMode
enum class EMagicLeapControllerTrackingMode : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapController.EMagicLeapControllerHapticIntensity
enum class EMagicLeapControllerHapticIntensity : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapController.EMagicLeapControllerHapticPattern
enum class EMagicLeapControllerHapticPattern : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapController.EMagicLeapControllerLEDSpeed
enum class EMagicLeapControllerLEDSpeed : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapController.EMagicLeapControllerLEDColor
enum class EMagicLeapControllerLEDColor : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapController.EMagicLeapControllerLEDEffect
enum class EMagicLeapControllerLEDEffect : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapController.EMagicLeapControllerLEDPattern
enum class EMagicLeapControllerLEDPattern : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapController.EMagicLeapControllerType
enum class EMagicLeapControllerType : uint8 {
	None = 0,
	None = 0
};

// ScriptStruct MagicLeapController.MagicLeapTouchpadGesture
// Size: 0x30 (Inherited: 0x00)
struct FMagicLeapTouchpadGesture {
	enum class EControllerHand Hand; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName MotionSource; // 0x04(0x08)
	enum class EMagicLeapTouchpadGestureType Type; // 0x0c(0x01)
	enum class EMagicLeapTouchpadGestureDirection Direction; // 0x0d(0x01)
	char pad_E[0x2]; // 0x0e(0x02)
	struct FVector PositionAndForce; // 0x10(0x0c)
	float Speed; // 0x1c(0x04)
	float Distance; // 0x20(0x04)
	float FingerGap; // 0x24(0x04)
	float Radius; // 0x28(0x04)
	float Angle; // 0x2c(0x04)
};

