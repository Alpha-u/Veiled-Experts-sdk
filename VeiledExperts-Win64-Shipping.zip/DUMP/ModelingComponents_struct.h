// Enum ModelingComponents.EDynamicMeshTangentCalcType
enum class EDynamicMeshTangentCalcType : uint8 {
	None = 0,
	None = 0
};

// Enum ModelingComponents.EMultiTransformerMode
enum class EMultiTransformerMode : uint8 {
	None = 0,
	None = 0
};

