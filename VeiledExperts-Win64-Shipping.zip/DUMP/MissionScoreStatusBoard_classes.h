// WidgetBlueprintGeneratedClass MissionScoreStatusBoard.MissionScoreStatusBoard_C
// Size: 0x370 (Inherited: 0x300)
struct UMissionScoreStatusBoard_C : UPDMissionScoreStatusBoard {
	struct UStatusBoardBlockAll_C* BTN_Community_OFF; // 0x300(0x08)
	struct UImage* IMG_GuideBg2; // 0x308(0x08)
	struct UImage* IMG_InfoBoardBg; // 0x310(0x08)
	struct UImage* IMG_InfoBoardBLine_Ally; // 0x318(0x08)
	struct UImage* IMG_Kill; // 0x320(0x08)
	struct UImage* IMG_Ping; // 0x328(0x08)
	struct UImage* IMG_PlayerInfo_Bg_Ally; // 0x330(0x08)
	struct UImage* IMG_Point; // 0x338(0x08)
	struct UImage* IMG_Score; // 0x340(0x08)
	struct UMissionScoreStatusBoardPlayerInfo_C* MissionScoreStatusBoardPlayerInfo; // 0x348(0x08)
	struct UMissionScoreStatusBoardPlayerInfo_C* MissionScoreStatusBoardPlayerInfo_2; // 0x350(0x08)
	struct UMissionScoreStatusBoardRoundItem_C* RoundItem; // 0x358(0x08)
	struct UMissionScoreStatusBoardRoundItem_C* RoundItem_2; // 0x360(0x08)
	struct UMissionScoreStatusBoardRoundItem_C* RoundItem_3; // 0x368(0x08)
};

