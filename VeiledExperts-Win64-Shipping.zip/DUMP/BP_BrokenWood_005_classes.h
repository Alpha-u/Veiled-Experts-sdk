// BlueprintGeneratedClass BP_BrokenWood_005.BP_BrokenWood_005_C
// Size: 0x730 (Inherited: 0x728)
struct ABP_BrokenWood_005_C : APDDynamicObject {
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x728(0x08)
};

