// AnimBlueprintGeneratedClass ABP_Luna_Hair.ABP_Luna_Hair_C
// Size: 0x3880 (Inherited: 0x2a0)
struct UABP_Luna_Hair_C : UPDAnimDynamicsInstBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2a8(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2; // 0x2d8(0xe0)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x3b8(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x3d8(0x20)
	char pad_3F8[0x8]; // 0x3f8(0x08)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_12; // 0x400(0x440)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x840(0xa0)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer; // 0x8e0(0xe0)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_11; // 0x9c0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_10; // 0xe00(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_9; // 0x1240(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8; // 0x1680(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7; // 0x1ac0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6; // 0x1f00(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5; // 0x2340(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4; // 0x2780(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3; // 0x2bc0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2; // 0x3000(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics; // 0x3440(0x440)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Luna_Hair.ABP_Luna_Hair_C.AnimGraph // (Exec|Event|Static|MulticastDelegate|Public|Protected|HasOutParms|HasDefaults|DLLImport|EditorOnly) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_ABP_Luna_Hair(int32_t EntryPoint); // Function ABP_Luna_Hair.ABP_Luna_Hair_C.ExecuteUbergraph_ABP_Luna_Hair // (None) // @ game+0xffff80091677ffff
};

