// WidgetBlueprintGeneratedClass MainLobby.MainLobby_C
// Size: 0x3d8 (Inherited: 0x350)
struct UMainLobby_C : UPDLobbyUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x350(0x08)
	struct UWidgetAnimation* Anim_SceneOut; // 0x358(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x360(0x08)
	struct UPDWebButton_C* Btn_GameGuide; // 0x368(0x08)
	struct UEquipLeptonInfo_C* EquipLeptonInfo; // 0x370(0x08)
	struct UImage* IMG_Idle; // 0x378(0x08)
	struct UImage* IMG_MissionList_Outline; // 0x380(0x08)
	struct UImage* IMG_Muted; // 0x388(0x08)
	struct UImage* IMG_Muted_Line; // 0x390(0x08)
	struct UImage* IMG_NoAudio; // 0x398(0x08)
	struct UImage* IMG_NotJoined; // 0x3a0(0x08)
	struct UImage* IMG_QR_Common; // 0x3a8(0x08)
	struct UImage* IMG_SlotBg; // 0x3b0(0x08)
	struct UImage* IMG_Speaking; // 0x3b8(0x08)
	struct UImage* IMG_Speaking_FX; // 0x3c0(0x08)
	struct UImage* IMG_VoiceSwitch_Bg; // 0x3c8(0x08)
	struct UImage* IMG_VX_Companion; // 0x3d0(0x08)

	void PreConstruct(bool IsDesignTime); // Function MainLobby.MainLobby_C.PreConstruct // (NetReliableNetRequest|Native|Event|NetResponse|UbergraphFunction|MulticastDelegate|Private|HasOutParms|NetClient|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_MainLobby(int32_t EntryPoint); // Function MainLobby.MainLobby_C.ExecuteUbergraph_MainLobby // (None) // @ game+0xffff80091677ffff
};

