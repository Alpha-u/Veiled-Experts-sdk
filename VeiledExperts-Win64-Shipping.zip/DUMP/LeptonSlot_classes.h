// WidgetBlueprintGeneratedClass LeptonSlot.LeptonSlot_C
// Size: 0x2f8 (Inherited: 0x2f8)
struct ULeptonSlot_C : UPDEquipLeptonSlot {
};

