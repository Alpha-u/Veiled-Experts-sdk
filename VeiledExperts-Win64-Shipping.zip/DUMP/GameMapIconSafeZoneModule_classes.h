// WidgetBlueprintGeneratedClass GameMapIconSafeZoneModule.GameMapIconSafeZoneModule_C
// Size: 0x330 (Inherited: 0x328)
struct UGameMapIconSafeZoneModule_C : UPDGameMapIconSafeZoneModule {
	struct UPDTextBlock* TB_Name; // 0x328(0x08)
};

