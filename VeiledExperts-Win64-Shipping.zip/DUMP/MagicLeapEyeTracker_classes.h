// Class MagicLeapEyeTracker.MagicLeapEyeTrackerFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UMagicLeapEyeTrackerFunctionLibrary : UBlueprintFunctionLibrary {

	bool GetEyeBlinkState(struct FMagicLeapEyeBlinkState& BlinkState); // Function MagicLeapEyeTracker.MagicLeapEyeTrackerFunctionLibrary.GetEyeBlinkState // (None) // @ game+0xffff800916770002
	enum class EMagicLeapEyeTrackingCalibrationStatus GetCalibrationStatus(); // Function MagicLeapEyeTracker.MagicLeapEyeTrackerFunctionLibrary.GetCalibrationStatus // (None) // @ game+0xffff800916770000
};

