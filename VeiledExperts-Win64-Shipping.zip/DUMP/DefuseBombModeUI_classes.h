// WidgetBlueprintGeneratedClass DefuseBombModeUI.DefuseBombModeUI_C
// Size: 0x5e0 (Inherited: 0x5c0)
struct UDefuseBombModeUI_C : UPDDefuseBombModeUI {
	struct UCallingCard_C* CallingCard; // 0x5c0(0x08)
	struct UImage* IMG_BottomBg; // 0x5c8(0x08)
	struct UMatchStopInfoUI_C* MatchStopInfoUI; // 0x5d0(0x08)
	struct UMinimap_C* Minimap; // 0x5d8(0x08)
};

