// WidgetBlueprintGeneratedClass Login.Login_C
// Size: 0x3f8 (Inherited: 0x360)
struct ULogin_C : UPDLoginUI {
	struct UWidgetAnimation* Anim_FadeIn; // 0x360(0x08)
	struct UWidgetAnimation* Anim_Alert; // 0x368(0x08)
	struct UImage* IMG_Alert; // 0x370(0x08)
	struct UImage* IMG_BottomBar; // 0x378(0x08)
	struct UImage* IMG_BoxBg; // 0x380(0x08)
	struct UImage* IMG_Deco01_Arrow; // 0x388(0x08)
	struct UImage* IMG_Deco01_TxtAnim; // 0x390(0x08)
	struct UImage* IMG_Fadein; // 0x398(0x08)
	struct UImage* IMG_ID_BG; // 0x3a0(0x08)
	struct UImage* IMG_ID_Outline; // 0x3a8(0x08)
	struct UImage* IMG_NA_Bg; // 0x3b0(0x08)
	struct UImage* IMG_NA_Divider; // 0x3b8(0x08)
	struct UImage* IMG_NA_Outline; // 0x3c0(0x08)
	struct UImage* IMG_PW_BG; // 0x3c8(0x08)
	struct UImage* IMG_PW_Outline; // 0x3d0(0x08)
	struct UImage* IMG_SaveID_Divider; // 0x3d8(0x08)
	struct UImage* IMG_SaveID_Outline; // 0x3e0(0x08)
	struct UImage* IMG_TopBar; // 0x3e8(0x08)
	struct UImage* IMG_UnkownLogo; // 0x3f0(0x08)
};

