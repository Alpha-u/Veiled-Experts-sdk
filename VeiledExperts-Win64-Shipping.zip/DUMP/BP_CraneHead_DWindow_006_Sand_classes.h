// BlueprintGeneratedClass BP_CraneHead_DWindow_006_Sand.BP_CraneHead_DWindow_006_Sand_C
// Size: 0x738 (Inherited: 0x728)
struct ABP_CraneHead_DWindow_006_Sand_C : APDDynamicObject {
	struct UBoxComponent* Box; // 0x728(0x08)
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x730(0x08)
};

