// BlueprintGeneratedClass ExportSafeZoneActor.ExportSafeZoneActor_C
// Size: 0x248 (Inherited: 0x240)
struct AExportSafeZoneActor_C : APDExportSafeZoneActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)

	void  ��꺆윓(); // Function ExportSafeZoneActor.ExportSafeZoneActor_C. ��꺆윓 // (Exec|NetResponse|Static|MulticastDelegate|Private|NetServer|HasOutParms|HasDefaults|DLLImport|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_ExportSafeZoneActor(int32_t EntryPoint); // Function ExportSafeZoneActor.ExportSafeZoneActor_C.ExecuteUbergraph_ExportSafeZoneActor // (Net|NetRequest|Event|NetResponse|Static|MulticastDelegate|Private|NetServer|HasOutParms|HasDefaults|DLLImport|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
};

