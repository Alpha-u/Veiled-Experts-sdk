// BlueprintGeneratedClass ExportSafeZoneActor.ExportSafeZoneActor_C
// Size: 0x248 (Inherited: 0x240)
struct AExportSafeZoneActor_C : APDExportSafeZoneActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)

	void  ��껱읤(); // Function ExportSafeZoneActor.ExportSafeZoneActor_C. ��껱읤 // (Net|NetReliableExec|NetResponse|NetMulticast|UbergraphFunction|Public|Protected|Delegate|HasOutParms|NetClient|DLLImport|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_ExportSafeZoneActor(int32_t EntryPoint); // Function ExportSafeZoneActor.ExportSafeZoneActor_C.ExecuteUbergraph_ExportSafeZoneActor // (NetRequest|Exec|NetResponse|NetMulticast|UbergraphFunction|Public|Protected|Delegate|HasOutParms|NetClient|DLLImport|BlueprintEvent|Const|NetValidate) // @ game+0xffff8008b8ceffff
};

