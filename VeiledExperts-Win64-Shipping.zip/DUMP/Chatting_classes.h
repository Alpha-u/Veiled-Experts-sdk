// WidgetBlueprintGeneratedClass Chatting.Chatting_C
// Size: 0x3b8 (Inherited: 0x3a0)
struct UChatting_C : UPDChattingUI {
	struct UWidgetAnimation* Hide; // 0x3a0(0x08)
	struct UImage* IMG_InputBg; // 0x3a8(0x08)
	struct UPDImage* img_Top; // 0x3b0(0x08)
};

