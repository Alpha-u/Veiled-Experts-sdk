// BlueprintGeneratedClass BP_AsyDS_Cleaning_Trolley_flask_003.BP_AsyDS_Cleaning_Trolley_flask_003_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_AsyDS_Cleaning_Trolley_flask_003_C : APDAsyncObjectDestroyed {
};

