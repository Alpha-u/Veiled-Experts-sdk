// WidgetBlueprintGeneratedClass GameMapIconItemBox.GameMapIconItemBox_C
// Size: 0x2f0 (Inherited: 0x2f0)
struct UGameMapIconItemBox_C : UPDGameMapIconModule {
};

