// WidgetBlueprintGeneratedClass AgentProfilePopup.AgentProfilePopup_C
// Size: 0x3b0 (Inherited: 0x358)
struct UAgentProfilePopup_C : UPDAgentProfilePopupUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x358(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x360(0x08)
	struct UImage* IMG_Blinder; // 0x368(0x08)
	struct UImage* IMG_BottomBar; // 0x370(0x08)
	struct UImage* IMG_Deco_BL; // 0x378(0x08)
	struct UImage* IMG_Deco_BR; // 0x380(0x08)
	struct UImage* IMG_Deco_TL; // 0x388(0x08)
	struct UImage* IMG_Deco_TR; // 0x390(0x08)
	struct UImage* IMG_SignBg; // 0x398(0x08)
	struct UImage* IMG_TopBar; // 0x3a0(0x08)
	struct UImage* IMG_TopDeco; // 0x3a8(0x08)
};

