// BlueprintGeneratedClass BP_MERGED_Small_Warehouse_002_01_Epic.BP_MERGED_Small_Warehouse_002_01_Epic_C
// Size: 0x2a0 (Inherited: 0x220)
struct ABP_MERGED_Small_Warehouse_002_01_Epic_C : AActor {
	struct UStaticMeshComponent* SM_Barrier_007; // 0x220(0x08)
	struct UStaticMeshComponent* SM_Barrier_009; // 0x228(0x08)
	struct UStaticMeshComponent* SM_Barrier_008; // 0x230(0x08)
	struct UStaticMeshComponent* SM_Barrier_003; // 0x238(0x08)
	struct UStaticMeshComponent* SM_Hallway_Vent_007; // 0x240(0x08)
	struct UStaticMeshComponent* SM_FirstAidKit_004; // 0x248(0x08)
	struct UStaticMeshComponent* SM_FirstAidKit_003; // 0x250(0x08)
	struct UStaticMeshComponent* SM_SignB_02; // 0x258(0x08)
	struct UStaticMeshComponent* SM_SignA_11; // 0x260(0x08)
	struct UStaticMeshComponent* SM_Hallway_Vent_0011; // 0x268(0x08)
	struct UStaticMeshComponent* SM_Hallway_Vent_0010; // 0x270(0x08)
	struct UStaticMeshComponent* SM_Hallway_Vent_006; // 0x278(0x08)
	struct UStaticMeshComponent* SM_Hallway_Vent_003; // 0x280(0x08)
	struct UStaticMeshComponent* SM_SignB_12; // 0x288(0x08)
	struct UStaticMeshComponent* SM_Hallway_Firesign_001; // 0x290(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x298(0x08)
};

