// Enum LuminRuntimeSettings.ELuminPrivilege
enum class ELuminPrivilege : uint8 {
	None = 0,
	None = 0
};

// Enum LuminRuntimeSettings.ELuminFrameTimingHint
enum class ELuminFrameTimingHint : uint8 {
	None = 0,
	None = 0
};

// Enum LuminRuntimeSettings.ELuminComponentType
enum class ELuminComponentType : uint8 {
	None = 0,
	None = 0
};

// Enum LuminRuntimeSettings.ELuminComponentSubElementType
enum class ELuminComponentSubElementType : uint8 {
	None = 0,
	None = 0
};

// ScriptStruct LuminRuntimeSettings.LocalizedIconInfos
// Size: 0x10 (Inherited: 0x00)
struct FLocalizedIconInfos {
	struct TArray<struct FLocalizedIconInfo> IconData; // 0x00(0x10)
};

// ScriptStruct LuminRuntimeSettings.LocalizedIconInfo
// Size: 0x30 (Inherited: 0x00)
struct FLocalizedIconInfo {
	struct FString LanguageCode; // 0x00(0x10)
	struct FDirectoryPath IconModelPath; // 0x10(0x10)
	struct FDirectoryPath IconPortalPath; // 0x20(0x10)
};

// ScriptStruct LuminRuntimeSettings.LocalizedAppName
// Size: 0x20 (Inherited: 0x00)
struct FLocalizedAppName {
	struct FString LanguageCode; // 0x00(0x10)
	struct FString AppName; // 0x10(0x10)
};

// ScriptStruct LuminRuntimeSettings.LuminComponentElement
// Size: 0x48 (Inherited: 0x00)
struct FLuminComponentElement {
	struct FString Name; // 0x00(0x10)
	struct FString VisibleName; // 0x10(0x10)
	struct FString ExecutableName; // 0x20(0x10)
	enum class ELuminComponentType ComponentType; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TArray<struct FLuminComponentSubElement> ExtraComponentSubElements; // 0x38(0x10)
};

// ScriptStruct LuminRuntimeSettings.LuminComponentSubElement
// Size: 0x18 (Inherited: 0x00)
struct FLuminComponentSubElement {
	enum class ELuminComponentSubElementType ElementType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Value; // 0x08(0x10)
};

