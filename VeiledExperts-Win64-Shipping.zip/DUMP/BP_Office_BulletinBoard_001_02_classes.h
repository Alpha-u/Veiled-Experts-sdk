// BlueprintGeneratedClass BP_Office_BulletinBoard_001_02.BP_Office_BulletinBoard_001_02_C
// Size: 0x730 (Inherited: 0x728)
struct ABP_Office_BulletinBoard_001_02_C : APDDynamicObject {
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x728(0x08)
};

