// WidgetBlueprintGeneratedClass GameSetupInfomationPopup.GameSetupInfomationPopup_C
// Size: 0x358 (Inherited: 0x348)
struct UGameSetupInfomationPopup_C : UPDGameSetupInformationPopupUI {
	struct UImage* IMG_Blinder; // 0x348(0x08)
	struct UImage* IMG_PopupBg; // 0x350(0x08)
};

