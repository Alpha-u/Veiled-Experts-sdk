// WidgetBlueprintGeneratedClass GameMapIconThrownModule.GameMapIconThrownModule_C
// Size: 0x328 (Inherited: 0x310)
struct UGameMapIconThrownModule_C : UPDPlayLogMapIconThrownModule {
	struct UWidgetAnimation* AniThrownAreaEnd; // 0x310(0x08)
	struct UWidgetAnimation* AniThrownAreaStart; // 0x318(0x08)
	struct UWidgetAnimation* AniThrownArea; // 0x320(0x08)
};

