// BlueprintGeneratedClass BP_AirPropeller_001.BP_AirPropeller_001_C
// Size: 0x380 (Inherited: 0x370)
struct ABP_AirPropeller_001_C : APDPropActor {
	struct UStaticMeshComponent* SM_AirPropeller_002; // 0x370(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x378(0x08)
};

