// WidgetBlueprintGeneratedClass MatchModeListItem.MatchModeListItem_C
// Size: 0x3a0 (Inherited: 0x398)
struct UMatchModeListItem_C : UPDMatchModeListItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x398(0x08)

	void BP_OnEntryReleased(); // Function MatchModeListItem.MatchModeListItem_C.BP_OnEntryReleased // (Net|NetReliableExec|NetResponse|Static|NetMulticast|MulticastDelegate|Private|Protected|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff80091677ffff
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function MatchModeListItem.MatchModeListItem_C.BP_OnItemExpansionChanged // (NetRequest|Exec|NetResponse|Static|NetMulticast|MulticastDelegate|Private|Protected|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff80091677ffff
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function MatchModeListItem.MatchModeListItem_C.BP_OnItemSelectionChanged // (NetReliableNetRequest|Exec|NetResponse|Static|NetMulticast|MulticastDelegate|Private|Protected|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_MatchModeListItem(int32_t EntryPoint); // Function MatchModeListItem.MatchModeListItem_C.ExecuteUbergraph_MatchModeListItem // (None) // @ game+0xffff80091677ffff
};

