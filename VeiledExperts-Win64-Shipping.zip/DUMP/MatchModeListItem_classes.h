// WidgetBlueprintGeneratedClass MatchModeListItem.MatchModeListItem_C
// Size: 0x3a0 (Inherited: 0x398)
struct UMatchModeListItem_C : UPDMatchModeListItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x398(0x08)

	void BP_OnEntryReleased(); // Function MatchModeListItem.MatchModeListItem_C.BP_OnEntryReleased // (Net|NetRequest|Native|Event|NetMulticast|Private|Delegate|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff8008b8ceffff
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function MatchModeListItem.MatchModeListItem_C.BP_OnItemExpansionChanged // (NetReliableNetRequest|Native|Event|NetMulticast|Private|Delegate|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff8008b8ceffff
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function MatchModeListItem.MatchModeListItem_C.BP_OnItemSelectionChanged // (Exec|Native|Event|NetMulticast|Private|Delegate|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|NetValidate) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_MatchModeListItem(int32_t EntryPoint); // Function MatchModeListItem.MatchModeListItem_C.ExecuteUbergraph_MatchModeListItem // (None) // @ game+0xffff8008b8ceffff
};

