// WidgetBlueprintGeneratedClass MailItemListSlot.MailItemListSlot_C
// Size: 0x2f0 (Inherited: 0x2e8)
struct UMailItemListSlot_C : UPDMailItemListSlotUI {
	struct UPDButton_C* Btn_ItemSlot; // 0x2e8(0x08)
};

