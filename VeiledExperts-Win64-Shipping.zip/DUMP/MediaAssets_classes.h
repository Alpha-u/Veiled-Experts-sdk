// Class MediaAssets.MediaSource
// Size: 0x80 (Inherited: 0x28)
struct UMediaSource : UObject {
	char pad_28[0x58]; // 0x28(0x58)

	bool Validate(); // Function MediaAssets.MediaSource.Validate // (None) // @ game+0xffff8008b8ce0000
	void SetMediaOptionString(struct FName& Key, struct FString Value); // Function MediaAssets.MediaSource.SetMediaOptionString // (None) // @ game+0xffff8008b8ceffff
	void SetMediaOptionInt64(struct FName& Key, int64_t Value); // Function MediaAssets.MediaSource.SetMediaOptionInt64 // (None) // @ game+0xffff8008b8ceffff
	void SetMediaOptionFloat(struct FName& Key, float Value); // Function MediaAssets.MediaSource.SetMediaOptionFloat // (None) // @ game+0xffff8008b8ceffff
	void SetMediaOptionBool(struct FName& Key, bool Value); // Function MediaAssets.MediaSource.SetMediaOptionBool // (None) // @ game+0xffff8008b8ceffff
	struct FString GetUrl(); // Function MediaAssets.MediaSource.GetUrl // (None) // @ game+0xffff8008b8ce0000
};

// Class MediaAssets.BaseMediaSource
// Size: 0x88 (Inherited: 0x80)
struct UBaseMediaSource : UMediaSource {
	struct FName PlayerName; // 0x80(0x08)
};

// Class MediaAssets.FileMediaSource
// Size: 0xb0 (Inherited: 0x88)
struct UFileMediaSource : UBaseMediaSource {
	struct FString FilePath; // 0x88(0x10)
	bool PrecacheFile; // 0x98(0x01)
	char pad_99[0x17]; // 0x99(0x17)

	void SetFilePath(struct FString Path); // Function MediaAssets.FileMediaSource.SetFilePath // (None) // @ game+0xffff8008b8ceffff
};

// Class MediaAssets.MediaBlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UMediaBlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	void EnumerateWebcamCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateWebcamCaptureDevices // (None) // @ game+0xffff8008b8ceffff
	void EnumerateVideoCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateVideoCaptureDevices // (None) // @ game+0xffff8008b8ceffff
	void EnumerateAudioCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateAudioCaptureDevices // (None) // @ game+0xffff8008b8ceffff
};

// Class MediaAssets.MediaComponent
// Size: 0xc0 (Inherited: 0xb0)
struct UMediaComponent : UActorComponent {
	struct UMediaTexture* MediaTexture; // 0xb0(0x08)
	struct UMediaPlayer* MediaPlayer; // 0xb8(0x08)

	struct UMediaTexture* GetMediaTexture(); // Function MediaAssets.MediaComponent.GetMediaTexture // (None) // @ game+0xffff8008b8ce0000
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaAssets.MediaComponent.GetMediaPlayer // (None) // @ game+0xffff8008b8ce0000
};

// Class MediaAssets.MediaPlayer
// Size: 0x138 (Inherited: 0x28)
struct UMediaPlayer : UObject {
	struct FMulticastInlineDelegate OnEndReached; // 0x28(0x10)
	struct FMulticastInlineDelegate OnMediaClosed; // 0x38(0x10)
	struct FMulticastInlineDelegate OnMediaOpened; // 0x48(0x10)
	struct FMulticastInlineDelegate OnMediaOpenFailed; // 0x58(0x10)
	struct FMulticastInlineDelegate OnPlaybackResumed; // 0x68(0x10)
	struct FMulticastInlineDelegate OnPlaybackSuspended; // 0x78(0x10)
	struct FMulticastInlineDelegate OnSeekCompleted; // 0x88(0x10)
	struct FMulticastInlineDelegate OnTracksChanged; // 0x98(0x10)
	struct FTimespan CacheAhead; // 0xa8(0x08)
	struct FTimespan CacheBehind; // 0xb0(0x08)
	struct FTimespan CacheBehindGame; // 0xb8(0x08)
	bool NativeAudioOut; // 0xc0(0x01)
	bool PlayOnOpen; // 0xc1(0x01)
	char pad_C2[0x2]; // 0xc2(0x02)
	char Shuffle : 1; // 0xc4(0x01)
	char Loop : 1; // 0xc4(0x01)
	char pad_C4_2 : 6; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
	struct UMediaPlaylist* Playlist; // 0xc8(0x08)
	int32_t PlaylistIndex; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct FTimespan TimeDelay; // 0xd8(0x08)
	float HorizontalFieldOfView; // 0xe0(0x04)
	float VerticalFieldOfView; // 0xe4(0x04)
	struct FRotator ViewRotation; // 0xe8(0x0c)
	char pad_F4[0x2c]; // 0xf4(0x2c)
	struct FGuid PlayerGuid; // 0x120(0x10)
	char pad_130[0x8]; // 0x130(0x08)

	bool SupportsSeeking(); // Function MediaAssets.MediaPlayer.SupportsSeeking // (None) // @ game+0xffff8008b8ce0000
	bool SupportsScrubbing(); // Function MediaAssets.MediaPlayer.SupportsScrubbing // (None) // @ game+0xffff8008b8ce0000
	bool SupportsRate(float Rate, bool Unthinned); // Function MediaAssets.MediaPlayer.SupportsRate // (None) // @ game+0xffff8008b8ce0005
	bool SetViewRotation(struct FRotator& Rotation, bool Absolute); // Function MediaAssets.MediaPlayer.SetViewRotation // (None) // @ game+0xffff8008b8ce000d
	bool SetViewField(float Horizontal, float Vertical, bool Absolute); // Function MediaAssets.MediaPlayer.SetViewField // (None) // @ game+0xffff8008b8ce0009
	bool SetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex, float FrameRate); // Function MediaAssets.MediaPlayer.SetVideoTrackFrameRate // (None) // @ game+0xffff8008b8ce000c
	bool SetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.SetTrackFormat // (None) // @ game+0xffff8008b8ce000c
	void SetTimeDelay(struct FTimespan TimeDelay); // Function MediaAssets.MediaPlayer.SetTimeDelay // (None) // @ game+0xffff8008b8ceffff
	bool SetRate(float Rate); // Function MediaAssets.MediaPlayer.SetRate // (None) // @ game+0xffff8008b8ce0004
	bool SetNativeVolume(float Volume); // Function MediaAssets.MediaPlayer.SetNativeVolume // (None) // @ game+0xffff8008b8ce0004
	void SetMediaOptions(struct UMediaSource* Options); // Function MediaAssets.MediaPlayer.SetMediaOptions // (None) // @ game+0xffff8008b8ceffff
	bool SetLooping(bool Looping); // Function MediaAssets.MediaPlayer.SetLooping // (None) // @ game+0xffff8008b8ce0001
	void SetDesiredPlayerName(struct FName PlayerName); // Function MediaAssets.MediaPlayer.SetDesiredPlayerName // (None) // @ game+0xffff8008b8ceffff
	void SetBlockOnTime(struct FTimespan& Time); // Function MediaAssets.MediaPlayer.SetBlockOnTime // (None) // @ game+0xffff8008b8ceffff
	bool SelectTrack(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.SelectTrack // (None) // @ game+0xffff8008b8ce0008
	bool Seek(struct FTimespan& Time); // Function MediaAssets.MediaPlayer.Seek // (None) // @ game+0xffff8008b8ce0008
	bool Rewind(); // Function MediaAssets.MediaPlayer.Rewind // (None) // @ game+0xffff8008b8ce0000
	bool Reopen(); // Function MediaAssets.MediaPlayer.Reopen // (None) // @ game+0xffff8008b8ce0000
	bool Previous(); // Function MediaAssets.MediaPlayer.Previous // (None) // @ game+0xffff8008b8ce0000
	void PlayAndSeek(); // Function MediaAssets.MediaPlayer.PlayAndSeek // (None) // @ game+0xffff8008b8ceffff
	bool Play(); // Function MediaAssets.MediaPlayer.Play // (None) // @ game+0xffff8008b8ce0000
	bool Pause(); // Function MediaAssets.MediaPlayer.Pause // (None) // @ game+0xffff8008b8ce0000
	bool OpenUrl(struct FString URL); // Function MediaAssets.MediaPlayer.OpenUrl // (None) // @ game+0xffff8008b8ce0010
	bool OpenSourceWithOptions(struct UMediaSource* MediaSource, struct FMediaPlayerOptions& Options); // Function MediaAssets.MediaPlayer.OpenSourceWithOptions // (None) // @ game+0xffff8008b8ce0038
	void OpenSourceLatent(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UMediaSource* MediaSource, struct FMediaPlayerOptions& Options, bool& bSuccess); // Function MediaAssets.MediaPlayer.OpenSourceLatent // (None) // @ game+0xffff8008b8ceffff
	bool OpenSource(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlayer.OpenSource // (None) // @ game+0xffff8008b8ce0008
	bool OpenPlaylistIndex(struct UMediaPlaylist* InPlaylist, int32_t Index); // Function MediaAssets.MediaPlayer.OpenPlaylistIndex // (None) // @ game+0xffff8008b8ce000c
	bool OpenPlaylist(struct UMediaPlaylist* InPlaylist); // Function MediaAssets.MediaPlayer.OpenPlaylist // (None) // @ game+0xffff8008b8ce0008
	bool OpenFile(struct FString FilePath); // Function MediaAssets.MediaPlayer.OpenFile // (None) // @ game+0xffff8008b8ce0010
	bool Next(); // Function MediaAssets.MediaPlayer.Next // (None) // @ game+0xffff8008b8ce0000
	bool IsReady(); // Function MediaAssets.MediaPlayer.IsReady // (None) // @ game+0xffff8008b8ce0000
	bool IsPreparing(); // Function MediaAssets.MediaPlayer.IsPreparing // (None) // @ game+0xffff8008b8ce0000
	bool IsPlaying(); // Function MediaAssets.MediaPlayer.IsPlaying // (None) // @ game+0xffff8008b8ce0000
	bool IsPaused(); // Function MediaAssets.MediaPlayer.IsPaused // (None) // @ game+0xffff8008b8ce0000
	bool IsLooping(); // Function MediaAssets.MediaPlayer.IsLooping // (None) // @ game+0xffff8008b8ce0000
	bool IsConnecting(); // Function MediaAssets.MediaPlayer.IsConnecting // (None) // @ game+0xffff8008b8ce0000
	bool IsClosed(); // Function MediaAssets.MediaPlayer.IsClosed // (None) // @ game+0xffff8008b8ce0000
	bool IsBuffering(); // Function MediaAssets.MediaPlayer.IsBuffering // (None) // @ game+0xffff8008b8ce0000
	bool HasError(); // Function MediaAssets.MediaPlayer.HasError // (None) // @ game+0xffff8008b8ce0000
	struct FRotator GetViewRotation(); // Function MediaAssets.MediaPlayer.GetViewRotation // (None) // @ game+0xffff8008b8ce0000
	struct FString GetVideoTrackType(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackType // (None) // @ game+0xffff8008b8ce0008
	struct FFloatRange GetVideoTrackFrameRates(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackFrameRates // (None) // @ game+0xffff8008b8ce0008
	float GetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackFrameRate // (None) // @ game+0xffff8008b8ce0008
	struct FIntPoint GetVideoTrackDimensions(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackDimensions // (None) // @ game+0xffff8008b8ce0008
	float GetVideoTrackAspectRatio(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackAspectRatio // (None) // @ game+0xffff8008b8ce0008
	float GetVerticalFieldOfView(); // Function MediaAssets.MediaPlayer.GetVerticalFieldOfView // (None) // @ game+0xffff8008b8ce0000
	struct FString GetUrl(); // Function MediaAssets.MediaPlayer.GetUrl // (None) // @ game+0xffff8008b8ce0000
	struct FString GetTrackLanguage(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackLanguage // (None) // @ game+0xffff8008b8ce0008
	int32_t GetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackFormat // (None) // @ game+0xffff8008b8ce0008
	struct FText GetTrackDisplayName(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackDisplayName // (None) // @ game+0xffff8008b8ce0008
	struct FTimespan GetTimeDelay(); // Function MediaAssets.MediaPlayer.GetTimeDelay // (None) // @ game+0xffff8008b8ce0000
	struct FTimespan GetTime(); // Function MediaAssets.MediaPlayer.GetTime // (None) // @ game+0xffff8008b8ce0000
	void GetSupportedRates(struct TArray<struct FFloatRange>& OutRates, bool Unthinned); // Function MediaAssets.MediaPlayer.GetSupportedRates // (None) // @ game+0xffff8008b8ceffff
	int32_t GetSelectedTrack(enum class EMediaPlayerTrack TrackType); // Function MediaAssets.MediaPlayer.GetSelectedTrack // (None) // @ game+0xffff8008b8ce0004
	float GetRate(); // Function MediaAssets.MediaPlayer.GetRate // (None) // @ game+0xffff8008b8ce0000
	int32_t GetPlaylistIndex(); // Function MediaAssets.MediaPlayer.GetPlaylistIndex // (None) // @ game+0xffff8008b8ce0000
	struct UMediaPlaylist* GetPlaylist(); // Function MediaAssets.MediaPlayer.GetPlaylist // (None) // @ game+0xffff8008b8ce0000
	struct FName GetPlayerName(); // Function MediaAssets.MediaPlayer.GetPlayerName // (None) // @ game+0xffff8008b8ce0000
	int32_t GetNumTracks(enum class EMediaPlayerTrack TrackType); // Function MediaAssets.MediaPlayer.GetNumTracks // (None) // @ game+0xffff8008b8ce0004
	int32_t GetNumTrackFormats(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetNumTrackFormats // (None) // @ game+0xffff8008b8ce0008
	struct FText GetMediaName(); // Function MediaAssets.MediaPlayer.GetMediaName // (None) // @ game+0xffff8008b8ce0000
	struct FTimespan GetLastVideoSampleProcessedTime(); // Function MediaAssets.MediaPlayer.GetLastVideoSampleProcessedTime // (None) // @ game+0xffff8008b8ce0000
	struct FTimespan GetLastAudioSampleProcessedTime(); // Function MediaAssets.MediaPlayer.GetLastAudioSampleProcessedTime // (None) // @ game+0xffff8008b8ce0000
	float GetHorizontalFieldOfView(); // Function MediaAssets.MediaPlayer.GetHorizontalFieldOfView // (None) // @ game+0xffff8008b8ce0000
	struct FTimespan GetDuration(); // Function MediaAssets.MediaPlayer.GetDuration // (None) // @ game+0xffff8008b8ce0000
	struct FName GetDesiredPlayerName(); // Function MediaAssets.MediaPlayer.GetDesiredPlayerName // (None) // @ game+0xffff8008b8ce0000
	struct FString GetAudioTrackType(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetAudioTrackType // (None) // @ game+0xffff8008b8ce0008
	int32_t GetAudioTrackSampleRate(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetAudioTrackSampleRate // (None) // @ game+0xffff8008b8ce0008
	int32_t GetAudioTrackChannels(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetAudioTrackChannels // (None) // @ game+0xffff8008b8ce0008
	void Close(); // Function MediaAssets.MediaPlayer.Close // (None) // @ game+0xffff8008b8ceffff
	bool CanPlayUrl(struct FString URL); // Function MediaAssets.MediaPlayer.CanPlayUrl // (None) // @ game+0xffff8008b8ce0010
	bool CanPlaySource(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlayer.CanPlaySource // (None) // @ game+0xffff8008b8ce0008
	bool CanPause(); // Function MediaAssets.MediaPlayer.CanPause // (None) // @ game+0xffff8008b8ce0000
};

// Class MediaAssets.MediaPlaylist
// Size: 0x38 (Inherited: 0x28)
struct UMediaPlaylist : UObject {
	struct TArray<struct UMediaSource*> Items; // 0x28(0x10)

	bool Replace(int32_t Index, struct UMediaSource* Replacement); // Function MediaAssets.MediaPlaylist.Replace // (None) // @ game+0xffff8008b8ce0010
	bool RemoveAt(int32_t Index); // Function MediaAssets.MediaPlaylist.RemoveAt // (None) // @ game+0xffff8008b8ce0004
	bool Remove(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlaylist.Remove // (None) // @ game+0xffff8008b8ce0008
	int32_t Num(); // Function MediaAssets.MediaPlaylist.Num // (None) // @ game+0xffff8008b8ce0000
	void Insert(struct UMediaSource* MediaSource, int32_t Index); // Function MediaAssets.MediaPlaylist.Insert // (None) // @ game+0xffff8008b8ceffff
	struct UMediaSource* GetRandom(int32_t& OutIndex); // Function MediaAssets.MediaPlaylist.GetRandom // (None) // @ game+0xffff8008b8ce0008
	struct UMediaSource* GetPrevious(int32_t& InOutIndex); // Function MediaAssets.MediaPlaylist.GetPrevious // (None) // @ game+0xffff8008b8ce0008
	struct UMediaSource* GetNext(int32_t& InOutIndex); // Function MediaAssets.MediaPlaylist.GetNext // (None) // @ game+0xffff8008b8ce0008
	struct UMediaSource* Get(int32_t Index); // Function MediaAssets.MediaPlaylist.Get // (None) // @ game+0xffff8008b8ce0008
	bool AddUrl(struct FString URL); // Function MediaAssets.MediaPlaylist.AddUrl // (None) // @ game+0xffff8008b8ce0010
	bool AddFile(struct FString FilePath); // Function MediaAssets.MediaPlaylist.AddFile // (None) // @ game+0xffff8008b8ce0010
	bool Add(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlaylist.Add // (None) // @ game+0xffff8008b8ce0008
};

// Class MediaAssets.MediaSoundComponent
// Size: 0x8d0 (Inherited: 0x6d0)
struct UMediaSoundComponent : USynthComponent {
	enum class EMediaSoundChannels Channels; // 0x6d0(0x04)
	bool DynamicRateAdjustment; // 0x6d4(0x01)
	char pad_6D5[0x3]; // 0x6d5(0x03)
	float RateAdjustmentFactor; // 0x6d8(0x04)
	struct FFloatRange RateAdjustmentRange; // 0x6dc(0x10)
	char pad_6EC[0x4]; // 0x6ec(0x04)
	struct UMediaPlayer* MediaPlayer; // 0x6f0(0x08)
	char pad_6F8[0x1d8]; // 0x6f8(0x1d8)

	void SetSpectralAnalysisSettings(struct TArray<float> InFrequenciesToAnalyze, enum class EMediaSoundComponentFFTSize InFFTSize); // Function MediaAssets.MediaSoundComponent.SetSpectralAnalysisSettings // (None) // @ game+0xffff8008b8ceffff
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer); // Function MediaAssets.MediaSoundComponent.SetMediaPlayer // (None) // @ game+0xffff8008b8ceffff
	void SetEnvelopeFollowingsettings(int32_t AttackTimeMsec, int32_t ReleaseTimeMsec); // Function MediaAssets.MediaSoundComponent.SetEnvelopeFollowingsettings // (None) // @ game+0xffff8008b8ceffff
	void SetEnableSpectralAnalysis(bool bInSpectralAnalysisEnabled); // Function MediaAssets.MediaSoundComponent.SetEnableSpectralAnalysis // (None) // @ game+0xffff8008b8ceffff
	void SetEnableEnvelopeFollowing(bool bInEnvelopeFollowing); // Function MediaAssets.MediaSoundComponent.SetEnableEnvelopeFollowing // (None) // @ game+0xffff8008b8ceffff
	struct TArray<struct FMediaSoundComponentSpectralData> GetSpectralData(); // Function MediaAssets.MediaSoundComponent.GetSpectralData // (None) // @ game+0xffff8008b8ce0000
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaAssets.MediaSoundComponent.GetMediaPlayer // (None) // @ game+0xffff8008b8ce0000
	float GetEnvelopeValue(); // Function MediaAssets.MediaSoundComponent.GetEnvelopeValue // (None) // @ game+0xffff8008b8ce0000
	bool BP_GetAttenuationSettingsToApply(struct FSoundAttenuationSettings& OutAttenuationSettings); // Function MediaAssets.MediaSoundComponent.BP_GetAttenuationSettingsToApply // (None) // @ game+0xffff8008b8ce03a0
};

// Class MediaAssets.MediaTexture
// Size: 0x230 (Inherited: 0x160)
struct UMediaTexture : UTexture {
	enum class TextureAddress AddressX; // 0x158(0x01)
	enum class TextureAddress AddressY; // 0x159(0x01)
	bool AutoClear; // 0x15a(0x01)
	struct FLinearColor ClearColor; // 0x15c(0x10)
	bool EnableGenMips; // 0x16c(0x01)
	char NumMips; // 0x16d(0x01)
	struct UMediaPlayer* MediaPlayer; // 0x170(0x08)
	char pad_17D[0xb3]; // 0x17d(0xb3)

	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer); // Function MediaAssets.MediaTexture.SetMediaPlayer // (None) // @ game+0xffff8008b8ceffff
	int32_t GetWidth(); // Function MediaAssets.MediaTexture.GetWidth // (None) // @ game+0xffff8008b8ce0000
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaAssets.MediaTexture.GetMediaPlayer // (None) // @ game+0xffff8008b8ce0000
	int32_t GetHeight(); // Function MediaAssets.MediaTexture.GetHeight // (None) // @ game+0xffff8008b8ce0000
	float GetAspectRatio(); // Function MediaAssets.MediaTexture.GetAspectRatio // (None) // @ game+0xffff8008b8ce0000
};

// Class MediaAssets.PlatformMediaSource
// Size: 0x88 (Inherited: 0x80)
struct UPlatformMediaSource : UMediaSource {
	struct UMediaSource* MediaSource; // 0x80(0x08)
};

// Class MediaAssets.StreamMediaSource
// Size: 0x98 (Inherited: 0x88)
struct UStreamMediaSource : UBaseMediaSource {
	struct FString StreamUrl; // 0x88(0x10)
};

// Class MediaAssets.TimeSynchronizableMediaSource
// Size: 0x98 (Inherited: 0x88)
struct UTimeSynchronizableMediaSource : UBaseMediaSource {
	bool bUseTimeSynchronization; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	int32_t FrameDelay; // 0x8c(0x04)
	double TimeDelay; // 0x90(0x08)
};

