// BlueprintGeneratedClass BP_Zipline.BP_Zipline_C
// Size: 0x3c8 (Inherited: 0x3c8)
struct ABP_Zipline_C : APDZipLine {
};

