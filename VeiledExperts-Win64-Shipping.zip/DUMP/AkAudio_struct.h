// Enum AkAudio.EAkCallbackType
enum class EAkCallbackType : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkResult
enum class EAkResult : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkAndroidAudioAPI
enum class EAkAndroidAudioAPI : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkAudioSessionMode
enum class EAkAudioSessionMode : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkAudioSessionCategoryOptions
enum class EAkAudioSessionCategoryOptions : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkAudioSessionCategory
enum class EAkAudioSessionCategory : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EReflectionFilterBits
enum class EReflectionFilterBits : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.AkCodecId
enum class AkCodecId : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkMidiCcValues
enum class EAkMidiCcValues : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkMidiEventType
enum class EAkMidiEventType : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.ERTPCValueType
enum class ERTPCValueType : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkCurveInterpolation
enum class EAkCurveInterpolation : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.AkActionOnEventType
enum class AkActionOnEventType : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.AkMultiPositionType
enum class AkMultiPositionType : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.AkSpeakerConfiguration
enum class AkSpeakerConfiguration : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.AkChannelConfiguration
enum class AkChannelConfiguration : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.AkAcousticPortalState
enum class AkAcousticPortalState : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.PanningRule
enum class PanningRule : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.AkMeshType
enum class AkMeshType : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkCommSystem
enum class EAkCommSystem : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkChannelMask
enum class EAkChannelMask : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkChannelConfigType
enum class EAkChannelConfigType : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkPanningRule
enum class EAkPanningRule : uint8 {
	None = 0,
	None = 0
};

// Enum AkAudio.EAkFitToGeometryMode
enum class EAkFitToGeometryMode : uint8 {
	None = 0,
	None = 0
};

// ScriptStruct AkAudio.AKWaapiJsonObject
// Size: 0x10 (Inherited: 0x00)
struct FAKWaapiJsonObject {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct AkAudio.AkWaapiSubscriptionId
// Size: 0x08 (Inherited: 0x00)
struct FAkWaapiSubscriptionId {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct AkAudio.AkAdvancedInitializationSettings
// Size: 0x2c (Inherited: 0x00)
struct FAkAdvancedInitializationSettings {
	uint32_t IO_MemorySize; // 0x00(0x04)
	uint32_t IO_Granularity; // 0x04(0x04)
	float TargetAutoStreamBufferLength; // 0x08(0x04)
	bool UseStreamCache; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	uint32_t MaximumPinnedBytesInCache; // 0x10(0x04)
	bool EnableGameSyncPreparation; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	uint32_t ContinuousPlaybackLookAhead; // 0x18(0x04)
	uint32_t MonitorQueuePoolSize; // 0x1c(0x04)
	uint32_t MaximumHardwareTimeoutMs; // 0x20(0x04)
	bool DebugOutOfRangeCheckEnabled; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	float DebugOutOfRangeLimit; // 0x28(0x04)
};

// ScriptStruct AkAudio.AkAdvancedInitializationSettingsWithMultiCoreRendering
// Size: 0x30 (Inherited: 0x2c)
struct FAkAdvancedInitializationSettingsWithMultiCoreRendering : FAkAdvancedInitializationSettings {
	bool EnableMultiCoreRendering; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
};

// ScriptStruct AkAudio.AkAndroidAdvancedInitializationSettings
// Size: 0x38 (Inherited: 0x30)
struct FAkAndroidAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	uint32_t AudioAPI; // 0x30(0x04)
	bool RoundFrameSizeToHardwareSize; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
};

// ScriptStruct AkAudio.AkAudioSession
// Size: 0x0c (Inherited: 0x00)
struct FAkAudioSession {
	enum class EAkAudioSessionCategory AudioSessionCategory; // 0x00(0x04)
	uint32_t AudioSessionCategoryOptions; // 0x04(0x04)
	enum class EAkAudioSessionMode AudioSessionMode; // 0x08(0x04)
};

// ScriptStruct AkAudio.AkExternalSourceInfo
// Size: 0x38 (Inherited: 0x00)
struct FAkExternalSourceInfo {
	struct FString ExternalSrcName; // 0x00(0x10)
	enum class AkCodecId CodecID; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FString Filename; // 0x18(0x10)
	struct UAkExternalMediaAsset* ExternalSourceAsset; // 0x28(0x08)
	bool IsStreamed; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct AkAudio.AkSegmentInfo
// Size: 0x24 (Inherited: 0x00)
struct FAkSegmentInfo {
	int32_t CurrentPosition; // 0x00(0x04)
	int32_t PreEntryDuration; // 0x04(0x04)
	int32_t ActiveDuration; // 0x08(0x04)
	int32_t PostExitDuration; // 0x0c(0x04)
	int32_t RemainingLookAheadTime; // 0x10(0x04)
	float BeatDuration; // 0x14(0x04)
	float BarDuration; // 0x18(0x04)
	float GridDuration; // 0x1c(0x04)
	float GridOffset; // 0x20(0x04)
};

// ScriptStruct AkAudio.AkMidiEventBase
// Size: 0x02 (Inherited: 0x00)
struct FAkMidiEventBase {
	enum class EAkMidiEventType Type; // 0x00(0x01)
	char Chan; // 0x01(0x01)
};

// ScriptStruct AkAudio.AkMidiProgramChange
// Size: 0x03 (Inherited: 0x02)
struct FAkMidiProgramChange : FAkMidiEventBase {
	char ProgramNum; // 0x02(0x01)
};

// ScriptStruct AkAudio.AkMidiChannelAftertouch
// Size: 0x03 (Inherited: 0x02)
struct FAkMidiChannelAftertouch : FAkMidiEventBase {
	char Value; // 0x02(0x01)
};

// ScriptStruct AkAudio.AkMidiNoteAftertouch
// Size: 0x04 (Inherited: 0x02)
struct FAkMidiNoteAftertouch : FAkMidiEventBase {
	char Note; // 0x02(0x01)
	char Value; // 0x03(0x01)
};

// ScriptStruct AkAudio.AkMidiPitchBend
// Size: 0x08 (Inherited: 0x02)
struct FAkMidiPitchBend : FAkMidiEventBase {
	char ValueLsb; // 0x02(0x01)
	char ValueMsb; // 0x03(0x01)
	int32_t FullValue; // 0x04(0x04)
};

// ScriptStruct AkAudio.AkMidiCc
// Size: 0x04 (Inherited: 0x02)
struct FAkMidiCc : FAkMidiEventBase {
	enum class EAkMidiCcValues Cc; // 0x02(0x01)
	char Value; // 0x03(0x01)
};

// ScriptStruct AkAudio.AkMidiNoteOnOff
// Size: 0x04 (Inherited: 0x02)
struct FAkMidiNoteOnOff : FAkMidiEventBase {
	char Note; // 0x02(0x01)
	char Velocity; // 0x03(0x01)
};

// ScriptStruct AkAudio.AkMidiGeneric
// Size: 0x04 (Inherited: 0x02)
struct FAkMidiGeneric : FAkMidiEventBase {
	char Param1; // 0x02(0x01)
	char Param2; // 0x03(0x01)
};

// ScriptStruct AkAudio.AkChannelMask
// Size: 0x04 (Inherited: 0x00)
struct FAkChannelMask {
	int32_t ChannelMask; // 0x00(0x04)
};

// ScriptStruct AkAudio.AkGeometrySurfaceOverride
// Size: 0x18 (Inherited: 0x00)
struct FAkGeometrySurfaceOverride {
	struct UAkAcousticTexture* AcousticTexture; // 0x00(0x08)
	char bEnableOcclusionOverride : 1; // 0x08(0x01)
	char pad_8_1 : 7; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float OcclusionValue; // 0x0c(0x04)
	float SurfaceArea; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct AkAudio.AkGeometryData
// Size: 0x50 (Inherited: 0x00)
struct FAkGeometryData {
	struct TArray<struct FVector> Vertices; // 0x00(0x10)
	struct TArray<struct FAkAcousticSurface> Surfaces; // 0x10(0x10)
	struct TArray<struct FAkTriangle> Triangles; // 0x20(0x10)
	struct TArray<struct UPhysicalMaterial*> ToOverrideAcousticTexture; // 0x30(0x10)
	struct TArray<struct UPhysicalMaterial*> ToOverrideOcclusion; // 0x40(0x10)
};

// ScriptStruct AkAudio.AkTriangle
// Size: 0x08 (Inherited: 0x00)
struct FAkTriangle {
	uint16_t Point0; // 0x00(0x02)
	uint16_t Point1; // 0x02(0x02)
	uint16_t Point2; // 0x04(0x02)
	uint16_t Surface; // 0x06(0x02)
};

// ScriptStruct AkAudio.AkAcousticSurface
// Size: 0x18 (Inherited: 0x00)
struct FAkAcousticSurface {
	uint32_t Texture; // 0x00(0x04)
	float Occlusion; // 0x04(0x04)
	struct FString Name; // 0x08(0x10)
};

// ScriptStruct AkAudio.AkHololensAdvancedInitializationSettings
// Size: 0x34 (Inherited: 0x30)
struct FAkHololensAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	bool UseHeadMountedDisplayAudioDevice; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
};

// ScriptStruct AkAudio.AkPluginInfo
// Size: 0x28 (Inherited: 0x00)
struct FAkPluginInfo {
	struct FString Name; // 0x00(0x10)
	uint32_t PluginID; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString dll; // 0x18(0x10)
};

// ScriptStruct AkAudio.AkCommonInitializationSettings
// Size: 0x60 (Inherited: 0x00)
struct FAkCommonInitializationSettings {
	uint32_t MaximumNumberOfMemoryPools; // 0x00(0x04)
	uint32_t MaximumNumberOfPositioningPaths; // 0x04(0x04)
	uint32_t CommandQueueSize; // 0x08(0x04)
	uint32_t SamplesPerFrame; // 0x0c(0x04)
	struct FAkMainOutputSettings MainOutputSettings; // 0x10(0x28)
	float StreamingLookAheadRatio; // 0x38(0x04)
	uint16_t NumberOfRefillsInVoice; // 0x3c(0x02)
	char pad_3E[0x2]; // 0x3e(0x02)
	struct FAkSpatialAudioSettings SpatialAudioSettings; // 0x40(0x20)
};

// ScriptStruct AkAudio.AkSpatialAudioSettings
// Size: 0x20 (Inherited: 0x00)
struct FAkSpatialAudioSettings {
	uint32_t MaxSoundPropagationDepth; // 0x00(0x04)
	float MovementThreshold; // 0x04(0x04)
	uint32_t NumberOfPrimaryRays; // 0x08(0x04)
	uint32_t ReflectionOrder; // 0x0c(0x04)
	float MaximumPathLength; // 0x10(0x04)
	float CPULimitPercentage; // 0x14(0x04)
	bool EnableDiffractionOnReflections; // 0x18(0x01)
	bool EnableGeometricDiffractionAndTransmission; // 0x19(0x01)
	bool CalcEmitterVirtualPosition; // 0x1a(0x01)
	bool UseObstruction; // 0x1b(0x01)
	bool UseOcclusion; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
};

// ScriptStruct AkAudio.AkMainOutputSettings
// Size: 0x28 (Inherited: 0x00)
struct FAkMainOutputSettings {
	struct FString AudioDeviceShareset; // 0x00(0x10)
	uint32_t DeviceID; // 0x10(0x04)
	enum class EAkPanningRule PanningRule; // 0x14(0x04)
	enum class EAkChannelConfigType ChannelConfigType; // 0x18(0x04)
	uint32_t ChannelMask; // 0x1c(0x04)
	uint32_t NumberOfChannels; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct AkAudio.AkCommonInitializationSettingsWithSampleRate
// Size: 0x68 (Inherited: 0x60)
struct FAkCommonInitializationSettingsWithSampleRate : FAkCommonInitializationSettings {
	uint32_t SampleRate; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// ScriptStruct AkAudio.AkCommunicationSettings
// Size: 0x20 (Inherited: 0x00)
struct FAkCommunicationSettings {
	uint32_t PoolSize; // 0x00(0x04)
	uint16_t DiscoveryBroadcastPort; // 0x04(0x02)
	uint16_t CommandPort; // 0x06(0x02)
	uint16_t NotificationPort; // 0x08(0x02)
	char pad_A[0x6]; // 0x0a(0x06)
	struct FString NetworkName; // 0x10(0x10)
};

// ScriptStruct AkAudio.AkCommunicationSettingsWithCommSelection
// Size: 0x28 (Inherited: 0x20)
struct FAkCommunicationSettingsWithCommSelection : FAkCommunicationSettings {
	enum class EAkCommSystem CommunicationSystem; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct AkAudio.AkCommunicationSettingsWithSystemInitialization
// Size: 0x28 (Inherited: 0x20)
struct FAkCommunicationSettingsWithSystemInitialization : FAkCommunicationSettings {
	bool InitializeSystemComms; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct AkAudio.AkBoolPropertyToControl
// Size: 0x10 (Inherited: 0x00)
struct FAkBoolPropertyToControl {
	struct FString ItemProperty; // 0x00(0x10)
};

// ScriptStruct AkAudio.AkPropertyToControl
// Size: 0x10 (Inherited: 0x00)
struct FAkPropertyToControl {
	struct FString ItemProperty; // 0x00(0x10)
};

// ScriptStruct AkAudio.AkPS4AdvancedInitializationSettings
// Size: 0x38 (Inherited: 0x30)
struct FAkPS4AdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	uint32_t ACPBatchBufferSize; // 0x30(0x04)
	bool UseHardwareCodecLowLatencyMode; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
};

// ScriptStruct AkAudio.AkReverbDescriptor
// Size: 0x28 (Inherited: 0x00)
struct FAkReverbDescriptor {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct AkAudio.AkAcousticTextureParams
// Size: 0x20 (Inherited: 0x00)
struct FAkAcousticTextureParams {
	struct FVector4 AbsorptionValues; // 0x00(0x10)
	char pad_10[0x10]; // 0x10(0x10)
};

// ScriptStruct AkAudio.AkGeometrySurfacePropertiesToMap
// Size: 0x30 (Inherited: 0x00)
struct FAkGeometrySurfacePropertiesToMap {
	struct TSoftObjectPtr<UAkAcousticTexture> AcousticTexture; // 0x00(0x28)
	float OcclusionValue; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct AkAudio.AkWwiseItemToControl
// Size: 0x40 (Inherited: 0x00)
struct FAkWwiseItemToControl {
	struct FAkWwiseObjectDetails ItemPicked; // 0x00(0x30)
	struct FString ItemPath; // 0x30(0x10)
};

// ScriptStruct AkAudio.AkWwiseObjectDetails
// Size: 0x30 (Inherited: 0x00)
struct FAkWwiseObjectDetails {
	struct FString ItemName; // 0x00(0x10)
	struct FString ItemPath; // 0x10(0x10)
	struct FString ItemId; // 0x20(0x10)
};

// ScriptStruct AkAudio.AkSurfaceProperties
// Size: 0x40 (Inherited: 0x00)
struct FAkSurfaceProperties {
	char pad_0[0x40]; // 0x00(0x40)
};

// ScriptStruct AkAudio.AkEdgeInfo
// Size: 0x28 (Inherited: 0x00)
struct FAkEdgeInfo {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct AkAudio.AkPoly
// Size: 0x18 (Inherited: 0x00)
struct FAkPoly {
	struct UAkAcousticTexture* Texture; // 0x00(0x08)
	float Occlusion; // 0x08(0x04)
	bool EnableSurface; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	float SurfaceArea; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct AkAudio.AkWaapiFieldNames
// Size: 0x10 (Inherited: 0x00)
struct FAkWaapiFieldNames {
	struct FString FieldName; // 0x00(0x10)
};

// ScriptStruct AkAudio.AkWaapiUri
// Size: 0x10 (Inherited: 0x00)
struct FAkWaapiUri {
	struct FString Uri; // 0x00(0x10)
};

// ScriptStruct AkAudio.AkWindowsAdvancedInitializationSettings
// Size: 0x38 (Inherited: 0x30)
struct FAkWindowsAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	bool UseHeadMountedDisplayAudioDevice; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	uint32_t MaxSystemAudioObjects; // 0x34(0x04)
};

// ScriptStruct AkAudio.AkXboxOneApuHeapInitializationSettings
// Size: 0x08 (Inherited: 0x00)
struct FAkXboxOneApuHeapInitializationSettings {
	uint32_t CachedSize; // 0x00(0x04)
	uint32_t NonCachedSize; // 0x04(0x04)
};

// ScriptStruct AkAudio.AkXboxOneAdvancedInitializationSettings
// Size: 0x34 (Inherited: 0x30)
struct FAkXboxOneAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	uint16_t MaximumNumberOfXMAVoices; // 0x30(0x02)
	bool UseHardwareCodecLowLatencyMode; // 0x32(0x01)
	char pad_33[0x1]; // 0x33(0x01)
};

// ScriptStruct AkAudio.AkAudioEventTrackKey
// Size: 0x20 (Inherited: 0x00)
struct FAkAudioEventTrackKey {
	float Time; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UAkAudioEvent* AkAudioEvent; // 0x08(0x08)
	struct FString EventName; // 0x10(0x10)
};

// ScriptStruct AkAudio.MovieSceneAkAudioEventTemplate
// Size: 0x28 (Inherited: 0x20)
struct FMovieSceneAkAudioEventTemplate : FMovieSceneEvalTemplate {
	struct UMovieSceneAkAudioEventSection* Section; // 0x20(0x08)
};

// ScriptStruct AkAudio.MovieSceneAkAudioRTPCTemplate
// Size: 0x28 (Inherited: 0x20)
struct FMovieSceneAkAudioRTPCTemplate : FMovieSceneEvalTemplate {
	struct UMovieSceneAkAudioRTPCSection* Section; // 0x20(0x08)
};

// ScriptStruct AkAudio.MovieSceneFloatChannelSerializationHelper
// Size: 0x30 (Inherited: 0x00)
struct FMovieSceneFloatChannelSerializationHelper {
	enum class ERichCurveExtrapolation PreInfinityExtrap; // 0x00(0x01)
	enum class ERichCurveExtrapolation PostInfinityExtrap; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct TArray<int32_t> Times; // 0x08(0x10)
	struct TArray<struct FMovieSceneFloatValueSerializationHelper> Values; // 0x18(0x10)
	float DefaultValue; // 0x28(0x04)
	bool bHasDefaultValue; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
};

// ScriptStruct AkAudio.MovieSceneFloatValueSerializationHelper
// Size: 0x1c (Inherited: 0x00)
struct FMovieSceneFloatValueSerializationHelper {
	float Value; // 0x00(0x04)
	enum class ERichCurveInterpMode InterpMode; // 0x04(0x01)
	enum class ERichCurveTangentMode TangentMode; // 0x05(0x01)
	char pad_6[0x2]; // 0x06(0x02)
	struct FMovieSceneTangentDataSerializationHelper Tangent; // 0x08(0x14)
};

// ScriptStruct AkAudio.MovieSceneTangentDataSerializationHelper
// Size: 0x14 (Inherited: 0x00)
struct FMovieSceneTangentDataSerializationHelper {
	float ArriveTangent; // 0x00(0x04)
	float LeaveTangent; // 0x04(0x04)
	enum class ERichCurveTangentWeightMode TangentWeightMode; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float ArriveTangentWeight; // 0x0c(0x04)
	float LeaveTangentWeight; // 0x10(0x04)
};

