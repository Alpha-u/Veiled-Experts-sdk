// Enum InteractiveToolsFramework.EInputCaptureState
enum class EInputCaptureState : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.EInputCaptureRequestType
enum class EInputCaptureRequestType : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.EInputCaptureSide
enum class EInputCaptureSide : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.EInputDevices
enum class EInputDevices : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.ETransformGizmoSubElements
enum class ETransformGizmoSubElements : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.EToolChangeTrackingMode
enum class EToolChangeTrackingMode : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.EToolSide
enum class EToolSide : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.ESelectedObjectsModificationType
enum class ESelectedObjectsModificationType : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.EToolMessageLevel
enum class EToolMessageLevel : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.EToolContextCoordinateSystem
enum class EToolContextCoordinateSystem : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.EStandardToolContextMaterials
enum class EStandardToolContextMaterials : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.ESceneSnapQueryTargetType
enum class ESceneSnapQueryTargetType : uint8 {
	None = 0,
	None = 0
};

// Enum InteractiveToolsFramework.ESceneSnapQueryType
enum class ESceneSnapQueryType : uint8 {
	None = 0,
	None = 0
};

// ScriptStruct InteractiveToolsFramework.BrushStampData
// Size: 0xa8 (Inherited: 0x00)
struct FBrushStampData {
	char pad_0[0xa8]; // 0x00(0xa8)
};

// ScriptStruct InteractiveToolsFramework.BehaviorInfo
// Size: 0x20 (Inherited: 0x00)
struct FBehaviorInfo {
	struct UInputBehavior* Behavior; // 0x00(0x08)
	char pad_8[0x18]; // 0x08(0x18)
};

// ScriptStruct InteractiveToolsFramework.InputRayHit
// Size: 0x28 (Inherited: 0x00)
struct FInputRayHit {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct InteractiveToolsFramework.ActiveGizmo
// Size: 0x30 (Inherited: 0x00)
struct FActiveGizmo {
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct InteractiveToolsFramework.GizmoFloatParameterChange
// Size: 0x08 (Inherited: 0x00)
struct FGizmoFloatParameterChange {
	float InitialValue; // 0x00(0x04)
	float CurrentValue; // 0x04(0x04)
};

// ScriptStruct InteractiveToolsFramework.GizmoVec2ParameterChange
// Size: 0x10 (Inherited: 0x00)
struct FGizmoVec2ParameterChange {
	struct FVector2D InitialValue; // 0x00(0x08)
	struct FVector2D CurrentValue; // 0x08(0x08)
};

