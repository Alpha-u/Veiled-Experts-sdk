// BlueprintGeneratedClass BP_AsyDS_BottlePlasticE_002.BP_AsyDS_BottlePlasticE_002_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_AsyDS_BottlePlasticE_002_C : APDAsyncObjectDestroyed {
};

