// BlueprintGeneratedClass AnimNotify_HandR.AnimNotify_HandR_C
// Size: 0xb8 (Inherited: 0xb8)
struct UAnimNotify_HandR_C : UPDParkourAkAnimNotify {
};

