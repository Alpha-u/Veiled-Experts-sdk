// BlueprintGeneratedClass BP_3SupplyA_8Room.BP_3SupplyA_8Room_C
// Size: 0x288 (Inherited: 0x220)
struct ABP_3SupplyA_8Room_C : AActor {
	struct UStaticMeshComponent* SM_FuseBox_03; // 0x220(0x08)
	struct UStaticMeshComponent* SM_PipeEnd_002; // 0x228(0x08)
	struct UStaticMeshComponent* SM_Hallway_Exitsign_001; // 0x230(0x08)
	struct UStaticMeshComponent* SM_WallWire_03; // 0x238(0x08)
	struct UStaticMeshComponent* SM_PipeEnd_001; // 0x240(0x08)
	struct UStaticMeshComponent* SM_MERGED_3SupplyAPipe_001; // 0x248(0x08)
	struct UStaticMeshComponent* SM_3SupplyA8Wall_002; // 0x250(0x08)
	struct UStaticMeshComponent* SM_EmergencyBoardFull_001; // 0x258(0x08)
	struct UStaticMeshComponent* SM_HangingLamp_001_03; // 0x260(0x08)
	struct UStaticMeshComponent* SM_3SupplyA8Ceiling_001; // 0x268(0x08)
	struct UStaticMeshComponent* SM_3SupplyA8Floor_001; // 0x270(0x08)
	struct UStaticMeshComponent* SM_3SupplyA8Wall_001; // 0x278(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x280(0x08)
};

