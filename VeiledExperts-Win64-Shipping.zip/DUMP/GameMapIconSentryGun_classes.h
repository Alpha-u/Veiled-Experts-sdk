// WidgetBlueprintGeneratedClass GameMapIconSentryGun.GameMapIconSentryGun_C
// Size: 0x328 (Inherited: 0x310)
struct UGameMapIconSentryGun_C : UPDGameMapIconSentryGun {
	struct UWidgetAnimation* Shooting; // 0x310(0x08)
	struct UImage* IMG_Shot00; // 0x318(0x08)
	struct UImage* IMG_Shot01; // 0x320(0x08)
};

