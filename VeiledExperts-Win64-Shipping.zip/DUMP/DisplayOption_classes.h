// WidgetBlueprintGeneratedClass DisplayOption.DisplayOption_C
// Size: 0x488 (Inherited: 0x480)
struct UDisplayOption_C : UPDDisplayOptionUI {
	struct UImage* Img_ContentsLine; // 0x480(0x08)
};

