// WidgetBlueprintGeneratedClass CustomMatch.CustomMatch_C
// Size: 0x4a8 (Inherited: 0x440)
struct UCustomMatch_C : UPDCustomMatchUI {
	struct UWidgetAnimation* Anim_CopyMsg; // 0x440(0x08)
	struct UWidgetAnimation* Anim_SceneOut; // 0x448(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x450(0x08)
	struct UImage* IMG_ClanBg; // 0x458(0x08)
	struct UImage* IMG_ClanDeco; // 0x460(0x08)
	struct UImage* IMG_Community; // 0x468(0x08)
	struct UImage* IMG_ContextMenu_Shadow; // 0x470(0x08)
	struct UImage* IMG_Defence_DescBg; // 0x478(0x08)
	struct UImage* IMG_MatchSettingBg; // 0x480(0x08)
	struct UImage* IMG_MenuBg; // 0x488(0x08)
	struct UImage* IMG_Offence_DescBg; // 0x490(0x08)
	struct UImage* IMG_Option; // 0x498(0x08)
	struct UImage* IMG_Wait_DescBg; // 0x4a0(0x08)
};

