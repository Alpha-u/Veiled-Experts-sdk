// WidgetBlueprintGeneratedClass AgentCreateListItem.AgentCreateListItem_C
// Size: 0x3a8 (Inherited: 0x360)
struct UAgentCreateListItem_C : UPDAgentCreateListItem {
	struct UImage* IMG_Agent_HoverBg; // 0x360(0x08)
	struct UImage* IMG_Agent_PicBg; // 0x368(0x08)
	struct UImage* IMG_Agent_Selected_Arrow; // 0x370(0x08)
	struct UImage* IMG_Agent_SlotBg; // 0x378(0x08)
	struct UImage* IMG_Contract_HoverBg; // 0x380(0x08)
	struct UImage* IMG_Contract_PicBg; // 0x388(0x08)
	struct UImage* IMG_Contract_Selected_Arrow; // 0x390(0x08)
	struct UImage* IMG_Contract_SlotBg; // 0x398(0x08)
	struct UImage* IMG_UnderBg; // 0x3a0(0x08)
};

