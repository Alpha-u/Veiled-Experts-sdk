// Enum InputCore.ETouchIndex
enum class ETouchIndex : uint8 {
	None = 0
};

// Enum InputCore.EControllerHand
enum class EControllerHand : uint8 {
	None = 0,
	None = 0
};

// Enum InputCore.ETouchType
enum class ETouchType : uint8 {
	None = 0
};

// Enum InputCore.EConsoleForGamepadLabels
enum class EConsoleForGamepadLabels : uint8 {
	None = 0
};

// ScriptStruct InputCore.Key
// Size: 0x18 (Inherited: 0x00)
struct FKey {
	struct FName KeyName; // 0x00(0x08)
	char pad_8[0x10]; // 0x08(0x10)
};

