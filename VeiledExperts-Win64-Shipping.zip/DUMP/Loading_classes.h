// WidgetBlueprintGeneratedClass Loading.Loading_C
// Size: 0x300 (Inherited: 0x300)
struct ULoading_C : UPDLoadingUI {
};

