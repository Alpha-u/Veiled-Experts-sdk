// WidgetBlueprintGeneratedClass CrossHair.CrossHair_C
// Size: 0x910 (Inherited: 0x8f0)
struct UCrossHair_C : UPDCrossHairUI {
	struct UWidgetAnimation* Ani_Groggy; // 0x8f0(0x08)
	struct UWidgetAnimation* Ani_Kill; // 0x8f8(0x08)
	struct UWidgetAnimation* Ani_Reload; // 0x900(0x08)
	struct UWidgetAnimation* Ani_HitIndicator; // 0x908(0x08)
};

