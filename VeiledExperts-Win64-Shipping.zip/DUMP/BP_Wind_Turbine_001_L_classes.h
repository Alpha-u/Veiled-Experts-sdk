// BlueprintGeneratedClass BP_Wind_Turbine_001_L.BP_Wind_Turbine_001_L_C
// Size: 0x3a0 (Inherited: 0x370)
struct ABP_Wind_Turbine_001_L_C : APDPropActor {
	struct UStaticMeshComponent* SM_Wind_Turbine_003_DO; // 0x370(0x08)
	struct UStaticMeshComponent* SM_Wind_Turbine_007; // 0x378(0x08)
	struct UStaticMeshComponent* SM_Wind_Turbine_005; // 0x380(0x08)
	struct UStaticMeshComponent* SM_Wind_Turbine_006; // 0x388(0x08)
	struct UStaticMeshComponent* StaticMeshComponent0; // 0x390(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x398(0x08)
};

