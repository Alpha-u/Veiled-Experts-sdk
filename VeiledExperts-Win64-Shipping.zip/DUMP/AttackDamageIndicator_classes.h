// WidgetBlueprintGeneratedClass AttackDamageIndicator.AttackDamageIndicator_C
// Size: 0x600 (Inherited: 0x600)
struct UAttackDamageIndicator_C : UPDAttackDamageIndicatorUI {
};

