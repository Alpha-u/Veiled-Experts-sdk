// WidgetBlueprintGeneratedClass GameMapIconCamp.GameMapIconCamp_C
// Size: 0x320 (Inherited: 0x320)
struct UGameMapIconCamp_C : UPDGameMapIconCamp {
};

