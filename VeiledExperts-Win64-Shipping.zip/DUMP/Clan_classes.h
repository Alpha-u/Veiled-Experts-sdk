// WidgetBlueprintGeneratedClass Clan.Clan_C
// Size: 0x3a0 (Inherited: 0x380)
struct UClan_C : UPDClanUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x380(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x388(0x08)
	struct UImage* IMG_ClanBg; // 0x390(0x08)
	struct UImage* IMG_SubMenu_BG; // 0x398(0x08)
};

