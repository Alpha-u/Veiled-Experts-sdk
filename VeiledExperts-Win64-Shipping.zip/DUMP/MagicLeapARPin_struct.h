// Enum MagicLeapARPin.EMagicLeapAutoPinType
enum class EMagicLeapAutoPinType : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapARPin.EMagicLeapPassableWorldError
enum class EMagicLeapPassableWorldError : uint8 {
	None = 0,
	None = 0
};

// ScriptStruct MagicLeapARPin.MagicLeapARPinState
// Size: 0x10 (Inherited: 0x00)
struct FMagicLeapARPinState {
	float Confidence; // 0x00(0x04)
	float ValidRadius; // 0x04(0x04)
	float RotationError; // 0x08(0x04)
	float TranslationError; // 0x0c(0x04)
};

