// WidgetBlueprintGeneratedClass GameMapIconGunFire.GameMapIconGunFire_C
// Size: 0x2f8 (Inherited: 0x2f8)
struct UGameMapIconGunFire_C : UPDGameMapIconFireSoundUI {
};

