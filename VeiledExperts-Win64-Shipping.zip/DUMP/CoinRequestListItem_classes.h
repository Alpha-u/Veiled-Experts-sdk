// WidgetBlueprintGeneratedClass CoinRequestListItem.CoinRequestListItem_C
// Size: 0x378 (Inherited: 0x340)
struct UCoinRequestListItem_C : UPDCoinRequestListItem {
	struct UImage* IMG_Coin; // 0x340(0x08)
	struct UImage* IMG_MouseGuide_Coin_L; // 0x348(0x08)
	struct UImage* IMG_MouseGuide_Coin_R; // 0x350(0x08)
	struct UImage* IMG_MouseGuide_L; // 0x358(0x08)
	struct UImage* IMG_MouseGuide_R; // 0x360(0x08)
	struct UImage* IMG_MouseGuideBg_L; // 0x368(0x08)
	struct UImage* IMG_MouseGuideBg_R; // 0x370(0x08)
};

