// WidgetBlueprintGeneratedClass InvitePartyPopup.InvitePartyPopup_C
// Size: 0x3b0 (Inherited: 0x360)
struct UInvitePartyPopup_C : UPDInvitePartyPopupUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x360(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x368(0x08)
	struct UImage* IMG_Deco_01; // 0x370(0x08)
	struct UImage* IMG_Deco_02; // 0x378(0x08)
	struct UImage* IMG_Deco_03; // 0x380(0x08)
	struct UImage* IMG_Deco_04; // 0x388(0x08)
	struct UImage* IMG_PopupBg; // 0x390(0x08)
	struct UImage* IMG_PopupBg_L; // 0x398(0x08)
	struct UImage* IMG_PopupBg_R; // 0x3a0(0x08)
	struct UImage* IMG_VXLogo; // 0x3a8(0x08)
};

