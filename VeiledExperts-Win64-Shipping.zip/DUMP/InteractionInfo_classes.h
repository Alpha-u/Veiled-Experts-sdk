// WidgetBlueprintGeneratedClass InteractionInfo.InteractionInfo_C
// Size: 0x3e0 (Inherited: 0x3c8)
struct UInteractionInfo_C : UPDInteractionInfoUI {
	struct UCircleProgressModule_C* CPM_Progress_Back_2; // 0x3c8(0x08)
	struct UCircleProgressModule_C* CPM_Progress_BackLine; // 0x3d0(0x08)
	struct UImage* Image_109; // 0x3d8(0x08)
};

