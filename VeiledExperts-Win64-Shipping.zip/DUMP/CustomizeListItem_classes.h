// WidgetBlueprintGeneratedClass CustomizeListItem.CustomizeListItem_C
// Size: 0x300 (Inherited: 0x2f8)
struct UCustomizeListItem_C : UPDCustomizeListItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2f8(0x08)

	void BP_OnEntryReleased(); // Function CustomizeListItem.CustomizeListItem_C.BP_OnEntryReleased // (Net|Exec|Native|Static|MulticastDelegate|Public|Protected|NetServer|HasOutParms|DLLImport|BlueprintCallable|BlueprintEvent|NetValidate) // @ game+0xffff8008b8ceffff
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function CustomizeListItem.CustomizeListItem_C.BP_OnItemExpansionChanged // (NetReliableExec|Native|Static|MulticastDelegate|Public|Protected|NetServer|HasOutParms|DLLImport|BlueprintCallable|BlueprintEvent|NetValidate) // @ game+0xffff8008b8ceffff
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function CustomizeListItem.CustomizeListItem_C.BP_OnItemSelectionChanged // (NetReliableNetRequest|Native|Static|MulticastDelegate|Public|Protected|NetServer|HasOutParms|DLLImport|BlueprintCallable|BlueprintEvent|NetValidate) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_CustomizeListItem(int32_t EntryPoint); // Function CustomizeListItem.CustomizeListItem_C.ExecuteUbergraph_CustomizeListItem // (None) // @ game+0xffff8008b8ceffff
};

