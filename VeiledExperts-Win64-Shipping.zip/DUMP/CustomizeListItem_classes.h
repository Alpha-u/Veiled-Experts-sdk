// WidgetBlueprintGeneratedClass CustomizeListItem.CustomizeListItem_C
// Size: 0x300 (Inherited: 0x2f8)
struct UCustomizeListItem_C : UPDCustomizeListItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2f8(0x08)

	void BP_OnEntryReleased(); // Function CustomizeListItem.CustomizeListItem_C.BP_OnEntryReleased // (NetReliableExec|Native|Static|NetMulticast|UbergraphFunction|MulticastDelegate|Private|Protected|Delegate|HasOutParms|HasDefaults|NetClient|BlueprintEvent|BlueprintPure|Const|NetValidate) // @ game+0xffff80091677ffff
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function CustomizeListItem.CustomizeListItem_C.BP_OnItemExpansionChanged // (Net|NetReliableNetRequest|Exec|Event|Static|NetMulticast|UbergraphFunction|MulticastDelegate|Private|Protected|Delegate|HasOutParms|HasDefaults|NetClient|BlueprintEvent|BlueprintPure|Const|NetValidate) // @ game+0xffff80091677ffff
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function CustomizeListItem.CustomizeListItem_C.BP_OnItemSelectionChanged // (NetReliableNetResponse|Static|NetMulticast|UbergraphFunction|MulticastDelegate|Private|Protected|Delegate|HasOutParms|HasDefaults|NetClient|BlueprintEvent|BlueprintPure|Const|NetValidate) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_CustomizeListItem(int32_t EntryPoint); // Function CustomizeListItem.CustomizeListItem_C.ExecuteUbergraph_CustomizeListItem // (None) // @ game+0xffff80091677ffff
};

