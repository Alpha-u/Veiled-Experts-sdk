// WidgetBlueprintGeneratedClass EquipLeptonInfo.EquipLeptonInfo_C
// Size: 0x390 (Inherited: 0x340)
struct UEquipLeptonInfo_C : UPDEquipLeptonUI {
	struct UImage* IMG_Alert; // 0x340(0x08)
	struct UImage* IMG_Anim; // 0x348(0x08)
	struct UImage* IMG_LeptonAlert_Bg; // 0x350(0x08)
	struct UImage* IMG_LeptonAlert_Bg2; // 0x358(0x08)
	struct UImage* IMG_Name_Deco; // 0x360(0x08)
	struct UImage* IMG_Story_Deco; // 0x368(0x08)
	struct UImage* IMG_Tooltip_Bg; // 0x370(0x08)
	struct UImage* IMG_Tooltip_IconBg; // 0x378(0x08)
	struct UImage* IMG_Tooltip_Outline; // 0x380(0x08)
	struct URichTextBlock* RT_PerkAlert_Desc; // 0x388(0x08)
};

