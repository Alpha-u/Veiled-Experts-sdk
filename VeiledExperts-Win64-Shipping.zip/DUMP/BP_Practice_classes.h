// BlueprintGeneratedClass BP_Practice.BP_Practice_C
// Size: 0x730 (Inherited: 0x728)
struct ABP_Practice_C : APDDynamicObject {
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x728(0x08)
};

