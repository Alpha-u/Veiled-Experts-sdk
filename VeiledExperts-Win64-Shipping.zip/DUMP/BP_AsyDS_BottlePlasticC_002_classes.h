// BlueprintGeneratedClass BP_AsyDS_BottlePlasticC_002.BP_AsyDS_BottlePlasticC_002_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_AsyDS_BottlePlasticC_002_C : APDAsyncObjectDestroyed {
};

