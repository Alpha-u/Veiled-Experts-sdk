// WidgetBlueprintGeneratedClass Intro.Intro_C
// Size: 0x308 (Inherited: 0x308)
struct UIntro_C : UPDIntroUI {
};

