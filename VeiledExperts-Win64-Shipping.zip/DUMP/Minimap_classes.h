// WidgetBlueprintGeneratedClass Minimap.Minimap_C
// Size: 0x408 (Inherited: 0x350)
struct UMinimap_C : UPDMinimapUI {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x350(0x08)
	struct UWidgetAnimation* AllyPing_Old; // 0x358(0x08)
	struct UWidgetAnimation* MissionPing_Old; // 0x360(0x08)
	struct UWidgetAnimation* MapScale; // 0x368(0x08)
	struct UWidgetAnimation* AllyPing; // 0x370(0x08)
	struct UWidgetAnimation* MissionPing; // 0x378(0x08)
	struct UPDButton_C* Btn_DeleteAllLine; // 0x380(0x08)
	struct UCheckBox* CB_ToggleBoard; // 0x388(0x08)
	struct UImage* IMG_AlertAnim_01; // 0x390(0x08)
	struct UImage* IMG_AlertAnim_02; // 0x398(0x08)
	struct UImage* IMG_AlertAnim_03; // 0x3a0(0x08)
	struct UImage* IMG_Back; // 0x3a8(0x08)
	struct UImage* IMG_BadgeBg; // 0x3b0(0x08)
	struct UImage* IMG_BadgeOutline; // 0x3b8(0x08)
	struct UPDImage* IMG_Deco; // 0x3c0(0x08)
	struct UImage* IMG_MapShadow; // 0x3c8(0x08)
	struct UImage* IMG_Mouse_C; // 0x3d0(0x08)
	struct UImage* IMG_Mouse_C_2; // 0x3d8(0x08)
	struct UImage* IMG_Mouse_L; // 0x3e0(0x08)
	struct UImage* IMG_Mouse_WD; // 0x3e8(0x08)
	struct UImage* IMG_Mouse_WU; // 0x3f0(0x08)
	struct URetainerBox* RetainerBox_1; // 0x3f8(0x08)
	struct UWidgetSwitcher* WS_Menu; // 0x400(0x08)

	void Construct(); // Function Minimap.Minimap_C.Construct // (Net|NetReliableNetRequest|Exec|Native|Event|NetMulticast|UbergraphFunction|Public|Delegate|HasOutParms|NetClient|BlueprintEvent|BlueprintPure|EditorOnly) // @ game+0xffff8008b8ceffff
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function Minimap.Minimap_C.Tick // (NetReliableNetResponse|NetMulticast|UbergraphFunction|Public|Delegate|HasOutParms|NetClient|BlueprintEvent|BlueprintPure|EditorOnly) // @ game+0xffff8008b8ceffff
	void ExecuteUbergraph_Minimap(int32_t EntryPoint); // Function Minimap.Minimap_C.ExecuteUbergraph_Minimap // (None) // @ game+0xffff8008b8ceffff
};

