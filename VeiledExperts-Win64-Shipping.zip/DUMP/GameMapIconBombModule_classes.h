// WidgetBlueprintGeneratedClass GameMapIconBombModule.GameMapIconBombModule_C
// Size: 0x2f0 (Inherited: 0x2f0)
struct UGameMapIconBombModule_C : UPDGameMapIconModule {
};

