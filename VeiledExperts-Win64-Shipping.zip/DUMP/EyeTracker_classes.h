// Class EyeTracker.EyeTrackerFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UEyeTrackerFunctionLibrary : UBlueprintFunctionLibrary {

	void SetEyeTrackedPlayer(struct APlayerController* PlayerController); // Function EyeTracker.EyeTrackerFunctionLibrary.SetEyeTrackedPlayer // (None) // @ game+0xffff8008b8ceffff
	bool IsStereoGazeDataAvailable(); // Function EyeTracker.EyeTrackerFunctionLibrary.IsStereoGazeDataAvailable // (None) // @ game+0xffff8008b8ce0000
	bool IsEyeTrackerConnected(); // Function EyeTracker.EyeTrackerFunctionLibrary.IsEyeTrackerConnected // (None) // @ game+0xffff8008b8ce0000
	bool GetStereoGazeData(struct FEyeTrackerStereoGazeData& OutGazeData); // Function EyeTracker.EyeTrackerFunctionLibrary.GetStereoGazeData // (None) // @ game+0xffff8008b8ce0040
	bool GetGazeData(struct FEyeTrackerGazeData& OutGazeData); // Function EyeTracker.EyeTrackerFunctionLibrary.GetGazeData // (None) // @ game+0xffff8008b8ce0028
};

