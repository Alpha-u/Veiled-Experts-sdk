// UserDefinedEnum ENiagaraExpansionMode.ENiagaraExpansionMode
enum class ENiagaraExpansionMode : uint8 {
	None = 0
};

