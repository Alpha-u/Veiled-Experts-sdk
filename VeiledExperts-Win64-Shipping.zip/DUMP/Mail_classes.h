// WidgetBlueprintGeneratedClass Mail.Mail_C
// Size: 0x380 (Inherited: 0x350)
struct UMail_C : UPDMailUI {
	struct UWidgetAnimation* Anim_SceneOut; // 0x350(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x358(0x08)
	struct UImage* IMG_MailBg; // 0x360(0x08)
	struct UImage* IMG_PopupBg; // 0x368(0x08)
	struct UImage* IMG_PopupBg_Bottom; // 0x370(0x08)
	struct UImage* IMG_TopDeco; // 0x378(0x08)
};

