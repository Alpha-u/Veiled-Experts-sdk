// WidgetBlueprintGeneratedClass MatchModeList.MatchModeList_C
// Size: 0x568 (Inherited: 0x538)
struct UMatchModeList_C : UPDMatchModeList {
	struct UWidgetAnimation* Anim_SceneOut; // 0x538(0x08)
	struct UWidgetAnimation* Anim_SceneShowUp; // 0x540(0x08)
	struct UImage* IMG_Guide_Mouse_2; // 0x548(0x08)
	struct UImage* IMG_ModeDesc_Line; // 0x550(0x08)
	struct UImage* IMG_ModeDesc_Shadow; // 0x558(0x08)
	struct UImage* IMG_ModeList_Sub_Shadow; // 0x560(0x08)
};

