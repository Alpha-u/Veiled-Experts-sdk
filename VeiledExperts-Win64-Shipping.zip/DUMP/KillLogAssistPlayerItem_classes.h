// WidgetBlueprintGeneratedClass KillLogAssistPlayerItem.KillLogAssistPlayerItem_C
// Size: 0x2e8 (Inherited: 0x2e8)
struct UKillLogAssistPlayerItem_C : UPDKillLogAssistPlayerItem {
};

