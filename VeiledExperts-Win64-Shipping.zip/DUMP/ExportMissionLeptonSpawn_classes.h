// BlueprintGeneratedClass ExportMissionLeptonSpawn.ExportMissionLeptonSpawn_C
// Size: 0x228 (Inherited: 0x220)
struct AExportMissionLeptonSpawn_C : AExportMissionLeptonSpawn {
	struct UStaticMeshComponent* StaticMesh; // 0x220(0x08)
};

