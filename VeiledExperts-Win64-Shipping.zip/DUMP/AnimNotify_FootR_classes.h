// BlueprintGeneratedClass AnimNotify_FootR.AnimNotify_FootR_C
// Size: 0xb8 (Inherited: 0xb8)
struct UAnimNotify_FootR_C : UPDFootstepAkAnimNotify {
};

