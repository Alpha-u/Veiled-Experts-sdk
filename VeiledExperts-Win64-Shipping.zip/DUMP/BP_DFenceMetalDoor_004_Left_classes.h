// BlueprintGeneratedClass BP_DFenceMetalDoor_004_Left.BP_DFenceMetalDoor_004_Left_C
// Size: 0x778 (Inherited: 0x728)
struct ABP_DFenceMetalDoor_004_Left_C : APDDynamicObject {
	struct UStaticMeshComponent* SM_FenceChainDoor_003_PenW<penetrating>; // 0x728(0x08)
	struct UStaticMeshComponent* SM_SignA_03; // 0x730(0x08)
	struct UStaticMeshComponent* SM_Decal_016; // 0x738(0x08)
	struct UStaticMeshComponent* SM_SignA_02; // 0x740(0x08)
	struct UStaticMeshComponent* SM_Decal_015; // 0x748(0x08)
	struct UStaticMeshComponent* SM_Decal_014; // 0x750(0x08)
	struct UStaticMeshComponent* SM_EaterySign_003; // 0x758(0x08)
	struct UStaticMeshComponent* SM_FenceDoorDecal_002; // 0x760(0x08)
	struct UStaticMeshComponent* LDOOR#; // 0x768(0x08)
	struct USceneComponent* ALIVEOBJ#; // 0x770(0x08)
};

