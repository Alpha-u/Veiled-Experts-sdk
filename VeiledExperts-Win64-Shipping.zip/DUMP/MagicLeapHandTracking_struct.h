// Enum MagicLeapHandTracking.EMagicLeapGestureTransformSpace
enum class EMagicLeapGestureTransformSpace : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapHandTracking.EMagicLeapHandTrackingGestureFilterLevel
enum class EMagicLeapHandTrackingGestureFilterLevel : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapHandTracking.EMagicLeapHandTrackingKeypointFilterLevel
enum class EMagicLeapHandTrackingKeypointFilterLevel : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapHandTracking.EMagicLeapHandTrackingGesture
enum class EMagicLeapHandTrackingGesture : uint8 {
	None = 0,
	None = 0
};

// Enum MagicLeapHandTracking.EMagicLeapHandTrackingKeypoint
enum class EMagicLeapHandTrackingKeypoint : uint8 {
	None = 0,
	None = 0
};

