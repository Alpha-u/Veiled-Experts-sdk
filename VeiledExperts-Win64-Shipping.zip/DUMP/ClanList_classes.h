// WidgetBlueprintGeneratedClass ClanList.ClanList_C
// Size: 0x380 (Inherited: 0x318)
struct UClanList_C : UPDClanListUI {
	struct UImage* IMG_Bar_01; // 0x318(0x08)
	struct UImage* IMG_Bar_02; // 0x320(0x08)
	struct UImage* IMG_Bar_03; // 0x328(0x08)
	struct UImage* IMG_Bar_04; // 0x330(0x08)
	struct UImage* IMG_Bar_05; // 0x338(0x08)
	struct UImage* IMG_Bar_06; // 0x340(0x08)
	struct UImage* IMG_Bar_07; // 0x348(0x08)
	struct UImage* IMG_Bar_08; // 0x350(0x08)
	struct UImage* IMG_Bar_09; // 0x358(0x08)
	struct UImage* IMG_ClanListContext_Outline; // 0x360(0x08)
	struct UImage* IMG_ContextMenu_Shadow; // 0x368(0x08)
	struct UImage* IMG_MenuBg; // 0x370(0x08)
	struct UImage* IMG_SearchIcon_4; // 0x378(0x08)
};

