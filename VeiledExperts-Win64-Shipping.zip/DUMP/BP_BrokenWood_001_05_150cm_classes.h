// BlueprintGeneratedClass BP_BrokenWood_001_05_150cm.BP_BrokenWood_001_05_150cm_C
// Size: 0x730 (Inherited: 0x728)
struct ABP_BrokenWood_001_05_150cm_C : APDDynamicObject {
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x728(0x08)
};

