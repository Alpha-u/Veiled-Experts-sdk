// WidgetBlueprintGeneratedClass MatchPlayerMyCharListItem.MatchPlayerMyCharListItem_C
// Size: 0x328 (Inherited: 0x318)
struct UMatchPlayerMyCharListItem_C : UPDMatchPlayerMyCharListItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UImage* IMG_SlotBg; // 0x320(0x08)

	void BP_OnEntryReleased(); // Function MatchPlayerMyCharListItem.MatchPlayerMyCharListItem_C.BP_OnEntryReleased // (NetReliableNetRequest|Exec|Native|Event|NetMulticast|MulticastDelegate|Private|HasOutParms|NetClient|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function MatchPlayerMyCharListItem.MatchPlayerMyCharListItem_C.BP_OnItemExpansionChanged // (Net|NetReliableNetRequest|Exec|Native|Event|NetMulticast|MulticastDelegate|Private|HasOutParms|NetClient|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function MatchPlayerMyCharListItem.MatchPlayerMyCharListItem_C.BP_OnItemSelectionChanged // (NetResponse|NetMulticast|MulticastDelegate|Private|HasOutParms|NetClient|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_MatchPlayerMyCharListItem(int32_t EntryPoint); // Function MatchPlayerMyCharListItem.MatchPlayerMyCharListItem_C.ExecuteUbergraph_MatchPlayerMyCharListItem // (None) // @ game+0xffff80091677ffff
};

