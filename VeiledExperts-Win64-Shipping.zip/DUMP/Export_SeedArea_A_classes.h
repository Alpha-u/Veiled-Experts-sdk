// BlueprintGeneratedClass Export_SeedArea_A.Export_SeedArea_A_C
// Size: 0x288 (Inherited: 0x280)
struct AExport_SeedArea_A_C : APDExportSeedArea {
	struct UStaticMeshComponent* ADecal; // 0x280(0x08)
};

