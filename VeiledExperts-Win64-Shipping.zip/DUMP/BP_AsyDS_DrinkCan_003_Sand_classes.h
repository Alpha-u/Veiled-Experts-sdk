// BlueprintGeneratedClass BP_AsyDS_DrinkCan_003_Sand.BP_AsyDS_DrinkCan_003_Sand_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_AsyDS_DrinkCan_003_Sand_C : APDAsyncObjectDestroyed {
};

