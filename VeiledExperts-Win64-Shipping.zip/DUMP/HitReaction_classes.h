// AnimBlueprintGeneratedClass HitReaction.HitReaction_C
// Size: 0xca8 (Inherited: 0x2c0)
struct UHitReaction_C : UPDHitReactionAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_SubInput; // 0x2f8(0x78)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x370(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x478(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x498(0x20)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_4; // 0x4b8(0xb8)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3; // 0x570(0xb8)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_3; // 0x628(0xc8)
	struct FAnimNode_Slot AnimGraphNode_Slot_3; // 0x6f0(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot_2; // 0x738(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2; // 0x780(0xc8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_8; // 0x848(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_7; // 0x870(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2; // 0x898(0xb8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_6; // 0x950(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5; // 0x978(0x28)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x9a0(0xa0)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0xa40(0xc8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4; // 0xb08(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3; // 0xb30(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0xb58(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0xba0(0xb8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0xc58(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0xc80(0x28)

	void AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph); // Function HitReaction.HitReaction_C.AnimGraph // (NetReliableExec|Native|Public|Delegate|NetClient|BlueprintPure|EditorOnly) // @ game+0xffff80091677ffff
	void ExecuteUbergraph_HitReaction(int32_t EntryPoint); // Function HitReaction.HitReaction_C.ExecuteUbergraph_HitReaction // (None) // @ game+0xffff80091677ffff
};

