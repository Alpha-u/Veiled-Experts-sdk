// WidgetBlueprintGeneratedClass MissionScore_RoundInfo.MissionScore_RoundInfo_C
// Size: 0x3b0 (Inherited: 0x3b0)
struct UMissionScore_RoundInfo_C : UPDMissionScoreRoundInfoUI {
};

