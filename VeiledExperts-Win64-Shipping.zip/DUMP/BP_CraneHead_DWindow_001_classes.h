// BlueprintGeneratedClass BP_CraneHead_DWindow_001.BP_CraneHead_DWindow_001_C
// Size: 0x730 (Inherited: 0x728)
struct ABP_CraneHead_DWindow_001_C : APDDynamicObject {
	struct UStaticMeshComponent* ALIVEOBJ#; // 0x728(0x08)
};

