// WidgetBlueprintGeneratedClass CustomMatchListItem.CustomMatchListItem_C
// Size: 0x3c8 (Inherited: 0x3a0)
struct UCustomMatchListItem_C : UPDCustomMatchListItem {
	struct UPDButton_C* Btn_Add; // 0x3a0(0x08)
	struct UImage* IMG_Empty_SlotBg; // 0x3a8(0x08)
	struct UImage* IMG_Normal_SlotBg; // 0x3b0(0x08)
	struct UImage* IMG_PerkIcon; // 0x3b8(0x08)
	struct UImage* IMG_PictureBg; // 0x3c0(0x08)
};

