// BlueprintGeneratedClass BP_Club_K_Moving_001.BP_Club_K_Moving_001_C
// Size: 0x388 (Inherited: 0x370)
struct ABP_Club_K_Moving_001_C : APDPropActor {
	struct UStaticMeshComponent* SM_BP_Club_K_Moving_01; // 0x370(0x08)
	struct USceneComponent* Scene; // 0x378(0x08)
	struct USceneComponent* SharedRoot; // 0x380(0x08)
};

