// WidgetBlueprintGeneratedClass InvenDrag.InvenDrag_C
// Size: 0x300 (Inherited: 0x300)
struct UInvenDrag_C : UPDInvenDrag {
};

