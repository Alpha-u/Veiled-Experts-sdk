// WidgetBlueprintGeneratedClass Intro_Derailed.Intro_Derailed_C
// Size: 0x310 (Inherited: 0x2d8)
struct UIntro_Derailed_C : UPDMatchIntroUI {
	struct UWidgetAnimation* Anim_Intro; // 0x2d8(0x08)
	struct UImage* IMG_DERAILED_Mission_Fx; // 0x2e0(0x08)
	struct URetainerBox* RB_DERAILED_Mission_GLow; // 0x2e8(0x08)
	struct URetainerBox* RT_DERAILED_MapName_Fx_01; // 0x2f0(0x08)
	struct URetainerBox* RT_DERAILED_MapName_Fx_02; // 0x2f8(0x08)
	struct URetainerBox* RT_DERAILED_Mission_Fx_01; // 0x300(0x08)
	struct URetainerBox* RT_DERAILED_Mission_Fx_02; // 0x308(0x08)
};

