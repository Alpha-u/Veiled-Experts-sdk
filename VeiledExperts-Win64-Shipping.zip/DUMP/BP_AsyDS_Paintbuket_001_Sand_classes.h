// BlueprintGeneratedClass BP_AsyDS_Paintbuket_001_Sand.BP_AsyDS_Paintbuket_001_Sand_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_AsyDS_Paintbuket_001_Sand_C : APDAsyncObjectDestroyed {
};

