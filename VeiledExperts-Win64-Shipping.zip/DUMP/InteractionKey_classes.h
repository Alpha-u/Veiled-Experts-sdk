// WidgetBlueprintGeneratedClass InteractionKey.InteractionKey_C
// Size: 0x4c0 (Inherited: 0x488)
struct UInteractionKey_C : UPDKeyText {
	struct UImage* IMG_GuideMouseLeft; // 0x488(0x08)
	struct UImage* IMG_GuideMouseMiddle; // 0x490(0x08)
	struct UImage* IMG_GuideMouseRight; // 0x498(0x08)
	struct UImage* IMG_GuideMouseThumb; // 0x4a0(0x08)
	struct UImage* IMG_GuideMouseThumb2; // 0x4a8(0x08)
	struct UImage* IMG_GuideScrollDown; // 0x4b0(0x08)
	struct UImage* IMG_GuideScrollUp; // 0x4b8(0x08)
};

