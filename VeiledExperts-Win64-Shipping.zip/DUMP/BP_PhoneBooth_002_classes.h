// BlueprintGeneratedClass BP_PhoneBooth_002.BP_PhoneBooth_002_C
// Size: 0x258 (Inherited: 0x220)
struct ABP_PhoneBooth_002_C : AActor {
	struct UChildActorComponent* BP_OfficeWindowG100X60_007; // 0x220(0x08)
	struct UChildActorComponent* BP_OfficeWindowG100X60_006; // 0x228(0x08)
	struct UChildActorComponent* BP_OfficeWindowG100X60_005; // 0x230(0x08)
	struct UChildActorComponent* BP_OfficeWindowG100X60_004; // 0x238(0x08)
	struct UStaticMeshComponent* SM_Phone_001; // 0x240(0x08)
	struct UStaticMeshComponent* SM_PhoneBooth_002_01; // 0x248(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x250(0x08)
};

